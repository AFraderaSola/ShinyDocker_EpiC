#' Function to delete to not very often used MQ folders
#' 
#' @param folders The folder which should be removed
#' @param delete_pattern Regex for folders which schould be deleted
#' @param quiet Print some output
#' @export
deleteUnusedMQFolders <- function(folders, 
                                  delete_pattern='/andromeda$|/ps$|/search$|/ser$|/n0$|/p0$',
                                  quiet=FALSE) {
  folders_to_erase <- 
    folders[grep(delete_pattern, folders)]
  
  if(!quiet) {
    cat(sprintf('We will erase %s folders!\n', length(folders_to_erase)))
  }
  for(i in seq(length(folders_to_erase))) {
    folder <- folders_to_erase[i]
    if(!quiet) {
      cat(sprintf('%s deleting %4d/%4d subfolder: "%s"\n',
                Sys.time(), i, length(folders_to_erase), folder))
    }
    unlink(folder, recursive=TRUE)
  }
  
  if(!quiet) {
    cat(sprintf('\nWe erased %s folders!', length(folders_to_erase)))
  }
}

