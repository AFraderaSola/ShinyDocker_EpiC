###############################################################################
#
# Function to interpret the rawfile name used at the CF Proteomics.
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

#' Function to handle our specific raw file names.
#' 
#' The raw file names in our institute have a complicated structure. To parse
#' them automatically, I created this object which expects a raw filename or at
#' least a the name part without the .raw ending (MaxQuant sometimes writes it
#' in the summary file without .raw ending). 
#' The function tries to extract the important information and reads some file 
#' infos.
#' 
#' In case a warning message appears and the parsing didn't work, it is also 
#' possible to create to set important parameters by hand. Please check the 
#' examples how to do this.
#' @export
#' @param filename The filename of a rawfile (without .raw ending is also possible)
#' @param date A 8 digits string representing a date (ex. 20150710)
#' @param machine A string to identifiy the machine (ex. QEP1, QEP2)
#' @param institute A string to identify the institute 
#' @param group A group abbreviation
#' @param barcode The sample barcode, used to identify the sample (ex. 0123, HeLa) 
#' and might be followed by some parameter such as fraction (-A, -B), always indicated with "-"
#' @param species A lowercase string indicating the species (hs -> human, cs -> yeast)
#' @param experiment Experiment type (ex. IP, IC, PR)
#' @param label Labeling type, such as NON, DML, SIL
#' @param retentiontime A string with 3 digits represening the minutes (ex. 060, 120)
#' @param comment Any comments behind the standard string
#' @param amount amount of sample
#' @examples 
#' RawFile('folder/20150113_QEP1_IMB_CF_HeLa-500ng_hs_PR_SIL_120.raw')
#' RawFile('20150113_QEP1_IMB_CF_HeLa-500ng_hs_PR_SIL_120.raw')
#' RawFile('20150113_QEP1_IMB_CF_HeLa-500ng_hs_PR_SIL_120') # also works without .raw
#' 
#' # In case the regex couldn't be applied, do it manually
#' RawFile(date='20150113', machine='QEP1', institute='IMB',
#'         group='CF', barcode='HeLa-500ng', species='hs',
#'         experiment='PR', label='SIL', retentiontime='120')
RawFile <- function(filename='',
                    date='',
                    machine='',
                    institute='',
                    group='',
                    barcode='',
                    species='',
                    experiment='',
                    label='',
                    retentiontime='', 
                    comment='',
                    amount='') {
  regexes <- list(
    standard=paste(c(
      '(?<date>[0-9]{8})',
      '(?<machine>[A-Z]+[0-9])',
      '(?<institute>[A-Za-z]+)',
      '(?<group>[A-Za-z]+)',
      '(?<barcode>[0-9]{4,5}-?[A-Za-z0-9]*|HeLa-?[A-Za-z0-9]*)',
      '(?<species>[a-z]+)',
      '(?<experiment>[A-Za-z]+)',
      '(?<label>[A-Z]+)',
      '(?<retentiontime>[0-9]+)',
      '?(?<comment>[A-Za-z0-9_]{0,40})\\.?.*'
    ), collapse='_'),
    hela=paste(c(
      '(?<date>[0-9]{8})',                          # 1 date
      '(?<machine>[A-Z]+[0-9])',                       # 2 machine
      '(?<institute>[A-Za-z]+)',                         # 3 institute
      '(?<group>[A-Za-z]+)',                         # 4 group
      '(?<barcode>[Hh][Ee][Ll][Aa])',                  # 5 hela keyword
      '(?<label>[A-Z]+)',                            # 6 label type
      '(?<amount>[0-9]+ng)',                          # 7 material
      '(?<retentiontime>[0-9]+)',
      '?(?<comment>[A-Za-z0-9_]{0,40})\\..*'  # 8 retention time 9 comments
    ), collapse='_'))
  result <- list(filename=filename,
                 date=date,
                 machine=machine,
                 institute=institute,
                 group=group,
                 barcode=barcode,
                 species=species,
                 experiment=experiment,
                 label=label,
                 retentiontime=retentiontime,
                 comment=comment,
                 amount=amount)
  class(result) <- append(class(result), 'RawFile')
  
  
  if(filename != '') {
    if(!grepl('.raw$', filename)) {
      result$rawfilename <- paste0(filename, '.raw')
    } else {
      result$rawfilename <- filename
    }
    
    result$fullname <- filename
    result$basename <- basename(filename)
    
    available_regexes <- names(regexes)
    matching_regexs <- sapply(regexes, function(x) regexpr(x, basename(filename), perl=TRUE) > 0)
    if(!any(matching_regexs)) {
      result$matching <- FALSE
      warning(sprintf('We could not find a regular expression for "%s". \nPlease use ?RawFile to manually set the values.',
                      filename), 
              call.=FALSE)
      warning(sprintf('If you expect this filename format more often, please contact m.dejung@imb.de to add it to the package.'), 
              call.=FALSE)
      return(result)
    }
    result$matching <- TRUE
    result$regextype <- available_regexes[matching_regexs][1]
    regex <- regexes[[available_regexes[matching_regexs][1]]] # using the first matching regex
    result$regex <- regex
    
    filename_df <- as.data.frame(
      parse.one(basename(filename),
                regexpr(regex, basename(filename), perl=TRUE)), 
      stringsAsFactors=FALSE)
    
    for(name in names(filename_df)) {
      result[name] <- filename_df[[name]]
    }
    
    if(file.exists(result$rawfilename) & !file.info(result$rawfilename)$isdir) {
      result$file_exists <- TRUE
      result$size <- file.size(result$rawfilename)/1024/1024
      result$timestamp <- file.mtime(result$rawfilename)
    } else {
      result$file_exists <- FALSE
      result$size <- NA
      result$timestamp <- NA
    }
  } else {
    result$filename <- NULL
  }
  return(result)
}

#' Helper function to extract the matching values from a regexes search.
#' 
#' @param res The string to match the result
#' @param result The result from the regexes search
parse.one <- function(res, result) {
  m <- do.call(rbind, lapply(seq_along(res), function(i) {
    if(result[i] == -1) return("")
    st <- attr(result, "capture.start")[i, ]
    substring(res[i], st, st + attr(result, "capture.length")[i, ] - 1)
  }))
  colnames(m) <- attr(result, "capture.names")
  m
}

#' Generic function to represent a RawFile object.
#' 
#' @param x the object to print
#' @param ... additional parameters
#' @export
#' @method print RawFile
print.RawFile <- function(x, ...) {
  if(!is.null(x$filename)) {
    print(x$rawfilename)
  } else {
    cat(sprintf('RawFile object was created manually with the following settings:\n'))
    if(x$date != '')          cat(sprintf('Date:          "%s"\n', x$date))
    if(x$machine != '')       cat(sprintf('Machine:       "%s"\n', x$machine))
    if(x$institute != '')     cat(sprintf('Institute:     "%s"\n', x$institute))
    if(x$group != '')         cat(sprintf('Group:         "%s"\n', x$group))
    if(x$barcode != '')       cat(sprintf('Barcode:       "%s"\n', x$barcode))
    if(x$species != '')       cat(sprintf('Species:       "%s"\n', x$species))
    if(x$experiment != '')    cat(sprintf('Experiment:    "%s"\n', x$experiment))
    if(x$label != '')         cat(sprintf('Label:         "%s"\n', x$label))
    if(x$retentiontime != '') cat(sprintf('Retentiontime: "%s"\n', x$retentiontime))
  }
}

#' Summary of the RawFile.
#' 
#' @param object The object for the summary
#' @param ... additional parameters
#' @export
#' @method summary RawFile
summary.RawFile <- function(object, ...) {
  cat(sprintf('Rawfile %s %s.\n', 
              object$rawfilename,
              ifelse(object$file_exists, 'exists', 'does not exist')))
  if(object$file_exists) {
    cat(sprintf('Filesize is %.2fMB and was created on %s.\n',
                object$size, object$timestamp))
  }
  cat(sprintf('Using %s regular expression type which %s.\n', 
              object$regextype,
              ifelse(object$matching, 'matched', 'did not match')))
}


#' New generic method for getParameter
#' @param x Object
#' @param parameter parameter to look for within the object
#' @export
getParameter <- function(x, parameter) UseMethod("getParameter")

#' Generic function to extract parameters of a raw file
#' 
#' @param x the RawFile object
#' @param parameter the parameter to extract
#' @export
#' @method getParameter RawFile
#' @examples 
#' raw_file <- RawFile('20150113_QEP1_IMB_CF_HeLa-500ng_hs_PR_SIL_120.raw')
#' getParameter(raw_file, 'date')
#' getParameter(raw_file, 'barcode')
getParameter.RawFile <- function(x, parameter) {
  if(parameter %in% names(x)) {
    if(x[[parameter]] == '') {
      message(sprintf('We could not extract "%s" RawFile name. The execution might fail.',
                      parameter))
    } else {
      return(x[[parameter]])
    }
  } else {
    message(sprintf('The following parameters are available: %s',
                    paste(names(x), collapse=', ')))
    stop(sprintf('"%s" is not a parameter within class "RawFile".',
                 parameter), call.=FALSE)
  }
}

