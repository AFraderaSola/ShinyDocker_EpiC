###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

#' Fucntion to create the PDF for the core facility
#' 
#' @param pdf_data return value of \code{getPdfSetup}
#' @param barcode some sample data
#' @export
createPdfs <- function(pdf_data, barcode) {
  error <- NULL
  pdfdir <- 'pdf'
  if (!file.exists(pdfdir)) {
    dir.create(pdfdir)
  }
  pdf_intern <- paste0("CFP_", barcode, "_intern")
  pdf_user <- paste0("CFP_", barcode)
  for(filename in pdf_data) {
    file.copy(filename,
              file.path(pdfdir, basename(filename)),
              overwrite=TRUE)
  }
  
  cwd <- getwd()
  result = tryCatch({
    setwd(pdfdir)
    cat(sprintf('switch to %s subfolder\n', pdfdir))
    usertempname <- sub('.Rnw', '', basename(pdf_data$user_temp))
    Sweave(basename(pdf_data$user_temp))
    tools::texi2dvi(paste0(usertempname, '.tex'), pdf = TRUE)
    file.copy(paste0(usertempname, '.pdf'),
              file.path(cwd, paste0(pdf_user, '.pdf')),
              overwrite=TRUE)
    
    cftempname <- sub('.Rnw', '', basename(pdf_data$cf_temp))
    Sweave(basename(pdf_data$cf_temp))
    tools::texi2dvi(paste0(cftempname, '.tex'), pdf = TRUE)
    file.copy(paste0(cftempname, '.pdf'),
              file.path(cwd, paste0(pdf_intern, '.pdf')),
              overwrite=TRUE)
  }, error = function(e) {
    print(e)
    if(getOption('cfpscripts.test_mode', FALSE)) {
      error(e)
    }
  }, finally = {
    cat('switch back to original working directory\n')
    setwd(cwd)
  })

}
