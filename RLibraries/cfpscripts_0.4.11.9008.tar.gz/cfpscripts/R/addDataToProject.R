###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

#' Copy a script file of this package to destination.
#'
#' @param from Path to txt files
#' @param name Some clear name for the project
#' @param to Where the data will be save within the working directory
#' @param specific_files If we only copy specific files listed in 'file_list'
#' @param file_list List of specific files to copy
#' @export
addDataToProject <- function(from, name, to='data',
                             specific_files=TRUE,
                             file_list=c('parameters.txt', 'summary.txt',
                                         'peptides.txt', 'evidence.txt',
                                         'proteinGroups.txt')) {
  if(!dir.exists(to)) dir.create(to)
  
  destination <- file.path(to, name)
  if(dir.exists(destination)) {
    stop(sprintf('Data named "%s" already exists!', name),
         '\nPlease define a different name.',
         call.=FALSE)
  } else {
    dir.create(destination)
  }
  
  files_to_copy <- list.files(from, full.names=TRUE)
  if(specific_files) {
    files_to_copy <- grep(paste(file_list, collapse='|'),
                          files_to_copy,
                          value=TRUE)
  }
  
  files_copied <- file.copy(files_to_copy, destination)
  
  if(!all(files_copied)) {
    warning(sprintf('Some files could not be copied to "%s": ', destination),
            paste(files_to_copy[!files_copied], collapse=', '),
            call.=FALSE)
  } else {
    message(sprintf('%d files where copied into %s', 
                    sum(files_copied), destination))
  }
  
  md5sum_df <- data.frame(
    files=c(files_to_copy, list.files(destination, full.names=TRUE)),
    md5sum=tools::md5sum(c(files_to_copy, list.files(destination, full.names=TRUE)))
  )
  write.table(md5sum_df, file.path(destination, 'md5sum.txt'), 
              row.names=FALSE, sep='\t')
  
  write.table(data.frame(
    parameter=c('timestamp','from','destination'),
    values=c(as.character(Sys.time()),  from, file.path(getwd(),destination))
  ), 
  file.path(destination, 'copy_parameters.txt'), 
  row.names=FALSE, sep='\t')
  
  
  
  
  
}

