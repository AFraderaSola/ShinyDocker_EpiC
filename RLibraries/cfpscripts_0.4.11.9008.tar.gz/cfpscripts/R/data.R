###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

#' Example data for SILAC trible label experiment without label switch.
#' 
#' Within the list are 4 different data frames, read from txt files within 
#' MaxQuant txt/ results folder. Please use \code{attach} to directly access 
#' the different data frames.
#' 
#' @format A list of 4 dataframes, representing the important files from a
#' MaxQuant analysis.
#' \describe{
#'   \item{pg}{proteinGroups.txt file with all protein groups information}
#'   \item{summary}{summary.txt file with a summary of the experiment}
#'   \item{peptides}{peptides.txt file with peptides information}
#'   \item{parameters}{parameters.txt file with paramters settings in MQ}
#' }
"silac_trible_label_for"


#' Example data for SILAC double label experiment with label switch (forward 
#' and reverse experiment.
#' 
#' Within the list are 4 different data frames, read from txt files within 
#' MaxQuant txt/ results folder. Please use \code{attach} to directly access 
#' the different data frames.
#' 
#' @format A list of 4 dataframes, representing the important files from a
#' MaxQuant analysis.
#' \describe{
#'   \item{pg}{proteinGroups.txt file with all protein groups information}
#'   \item{summary}{summary.txt file with a summary of the experiment}
#'   \item{peptides}{peptides.txt file with peptides information}
#'   \item{parameters}{parameters.txt file with paramters settings in MQ}
#' }
"silac_double_label_for_rev"
