###############################################################################
#
# Functions to load a globalOption and return an example string.
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

#' Getting options and returning a help in case of missing variables
#' 
#' @param option A variable string used in getOption()
#' @param example An example line to define the optin
#' @param stop_if_null Call stop if option is not set
#' @export
#' @examples
#' getGlobalOption('MAXQUANTCMD', 
#'                 'options(MAXQUANTCMD="path/to/MaxQuantCmd.exe")', 
#'                 FALSE)
getGlobalOption <- function(option, example=NULL, stop_if_null=TRUE) {
  my_option <- getOption(option)
  if(is.null(my_option)) {
    message(sprintf('There is no "%s" option specified in ".Rprofile".\n',
                    option),
            sprintf('Please make sure to provide the file ".Rprofile" in "%s".',
                    path.expand('~')))
    if(!is.null(example)) {
      message(sprintf('This should have at least a line "%s".',
                      example))
    }
    if(stop_if_null) {
      stop(sprintf('%s is not defined in "%s".', 
                   option, file.path(path.expand('~'), '.Rprofile')), call.=FALSE)
    }
  } else {
    return(my_option)
  }
}
