###############################################################################
#
# These functions are commonly used on a daily basis.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.4
# date: 2018.02.13
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################



#' This function will search for some directories we do not really need within a
#' MaxQuant analysis and it deletes them to save hard drive space.
#' @export
#' @param workdir The directory we will search for MQ folders to delete
#' @param dont_delete_pattern A file name, if existing, we ignore the folder
#' @param exclude_regex A regex of folder to exclude
#' @examples
#' scriptEraseUnusedMQFolders()
#' scriptEraseUnusedMQFolders(workdir='E:/2016')
scriptEraseUnusedMQFolders <- function(workdir='D:/', 
                                 dont_delete_pattern='Dont_delete.txt', 
                                 exclude_regex='automated_hela') {
  folders <- list.dirs(workdir)
  
  folders_to_ignore <- folders[file.exists(file.path(folders, dont_delete_pattern)) | 
                                 grepl(exclude_regex, folders)]
  
  if(length(folders_to_ignore) > 0) {
    folders_not_ignored <- folders[-grep(paste(folders_to_ignore,collapse='|'), folders)]
  } else {
    folders_not_ignored <- folders
  }
  
  cfpscripts::deleteUnusedMQFolders(folders_not_ignored)
  
  cat('\nChecking ignored folders for DML IC subfolders.\n')
  still_to_remove <- 
    grep('IC_', 
         grep(paste(folders_to_ignore, collapse='|'), folders, value=TRUE), 
         value=TRUE)
  
  cfpscripts::deleteUnusedMQFolders(still_to_remove)
}


#' This function will create Folders for selected Acid Digestion files.
#' @export
#' @param files_regex A regex to search for files.
#' @param enzyme_list List of enzymes, acid digestion needs to be last!
#' @examples 
#' scriptCreateBIStructure()
scriptCreateBIStructure <- function(files_regex='*._BI_.*\\.raw$',
                                    enzyme_list=c('Trypsine', 'GluC', 'Acid_Digestion')) {
  bi_files <- list.files('.', files_regex)
  
  if(length(bi_files) < 2) {
    cat('Not enough files for BAND IDENTIFICATION with acid digestion found.\n')
    return(invisible(NULL))
  }
  printNumbering <- function(my_vector) {
    for(i in seq_along(my_vector)) {
      cat(sprintf("% d %s\n", i, my_vector[i]))
    }
  }
  
  cat("List of available digestion enzymes:\n")
  printNumbering(enzyme_list)
  cat("\n\nPlease select an enzyme together with a corresponding file separated by space.\nMultiple files need to be separated by ';'\n")
  printNumbering(bi_files)
  bi_string <- strsplit(strsplit(readline("'e.g. 1 12;3 13' so 12 is the Trypsin file and 13 the acid digestion: "), ';')[[1]], ' ')
  
  selected_bi_files <- as.numeric(sapply(bi_string, '[', 2))
  used_barcodes <- as.numeric(unlist(sapply(lapply(bi_files[selected_bi_files], 
                                                   cfpscripts::RawFile), '[','barcode')))
  new_id <- 
    sprintf('_%04d-%04d_', range(used_barcodes)[1], range(used_barcodes)[2])
  new_folder <- 
    sub('\\.raw$', '', sub('_\\d{4}_', new_id, bi_files[as.numeric(bi_string[[1]][2])]))
  dir.create(new_folder)
  
  files_to_copy <- c()
  for(s in bi_string) {
    folder_name <- enzyme_list[as.numeric(s[1])]
    file_name <- bi_files[as.numeric(s[2])]
    dir.create(file.path(new_folder, folder_name))
    if(as.numeric(s[1]) == length(enzyme_list)) {
      file.rename(file_name, file.path(new_folder, folder_name, file_name))
      file.copy(files_to_copy,
                file.path(new_folder, folder_name, basename(files_to_copy)))
    } else {
      files_to_copy <- c(files_to_copy, file.path(new_folder, folder_name, file_name))
      file.rename(file_name, file.path(new_folder, folder_name, file_name))
    }
  }
}



#' This function creates for each raw file a folder with the same name
#' @export
#' @param workdir The directory to search for files and create the directories
#' @param pattern The pattern to search for files
#' @examples 
#' scriptCreateFoldersFromRawFiles()
scriptCreateFoldersFromRawFiles <- function(workdir='.', 
                                            pattern='*.raw') {
  files <- list.files(workdir, pattern=pattern) 
  if(length(files) > 0) {
    for(file in files) {
      folder <- sub('.raw', '',file)
      cat(sprintf('"%s" folder is created!\n', folder))
      dir.create(folder)
      file.rename(from=file,to=file.path(folder,file))
    }
  } else {
    cat(sprintf('There are now %s-files in "%s"\n',pattern,getwd()))
  }
}


