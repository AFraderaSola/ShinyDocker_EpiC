###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

#' Setting up a PDF variable with analysis related templates
#' 
#' This function creates a variable with some settings to choose the correct
#' template for creating pdfs of the analysis. The function supports the 
#' following \emph{analysis} methods:
#' 
#' \itemize{
#'  \item \code{SILAC_IC} this will return the correct templates for a silac 
#'  incorporation script.
#'  \item \code{SILAC_FOR_REV} this setting will return the templates for a 
#'  silac forward and reverse experiment.
#' }
#' 
#' @param analysis one of SILAC_IC, SILAC_FOR_REV, SILAC_FOR, DML_FOR_REV,
#' DML_FOR
#' @param temp_version use an alternative template version. Only use if you know
#' what you are doing. Ex. '0.1.1'
#' @export
#' @examples
#' pdf <- getPdfSetup('SILAC_IC')
getPdfSetup <- function(analysis=NULL, temp_version='') {
  if(is.null(analysis)) {
    stop('You have to provide the analysis method, please read the help!')
  }
  file_path <- system.file('extdata', package='cfpscripts')
  pdf <- list()
  pdf$style <- file.path(file_path,"Sweave.sty")
  pdf$logo <- file.path(file_path,"imb_logo.png")
  switch(analysis,
         SILAC_IC={
           pdf$user_temp <- file.path(file_path,
                                      "incorporation_check_USER_template.Rnw")
           pdf$cf_temp <- file.path(file_path, 
                                    "incorporation_check_CF_template.Rnw")},
         
         SILAC_FOR_REV={
           pdf$user_temp <- file.path(file_path,
                                      "LABELED_for_rev_USER_template.Rnw")
           pdf$cf_temp <- file.path(file_path, 
                                    "SILAC_for_rev_CF_template.Rnw")
           pdf$tables <- file.path(file_path,'tables_for_rev.pdf')
           pdf$excel <- file.path(file_path,
                                  'importing_text_files_in_an_excel_sheet.pdf')},
         
         DML_FOR_REV={
           pdf$user_temp <- file.path(file_path,
                                      "LABELED_for_rev_USER_template.Rnw")
           pdf$cf_temp <- file.path(file_path, 
                                    "SILAC_for_rev_CF_template.Rnw")
           pdf$tables <- file.path(file_path,'tables_for_rev.pdf')
           pdf$excel <- file.path(file_path,
                                  'importing_text_files_in_an_excel_sheet.pdf')},
         SILAC_FOR={
           pdf$user_temp <- file.path(file_path,
                                      "SILAC_ONLY_for_USER_template.Rnw")
           pdf$cf_temp <- file.path(file_path, 
                                    "SILAC_for_rev_CF_template.Rnw")
           pdf$tables <- file.path(file_path,'tables_ONLY_for.pdf')
           pdf$excel <- file.path(file_path,
                                  'importing_text_files_in_an_excel_sheet.pdf')},
         SILAC_FOR_TRIPLE={
           pdf$user_temp <- file.path(file_path,
                                      "SILAC_ONLY_for_TRIPLE_USER_template.Rnw")
           pdf$cf_temp <- file.path(file_path, 
                                    "SILAC_for_rev_CF_template.Rnw")
           pdf$tables <- file.path(file_path,'tables_SILAC_FOR_TRIPLE.pdf')
           pdf$excel <- file.path(file_path,
                                  'importing_text_files_in_an_excel_sheet.pdf')},
         warning(sprintf('"%s" is an unknown string by now.\n', analysis),
                 call.=FALSE)
  )
  if(temp_version != '') {
    user_temp <- sub('.Rnw$', sprintf('_%s.Rnw', temp_version), pdf$user_temp)
    ifelse(file.exists(user_temp),
           pdf$user_temp <- user_temp,
           warning(sprintf('There is no version "%s" available for %s.',
                           temp_version,
                           pdf$user_temp), call.=FALSE))
    cf_temp <- sub('.Rnw$', sprintf('_%s.Rnw', temp_version), pdf$cf_temp)
    ifelse(file.exists(user_temp),
           pdf$cf_temp <- cf_temp,
           warning(sprintf('There is no version "%s" available for %s.',
                           temp_version,
                           pdf$cf_temp), call.=FALSE))
  }
  return(pdf)
}
