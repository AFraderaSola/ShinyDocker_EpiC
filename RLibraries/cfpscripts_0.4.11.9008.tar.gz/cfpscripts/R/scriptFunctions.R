###############################################################################
#
# Functions to copy the correct script to your working directory.
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

#' Copy a script file of this package to destination.
#'
#' @param filename The filename of the script to copy
#' @param destination A folder to copy the file. Will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @import rMQanalysis
copyScriptFile <- function(filename, destination, dbg_level) {
  if(!file.exists(destination)) dir.create(destination)

  jnk <- file.copy(system.file(filename, package='cfpscripts'),
                   file.path(destination, basename(filename)),
                   overwrite=TRUE)
  if(jnk) {
    rMQanalysis::mylog(sprintf('Copy "%s" script to %s.',
                basename(filename),
                ifelse(destination == '.', 'your working directory',
                       paste0('"',destination,'"'))),
        dbg_level=dbg_level)
  } else {
    stop(sprintf('File %s not found', filename), call.=FALSE)
  }
  return(file.path(destination, basename(filename)))
}

#' Copies a SILAC script to your working directory
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.SILAC.script <- function(destination='.', dbg_level=0) {
  .Deprecated('a.LABELED.script',
              msg='We are about to remove the SILAC/DML scripts and encourage to use the universal "a.LABELED.script" function.')
  copyScriptFile('SILAC-DML_with_PDF.R', destination, dbg_level)
}

#' Copies a script to handel DML or SILAC labeled IPs or whole proteomes.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.LABELED.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('LABELED_with_PDF.R', destination, dbg_level)
}

#' Copies a SILAC IncorporationCheck script to your working directory
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.SILAC_IC.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('SILAC_INCORPORATION_CHECK_with_pdf.R', destination, dbg_level)
}

#' Different statistics script for QEP usage for UCM etc. CONSTANT DEVELOPMENT!
#' 
#' I somehow lost track on the different statistic scripts. Need to clean this
#' up a little in the future.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.YAERLY_STATS.script <- function(destination='.', dbg_level=0) {
  result <- c(
    copyScriptFile(file.path('stats','massspec_stats.Rmd'), destination, dbg_level),
    copyScriptFile(file.path('stats','qep1_stats.R'), destination, dbg_level),
    copyScriptFile(file.path('stats','year_stats.Rmd'), destination, dbg_level),
    copyScriptFile(file.path('stats','yearly_UCM_analysis.Rmd'), destination, dbg_level)
  )
  return(result)
}

#' Copies a DML script to your working directory
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.DML.script <- function(destination='.', dbg_level=0) {
  .Deprecated('a.LABELED.script',
              msg='We are about to remove the SILAC/DML scripts and encourage to use the universal "a.LABELED.script" function.')
  copyScriptFile('SILAC-DML_with_PDF.R', destination, dbg_level)
}

#' Copies a script to erase unused MQ folders to your working directory
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.RemoveUnusedMQFolders.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('erase_unused_MQ_folders.R', destination, dbg_level)
}

#' Copies a BAND IDENTIFICATION script to your working directory
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.BAND_IDENTIFICATION.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('BAND_IDENTIFICATION.R', destination, dbg_level)
}

#' Copies a hplc sequence creator script to your working directory
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.HPLC_sequence_creator.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('hplc_sequence_creator.R', destination, dbg_level)
}

#' Copies a createFoldersFromRawFiles script to your working directory
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.createFoldersFromRawFiles.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('createFoldersFromRawFiles.R', destination, dbg_level)
}

#' A file which loops over several DML folder and does the IC.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.LOOP_DML_prepare_IC.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('LOOP_DML_prepare_IC.R', destination, dbg_level)
}

#' Copies a DML_create_folder_start_MQ script to your working directory for 
#' preparing DML Incorporation check
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.DML_prepare_IC.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('DML_create_folder_start_MQ.R', destination, dbg_level)
}

#' Copies a maintenance analysis script used for HeLa analysis after MS 
#' maintenance into the working directory.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.HeLa_maintenance_analysis.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('maintenance_analysis.R', destination, dbg_level)
}

#' Copies a DML_incorporation_check script to your working directory AFTER 
#' \code{a.DML_prepare_IC.script()}
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.DML_IC.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('DML_incorporation_check.R', destination, dbg_level)
}

#' Copies a script to install recommended packages to your working directory.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.RECOMMENDED_PACKAGES.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('recommended_packages.R', destination, dbg_level)
}


#' Script to compare fasta file entries and give a little graphical report.
#' 
#' This script needs the table with counts for each fasta file and compares the
#' them related on the fasta file name. Will work for our CF files.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.COMPARE_FASTA_ENTRIES.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('compare_fasta_file_entries.R', destination, dbg_level)
}


#' This script searches through the raw data and extract all peaks for specific
#' masses (HELM AG)
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.MoverZ_SEARCH.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('mz_search.R', destination, dbg_level)
}


#' Copies a IP NON SILAC script to your working directory 
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.IP_NON_SILAC.script <- function(destination='.', dbg_level=0) {
  .Deprecated('non at the moment')
  copyScriptFile('CFP_R-Script_IP_NON-SILAC.R', destination, dbg_level)
}

#' Copies a PR or IP SILAC with for and rev script to your working directory 
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.PR_IP_SILAC_for_rev.script <- function(destination='.', dbg_level=0) {
  .Deprecated('a.SILAC.script')
  mylog(sprintf('a.PR_IP_SILAC_for_rev.script is DEPRICATED and will be REPLACED BY a.SILAC.script in the FUTURE!\n'),
        dbg_level=dbg_level)
  copyScriptFile('CFP_R-Script_PR_AND_IP_SILAC_for_and_rev_Mario.R', destination, dbg_level)
}

#' Copies a NON SILAC script for MULTIPLE files to your working directory 
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.NON_SILAC_MULTIPLE.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('NON-SILAC_multiple_files.R', destination, dbg_level)
}

#' Copies a NON SILAC script for SINGLE file to your working directory 
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.NON_SILAC_SINGLE.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('NON-SILAC_one_file.R', destination, dbg_level)
}

#' Calculates statistics for FASTA files within a folder. DEVELOPMENT!
#'
#' This script is used to count the sequences in fasta files. We use this for
#' the core facility databases to get the final number and check if we have a
#' mixture of different species in a single file.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.FASTA_STATISTICS.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('report_fasta_file_entries.R', destination, dbg_level)
}

#' Automated GSEA analysis. DEVELOPMENT!
#'
#' This script uses the gsea-3.0.jar to make a GSEA for preranked files.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.GSEA_automated.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('auto_GSEA.R', destination, dbg_level)
}

#' Download all fasta files from uniprot website
#'
#' This script is used to download all species from the uniprot website and
#' name the output files properly.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.DOWNLOAD_UNIPROT_FASTAS.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('download_protein_databases.R', destination, dbg_level)
}

#' Create billing for the running quarter
#'
#' This script will create a html file while reading the user_sample_submission.xlsx
#' file and will creater a quarterly statistics. You can copy and paste the 
#' quarterly data directly into excel.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.BILLING.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('billing.Rmd', destination, dbg_level)
}

#' DEV Version! Analysing DML or SILAC Labels in replicates. 
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.DML_multiple_replicates.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('DML_multiple_replicates.R', destination, dbg_level)
}

#' Copies a script to read MS2 information from Raw files to your working directory 
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.MS2readout.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('ms2readout.R', destination, dbg_level)
}

#' Copies a script to run Max Quant on multiple raw files with the same settings.
#' 
#'  This script is used at the moment to run TMT samples automatically but can 
#'  be adapted to run on other samples as well 
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.MQ4all.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('mq4all.R', destination, dbg_level)
}

#' A script to extract fastq sequences in a very dirty way!
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.EXTRACT_FASTQ_SEQUENCES.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('extract_fastq_sequences.R', destination, dbg_level)
}

#' A script to in silico digest a fasta file
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.IN_SILICO_DIGESTING.script <- function(destination='.', dbg_level=0) {
  copyScriptFile('insilico_digestion.R', destination, dbg_level)
}

#' Multi species script to start MQ and create a global proteinGroups and 
#' peptides file.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.MULTI_SPECIES.script <- function(destination='.', dbg_level=0) {
  result <- c()
  result <- c(result, copyScriptFile(file.path('multi_species','mqpar_template.txt'), destination, dbg_level))
  result <- c(result, copyScriptFile(file.path('multi_species','01_multi_species_start_MQ.R'), destination, dbg_level))
  result <- c(result, copyScriptFile(file.path('multi_species','02_lfq_analysis.R'), destination, dbg_level))
  return(result)
}

#' Copies a LFQ analyis script and additional files to your working directory 
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.LFQ_ANALYSIS.script <- function(destination='.', dbg_level=0) {
  result <- c()
  result <- c(result, copyScriptFile(file.path('lfq_analysis','DEPRECATED_010_main_lfq_analysis.Rmd'), destination, dbg_level))
  result <- c(result, copyScriptFile(file.path('lfq_analysis','highlight.txt'), destination, dbg_level))
  result <- c(result, copyScriptFile(file.path('lfq_analysis','NEWS.txt'), destination, dbg_level))
  result <- c(result, copyScriptFile(file.path('lfq_analysis','label_free_analysis.R'), destination, dbg_level))
  return(result)
}

#' Copies scripts for automated hela analysis into your working directory 
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.AUTOMATED_HELA.script <- function(destination='.', dbg_level=0) {
  .Deprecated('a.HELA_and_QUEUE.script',
              'We changed these functions to the complete MQ queue scripts.')
  a.HELA_and_QUEUE.script(destination=destination, dbg_level=dbg_level)
}

#' Copies scripts for automated hela analysis and the MQ queue into your working 
#' directory 
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @export
a.HELA_and_QUEUE.script <- function(destination='.', dbg_level=0) {
  base_folder <- 'hela_and_queue'
  result <- c()
  result <- c(result, copyScriptFile(file.path(base_folder,'01_HeLa_file_analyser.R'),
                                     destination, dbg_level))
  result <- c(result, copyScriptFile(file.path(base_folder,'02_HeLa_automated_maintenance.R'),
                                     destination, dbg_level))
  result <- c(result, copyScriptFile(file.path(base_folder,'03_HeLa_file_mover.R'),
                                     destination, dbg_level))
  result <- c(result, copyScriptFile(file.path(base_folder,'example.Rprofile'),
                                     destination, dbg_level))
  result <- c(result, copyScriptFile(file.path(base_folder,'email_regex.R'),
                                     destination, dbg_level))
  result <- c(result, copyScriptFile(file.path(base_folder,'mq_queue_script.R'),
                                     destination, dbg_level))
  # result <- c(result, copyScriptFile(file.path(base_folder,'watch_threads.R'),
  #                                    destination, dbg_level))
  # result <- c(result, copyScriptFile(file.path(base_folder,'watch_queue.R'),
  #                                    destination, dbg_level))
  return(result)
}


#' Copy ALL scripts from this package into a folder.
#' @param destination Path to copy, will be created if it not exist.
#' @param dbg_level Change to 1 or higher to prevent messages.
#' @import utils
#' @export
copyAllScripts <- function(destination='.', dbg_level=0) {
  function_regex <- 'a\\.(.*)\\.script'
  function_list <- grep(function_regex, ls('package:cfpscripts'), value=TRUE)
  for(func in function_list) {
    filenames <- get(func)(destination=destination, dbg_level=dbg_level)
    if(length(filenames) > 1) {
      folder_name <- file.path(destination, sub(function_regex, '\\1', func))
      if(utils::compareVersion(paste(unlist(R.Version()[c('major','minor')]), collapse='.'), 
                        '3.2.0') < 0) {
        dir.create(folder_name, showWarnings=FALSE)
      } else {
        if(!dir.exists(folder_name)) dir.create(folder_name)
      }
      for(filename in filenames) {
        file.rename(filename, 
                    file.path(destination, basename(folder_name), basename(filename)))
      }
    }
  }
  writeLines('\n', 
             file.path(destination, 
                       sprintf('___these scripts are created by cfpscripts version %s___', 
                               utils::packageVersion("cfpscripts"))))
}



