#' Quick recursive file search on windows and unix
#' 
#' @param path a single path or a vector with multiple paths
#' @param pattern a search pattern in shell style, so just * for wildcard
#' @export
#' @examples 
#' quickFileSearch(c('Z:\\massspec','Y:','X:'), '*_MA_*_HeLa_*')
#' quickFileSearch(c("/Volumes/massspec/massspec", 
#'                   "/Volumes/massspec3"),
#'                   '*_MA_*_HeLa_*')
quickFileSearch <- function(path, pattern) {
  switch (.Platform$OS.type,
          unix={
            paths <- paste(path, collapse=' ')
            command <- paste('find', paths, '-name', pattern)
            system(command, intern=TRUE)
          },
          windows={
            paths <- paste(file.path(path, pattern, 
                                     fsep='\\'),
                           collapse=' ')
            command <- paste('dir', paths, '/b /s /a-d')
            result <- shell(command, intern=TRUE)
            result <- result[grep(gsub('\\*','\\.\\*', pattern),
                                  result)]
            }
  )
}

