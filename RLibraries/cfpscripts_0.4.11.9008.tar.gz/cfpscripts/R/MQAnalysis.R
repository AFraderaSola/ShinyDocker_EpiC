###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

#' Copy the analysis script into the working directory
#' 
#' This function checks the working directory and tries to interpret the 
#' experiment type (SILAC, DML, etc) and copies the correct analysis script 
#' into the working directory. This file can now be edited in the prefered way
#' (setting variables etc) and then be executed.
#' 
#' In case the interpretation of the experiment fails, you still can define the
#' experiment by hand, please check the examples below.
#' @import rMQanalysis
#' @param experiment Which kind of experiment
#' @param destination The destination where to copy the file
#' @export
#' @examples 
#' MQAnalysis('SIL') # will copy a SILAC analysis script into working directory
#' MQAnalysis('DML', 'my_directory')
MQAnalysis <- function(experiment=NULL, destination='.') {
  experiments <- list(
    SIL=function() { 
      message('SIL') 
      result <- list(filename='SILAC-DML_with_PDF.R')
    },
    DML=function() { 
      message('DML') 
      result <- list(filename='SILAC-DML_with_PDF.R')
    }
  )
  if(is.null(experiment)) {
    stop(sprintf('MQAnalysis needs the experiment parameter defined at the moment.'),
         call.=FALSE)
  } else {
    if(!experiment %in% names(experiments)) {
      stop(sprintf('"%s" is an unknown condition type, please use one of "%s".\n',
                   experiment, names(experiments), collapse=', '),
           call.=FALSE)
    }
    result <- experiments[[experiment]]()
  }
  if(!file.exists(destination)) dir.create(destination)
  jnk <- file.copy(system.file(result$filename, package='cfpscripts'), 
            file.path(destination, result$filename))
}

