###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

#' Check which MaxQuant processes are currently running.
#' 
#' This function returns a data frame with a count of currently running data
#' frames. It will count the number of command line processes, the number of
#' started GUIs and also just sums the running tasks which can be more then the
#' sum of cmd and impl.
#' 
#' Since MaxQuant is only running under windows. This function will return NULL
#' if you execute it on Linux or Windows.
#' @export
processingData <- function() {
  if(.Platform$OS.type != 'windows') {
    warning('processingData() is only working in a windows environment.')
    return()
  }
  processor_load <- NULL
  while(length(processor_load) != 2) {
    processor_load <- 
      system(
        'typeperf "\\Processor(_Total)\\% Processor Time" \"\\Prozessorinformationen(_Total)\\Prozessorauslastung\" -sc 1', 
        intern=TRUE)[2:3]
    con <- textConnection(processor_load)
    processor_load <- read.csv(con)
  }
  
  running_tasks <- system('tasklist /fo CSV', intern=TRUE)
  con <- textConnection(running_tasks)
  running_tasks <- read.csv(con)
  
  return(data.frame(date=as.POSIXct(strptime(processor_load[1,1], '%m/%d/%Y %H:%M:%S')),
                    cpu_load=processor_load[1,2],
                    maxquantcmd=length(grep('MaxQuantCmd|MAXQUA~1.EXE',running_tasks[[1]])),
                    maxquantimpl=length(grep('MaxQuantImpl',running_tasks[[1]])),
                    maxquanttask=length(grep('MaxQuantTask',running_tasks[[1]])),
                    maxquantALL=length(grep('MaxQuant',running_tasks[[1]]))))
}

#' Count the number of finished proteinGroups.txt files within a given folder
#' list.
#' 
#' This function can be used to check if a MaxQuant analysis is already done
#' or at least the proteinGroups.txt file already exist. It is also possible to
#' change the file name.
#' @param folders a vector mit folder names to list the files
#' @param filename a filename or regular expression
#' @return A number of files found.
#' @export
#' @examples 
#' subfolders <- list.dirs(path=file.path('path','to','files'))
#' file_count <- countFinishedAnalysis(subfolders)
countFinishedAnalysis <- function(folders, filename='proteinGroups.txt') {
  length(list.files(folders, filename, recursive=TRUE))
}






