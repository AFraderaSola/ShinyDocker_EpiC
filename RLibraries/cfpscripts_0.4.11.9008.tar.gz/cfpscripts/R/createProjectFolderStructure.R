#' Function to create standard folder structure
#' 
#' By executing this function we create a "data" and "scripts" directory which 
#' should be used to be compatible with future scripts.
#' @export
#' @param additional_folders Folders to create next to standard folders
createProjectFolderStructure <- function(additional_folders=NULL) {
  folders_to_create <- c('data', 'scripts', additional_folders)
  for(folder in folders_to_create) {
    if(!dir.exists(folder)) {
      dir.create(folder)
      message(sprintf('Folder "%s" created.', folder))
    }
  }
}
