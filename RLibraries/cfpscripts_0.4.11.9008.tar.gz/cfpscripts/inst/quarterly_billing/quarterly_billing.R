
library(dplyr)
library(tidyr)
library(zoo)
library(lubridate)

working_quarter <- '2020 Q3'
out_dir <- file.path('inst','quarterly_billing',working_quarter)
if(!dir.exists(out_dir)) dir.create(out_dir)

working_quarter_long <- sub('(\\d+) Q(\\d)', '\\1_Quartal_\\2', working_quarter)
special_cost_center <- 
  list(
    `QEP 1+2`=c(G09=.5, G10=.35, cf12=.15),
    `QEP 1`=c(G10=.7, cf12=.3),
    `QEP 2`=c(G09=1)
  )


# files -------------------------------------------------------------------
folder_path <- '/Volumes/groups/'
consumables_file <- file.path(folder_path, 'Inventur','MS_consumables2020.xlsx')
silac_file <- file.path(folder_path, 'Inventur','Lagerabrechnung2020.xlsx')
uss_file <- file.path(folder_path, 
                      '_CF Proteomics User samples',
                      'User Sample submission.xlsx')


# Consumables -------------------------------------------------------------



consumables <- xlsx::read.xlsx(consumables_file, 1, stringsAsFactors=FALSE)
consumables_df <- 
  consumables %>%
  as_tibble() %>% 
  filter(!is.na(cost.center)) %>%
  mutate(index=1:n(),
         price=as.numeric(price),
         Quarter=zoo::as.yearqtr(Date)) %>%
  left_join(tibble(factor=special_cost_center, 
                   cost.center=names(special_cost_center)) %>% 
              unnest_longer(factor) %>%
              rename(account=factor_id), 
            by='cost.center') %>%
  mutate(account=ifelse(is.na(account), cost.center, account),
         factor=ifelse(is.na(factor), 1, factor),
         new_price=price * factor) 

consumables_df %>%
  filter(Quarter == working_quarter) %>%
  select(Quarter, Date, article, name, amount, price, factor, account, new_price) %>%
  print(n=50)

consumable_sum <- 
  consumables_df %>% 
  filter(Quarter == working_quarter) %>%
  group_by(Quarter, account, factor) %>% 
  summarise(`Gesamt Kosten`=sum(new_price),
            `Kosten/Sample/Chip`=sum(price),
            Leistung='mass spec consumables') %>%
  rename(`Zu Lasten Kostenstelle`=account,
         Anzahl=factor) %>%
  mutate(Leistungsdatum_text=sprintf('%s - %s', 
                                 as.Date.yearqtr(Quarter), 
                                 as.Date.yearqtr(Quarter + 0.25) - 1)) %>%
  ungroup()



# SILAC reagents ----------------------------------------------------------


silac <- xlsx::read.xlsx(silac_file, 1, stringsAsFactors=FALSE, startRow=4)
silac_prices <- xlsx::read.xlsx(silac_file, 3, stringsAsFactors=FALSE)

silac_prices_df <- 
  silac_prices %>%
  filter(Comment=='current') %>%
  mutate(Product=make.names(Product)) %>%
  select(Product, Price)

silac_df <- 
  silac %>%
  as_tibble() %>% 
  filter(!is.na(Account)) %>%
  mutate(index=1:n(),
         Quarter=zoo::as.yearqtr(Date)) %>%
  pivot_longer(DMEM..SILAC.:RPMI, names_to='Product', values_to='count') %>%
    drop_na(count) %>%
  left_join(silac_prices_df, 
            by='Product') %>%
  mutate(new_price=Price * count) 

silac_df %>%
  filter(Quarter == working_quarter) %>%
  select(Quarter, Date, Product, count, Price, Account, new_price) %>%
  print(n=50)

silac_sum <- 
  silac_df %>% 
  filter(Quarter == working_quarter) %>%
  mutate(Account=ifelse(Account == 'EXT', 'extern', Account),
         Gruppe=ifelse(Account == 'extern', Full.Name, NA)) %>%
  group_by(Quarter, Account, Gruppe) %>%
  summarise(`Gesamt Kosten`=sum(new_price),
            `Kosten/Sample/Chip`=sum(new_price),
            Anzahl=1,
            Leistung='SILAC consumables') %>%
  rename(`Zu Lasten Kostenstelle`=Account) %>%
  mutate(Leistungsdatum_text=sprintf('%s - %s', 
                                 as.Date.yearqtr(Quarter), 
                                 as.Date.yearqtr(Quarter + 0.25) - 1)) %>%
  ungroup()

silac_sum_special <- 
  silac_df %>% 
  filter(Quarter == working_quarter,
         grepl('[D|G]\\d\\d\\d+', Account)) %>%
  group_by(Date, Account) %>%
  summarise(`Gesamtkosten`=sum(new_price),
            `Kosten`=sum(new_price),
            Anzahl=1,
            Leistung='MS Service') %>%
  rename(`Zu Lasten`=Account,
         Leistungsdatum=Date) %>%
  ungroup()

# Massspec measurement time -----------------------------------------------

ms_prices <- 
  xlsx::read.xlsx2(uss_file,
                   sheetName='billing',
                   colClasses=c('Date', 'Date', 'character', 'character', 'numeric'),
                   stringsAsFactors=FALSE) 
ms_prices_df <- 
  ms_prices %>%
  as_tibble() %>%
  mutate(End=if_else(is.na(End), as.Date(lubridate::today()), as.Date(End)),
         interval=lubridate::interval(Start, End))


column_types <- 
  c('Date', 'character', 'character', 'character', 'character', 'Date', 
    'character', 'character', 'character', 'character', 'character', 
    'character', 'Date', 'character', 'character', 'Date', 'Date', 
    'character', 'character', 'character')
uss <- 
  xlsx::read.xlsx2(uss_file,
             sheetName='sample submission', 
             colClasses=column_types)
uss_df <- 
  uss %>%
  as_tibble() %>%
  select(Date, barcode, User, type, Label, MS.measured, 
         Service, MS.run, Account) %>%
  filter(barcode!='') %>%
  mutate(EXT=!grepl('^IMB_', barcode),
         Account2=ifelse(EXT, as.character(User), as.character(Account)),
         measure_quarter=zoo::as.yearqtr(MS.measured),
         hours=as.numeric(sub('h','',MS.run))) %>%
  left_join(ms_prices_df, by=c('Account2'='Account')) %>%
  filter(MS.measured %within% interval|is.na(interval)) %>%
  mutate(new_price=hours*Price.per.hour)




uss_sum <-
  uss_df %>%
  filter(measure_quarter == working_quarter) %>%
  group_by(measure_quarter, Account2, Groupleader, hours, Price.per.hour) %>%
  summarise(`Kosten/Sample/Chip`=unique(hours*Price.per.hour),
            Anzahl=n(),
            `Gesamt Kosten`=sum(new_price),
            Leistung=sprintf('mass spec run %sh', unique(hours)),
            `Zu Lasten Kostenstelle`=ifelse(unique(EXT), 'extern',Account2)) %>%
  rename(Quarter=measure_quarter,
         Gruppe=Groupleader) %>%
  mutate(Leistungsdatum_text=sprintf('%s - %s', 
                                 as.Date.yearqtr(Quarter), 
                                 as.Date.yearqtr(Quarter + 0.25) - 1)) %>%
  ungroup()


uss_sum_special <- 
  uss_df %>% 
  filter(measure_quarter == working_quarter,
         grepl('[D|G]\\d\\d\\d+', Account)) %>%
  group_by(MS.measured, Account2) %>%
  summarise(`Gesamtkosten`=sum(new_price),
            `Kosten`=unique(hours*Price.per.hour),
            Anzahl=n(),
            Leistung='MS Service') %>%
  rename(`Zu Lasten`=Account2,
         Leistungsdatum=MS.measured) %>%
  ungroup()








final_table <- 
  bind_rows(
    uss_sum %>% select(-Quarter), 
    silac_sum %>% select(-Quarter), 
    consumable_sum %>% select(-Quarter)
  ) %>%
  ungroup() %>% 
  mutate(Account=ifelse(grepl('[D|G]\\d\\d\\d+', `Zu Lasten Kostenstelle`), 
                        sub('([D|G]\\d\\d)\\d+', '\\1',`Zu Lasten Kostenstelle`), 
                        `Zu Lasten Kostenstelle` )) %>%
  left_join(ms_prices_df %>% 
              select(Groupleader, Account) %>%
              distinct(), 
            by='Account') %>%
  mutate(`Zu Gunsten Kostenstelle`='cf12',
         Gruppe=ifelse(is.na(Groupleader), Gruppe, Groupleader),
         Adresse=ifelse(is.na(Groupleader), '', 'IMB')) %>%
  select(Leistungsdatum_text, Gruppe, Adresse, Leistung, `Kosten/Sample/Chip`, Anzahl,
         `Gesamt Kosten`, `Zu Lasten Kostenstelle`, `Zu Gunsten Kostenstelle`)

xlsx::write.xlsx(final_table %>%
                   rename(Leistungsdatum=Leistungsdatum_text) %>%
                   as.data.frame(), 
                 file.path(out_dir, 
                           sprintf('%s_long.xlsx', working_quarter_long)),
                 row.names=FALSE)

xlsx::write.xlsx(final_table %>%
                   group_by(`Zu Lasten Kostenstelle`, G=Gruppe) %>%
                   summarise(Leistungsdatum_text=unique(`Leistungsdatum_text`),
                             `Gruppe`=unique(G),
                             Adresse=unique(Adresse),
                             Leistung='MS Service',
                             `Kosten/Sample/Chip`=sum(`Gesamt Kosten`),
                             Anzahl=1,
                             `Gesamt Kosten`=sum(`Gesamt Kosten`),
                             `Zu Gunsten Kostenstelle`=unique(`Zu Gunsten Kostenstelle`)
                             ) %>%
  select(names(final_table)) %>%
  rename(Leistungsdatum=Leistungsdatum_text) %>%
  as.data.frame(), 
                 file.path(out_dir, 
                           sprintf('%s.xlsx', working_quarter_long)),
  row.names=FALSE)


if(nrow(uss_sum_special) + nrow(silac_sum_special) > 0) {
  final_table_special <- 
    bind_rows(
      uss_sum_special, 
      silac_sum_special 
    ) %>%
    ungroup() %>% 
    mutate(Account=ifelse(grepl('[D|G]\\d\\d\\d+', `Zu Lasten`), 
                          sub('([D|G]\\d\\d)\\d+', '\\1',`Zu Lasten`), 
                          `Zu Lasten` ))%>%
    left_join(ms_prices_df %>% 
                select(Groupleader, Account) %>%
                distinct(), 
              by='Account') %>%
    mutate(`Zu Gunsten`='cf12',
           Gruppe=ifelse(is.na(Groupleader), Gruppe, Groupleader)) %>%
    select(Leistungsdatum, Gruppe, Leistung, `Kosten`, Anzahl,
           `Gesamtkosten`, `Zu Lasten`, `Zu Gunsten`)
  
  
  for(kostenstelle in unique(final_table_special$`Zu Lasten`)) {
    # special_kostenstelle <- unlist(special_kostenstellen[line,'Zu Lasten Kostenstelle'])
    special_subset <- 
      final_table_special  %>% 
      filter(`Zu Lasten` == kostenstelle) %>%
      mutate(Leistungsdatum=as.character(Leistungsdatum))
    special_kostenstelle_table <- 
      bind_rows(special_subset %>% mutate(Anzahl=as.character(Anzahl)),
                summarise(special_subset, 
                          Anzahl='Summe:',
                          Gesamtkosten=sum(Gesamtkosten))) %>%
      mutate(Kosten=ifelse(is.na(Kosten), NA, sprintf('%.2f €', Kosten)),
             Gesamtkosten=sprintf('%.2f €', Gesamtkosten)) %>%
      replace(is.na(.), '')
    rmarkdown::render('inst/quarterly_billing/word_test.Rmd',
                      output_file=sprintf('%s_%s.docx',
                                          working_quarter_long,
                                          kostenstelle), 
                      output_dir=out_dir)
  }
}






## TODO 
# for each extra grand we create a word file
# Export table to excel with column formating
# 



