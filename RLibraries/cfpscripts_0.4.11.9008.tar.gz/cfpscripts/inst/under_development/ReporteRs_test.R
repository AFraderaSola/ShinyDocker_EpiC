require(ReporteRs)
require(ggplot2)
library(dplyr)


myplot2 <- 
  ggplot(mtcars, aes(hp, disp)) +
  geom_point(aes(color=factor(cyl))) +
  geom_text(aes(label=rownames(mtcars))) +
  scale_color_discrete('cylinder')

# Create a new document
mydoc <- pptx(title="EVG demo", template='inst/under_development/template.pptx')

mydoc <-
  mydoc %>%
  addSlide("Title Slide") %>%
  addTitle("The ReportRs package") %>%
  addSubtitle('Mario Dejung')

mydoc <- 
  mydoc %>%
  addSlide("Title and Content") %>%
  addTitle("Again, a new package") %>%
  addParagraph(
    c('Why should I learn a new packages, I prefer to use scripts!',
      'What is so important on this package?'),
    stylename="BulletList") %>%
  addDate() %>%
  addPageNumber()

mydoc <- 
  mydoc %>%
  addSlide("Title and Content") %>%
  addTitle("R speaks Powerpoint") %>%
  addParagraph(
    c('It can create powerpoint presentations with a script.',
      'Actually it produced this presentation, have a look!'),
    stylename="BulletList") %>%
  addDate() %>%
  addPageNumber()

mydoc <- 
  mydoc %>%
  addSlide("Title and Content") %>%
  addTitle("Some ReporteRs code") %>%
  addParagraph(set_of_paragraphs(
    pot_img('~/Desktop/Screen Shot 2017-05-14 at 20.52.27.png', 
            6, 5))) %>%
  addDate() %>%
  addPageNumber()


myplot <- qplot(Sepal.Length, Petal.Length, 
                data=iris, color=Species, 
                size=Petal.Width, alpha=I(0.7) )
mydoc <- 
  mydoc %>%
  addSlide("Two Content") %>%
  addTitle("We can add figures") %>%
  addPlot(function() print(myplot), vector.graphic=TRUE) %>%
  addParagraph(
    c('And write some text related to the figures'),
    stylename='Bulletlist') %>%
  addDate() %>%
  addPageNumber()

mydoc <- 
  mydoc %>%
  addSlide("Title and Content") %>%
  addTitle("Nice, but...") %>%
  addParagraph(
    c('... who the hell wants to create a presentation with R?',
      'It can be done at least 5 times quicker by hand...',
      'Any advantages?!?'),
    stylename='Bulletlist') %>%
  addDate() %>%
  addPageNumber()

mydoc <- 
  mydoc %>%
  addSlide("Title and Content") %>%
  addTitle("The advantage") %>%
  addPlot(function() print(myplot2), vector.graphic=TRUE) %>%
  addDate() %>%
  addPageNumber()

writeDoc(mydoc, file="EVG_example.pptx")

