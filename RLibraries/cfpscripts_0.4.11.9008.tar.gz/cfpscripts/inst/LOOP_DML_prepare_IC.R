# Loop the DML prepare IC script
#
# This script will loop over several DML experiments and will prepare and start
# the MQ analysis. It needs to be executed basically on the drive with all DML
# folder (e.g. setwd('D:')). It also needs a DML_create_folder_start_MQ script
# (e.g. cfpscripts::a.DML_prepare_IC.script()).
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.1
# date: 2017.02.22
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

home_dir <- getwd()
all_folders <- list.dirs(recursive=FALSE)
dml_folders <- all_folders[grepl('_DML_', all_folders)]

cat(sprintf('[%d] %s\n', seq_along(dml_folders), dml_folders))
folder_numbers <- 
  readline('please use comma separated folder numbers (e.g. 1, 4, 7): ')

dml_folders <- 
  dml_folders[eval(parse(text=paste0('c(',folder_numbers,')')))]

for(i in seq_along(dml_folders)) {
  setwd(dml_folders[i])
  
  cat(sprintf('working in %s (%s/%s)\n', 
              dml_folders[i], i, length(dml_folders)))
  source(file.path(home_dir, 'DML_create_folder_start_MQ_stable.R'))
  source(file.path(home_dir, 'DML_incorporation_check.R'))
  
  setwd(home_dir)
}


