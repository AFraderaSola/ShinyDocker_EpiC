###############################################################################
#
# Execute these commands once you installed a new version of R and/or RStudio
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.9
# date: 2020.02.03
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

recommendted_packages <- c(
  'ggplot2',
  'plotly',
  'sp',
  'gridExtra',
  'seqinr',
  'stringr',
  'dplyr',
  'plyr',
  'markdown',
  'reshape2',
  'ShortRead',
  'Peptides',
  'XML',
  'logging',
  'NMF',
  'gplots',
  'RColorBrewer',
  'rjson',
  'splitstackshape',
  'GGally',
  'devtools',
  'zoo',
  'data.table',
  'tidyr',
  'coin',
  'xlsx',
  'logspline',
  'readr',
  'ggrepel',
  'sessioninfo', 
  'shiny',
  'shinythemes',
  'DT',
  'BiocManager',
  'VennDiagram',
  'heatmaply'
)

install.packages(recommendted_packages)

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install(c(
  'Gviz',
  'GenomicRanges',
  "biomaRt",
  'IHW'
))

getDependencies <- function(packs){
  dependencyNames <- unlist(
    tools::package_dependencies(packages = packs, db = available.packages(), 
                                which = c("Depends", "Imports"),
                                recursive = TRUE))
  packageNames <- union(packs, dependencyNames)
  packageNames
}

