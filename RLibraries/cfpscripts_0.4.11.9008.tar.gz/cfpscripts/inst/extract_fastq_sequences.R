###############################################################################
#
# Script to extract fastq sequences and creating a table of it.
# 
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.2
# date: 2017.06.06
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

setwd('/Volumes/massspec/_MS_DATA_OUT/Mario/hanna_basecalls2/')
tar_files <- list.files('/Volumes/massspec/_MS_DATA_OUT/Mario/hanna_basecalls2/BaseCalls/', 
                        'fastq.gz',
                        full.names=TRUE)

out_dir <- 'hanna'
if(!dir.exists(out_dir)) dir.create(out_dir)

all_seq <- data.frame()
all_seq_short <- data.frame()
for(tar_file in tar_files) {
  cat(sprintf('work on %s\n', tar_file))
  jnk <- readLines(gzfile(tar_file)) # read all lines of the fastq file
  jnk2 <- jnk[seq(2, length(jnk), 4)] # extract only the lines with the sequence
  # seq_rows <- c(seq_rows, jnk2)
  jnk3 <- as.data.frame(
    head(
      sort(table(substr(jnk2,6,154)), # we cutting off the first and last 5 nucleotides
           decreasing=TRUE),50) # sorting to have the highest number first
    )
  all_seq <- rbind(all_seq,
                   cbind(file=basename(tar_file), jnk3))
  all_seq_short <- rbind(all_seq_short,
                   cbind(file=basename(tar_file), head(jnk3,10)))
  write.table(jnk3, # write the data into a txt file
              file.path(out_dir, paste0(basename(tar_file), '.txt')),
              sep = '\t', row.names = TRUE)
}

seqinr::write.fasta(as.list(all_seq$Var1),
                    paste(gsub('imb-butter-\\d+-\\d+-\\d+-|Undetermined_|_001\\.fastq\\.gz','',all_seq$file), 
                          all_seq$Freq, rownames(all_seq), sep='_'),
                    file.path(out_dir, 'all_sequences.fasta'))


seqinr::write.fasta(as.list(all_seq_short$Var1),
                    paste(gsub('imb-butter-\\d+-\\d+-\\d+-|Undetermined_|_001\\.fastq\\.gz','',all_seq_short$file), 
                          all_seq_short$Freq, rownames(all_seq_short),  sep='_'),
                    file.path(out_dir, 'all_sequences_short.fasta'))





