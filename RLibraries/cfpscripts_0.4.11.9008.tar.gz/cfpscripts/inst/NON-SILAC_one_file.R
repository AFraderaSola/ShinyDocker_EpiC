###############################################################################
#
# Script to do the analysis for a NON-SILAC experiment on the MaxQuant output 
# files.
#
# This script has to be executet within the folder with the raw files. So it 
# needs the folder with the "combined" folder in it. It will generate a 
# filtered proteinGroups file within this folder.
# 
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.4
# date: 2015.12.18
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################
rm(list = ls()) # remove most objects from the working environment
par(mfrow=c(1,1)) # reset number of graphs per image

library(rMQanalysis)
library(ggplot2)
library(gridExtra)

cat(paste0(getwd(),'\n'))

###############################################################################
# define some variables
data_directory <- file.path('combined','txt') # where are the txt files located
out_directory <- file.path('.')
# If you want to overwrite the name, use this variables here...
OVERWRITE_name <- ''
search_fasta_header <- c() 
FASTA_DB <- 'HUMAN.fasta'
fasta_basepath <- getGlobalOption('MQFASTADIR', 'options(MQFASTADIR="path/to/*.fasta")')
fasta_file <- file.path(fasta_basepath, FASTA_DB)

###############################################################################
# read some files
summary <- read.delim(file.path(data_directory,'summary.txt'))
proteinGroups <- read.delim(file.path(data_directory,'proteinGroups.txt'))
peptides <- read.delim(file.path(data_directory,'peptides.txt'))


###############################################################################
# read infos from the files
infile <- as.character(summary$Raw.file[-length(summary$Raw.file)])
if(length(infile) > 1 & OVERWRITE_name == '') {
  stop('There are several input files detected. Please use "OVERWRITE_name" to set a name.')
}
name <- 
  gsub('.*(\\d{8})_(\\w+)_(\\w+)_(\\w+_\\d{4,}.*)_(\\w+)_(\\w+)_(\\w+)_(\\w+)',
       '\\4',
       infile)

if(!OVERWRITE_name == '') name <- OVERWRITE_name
sample_data <- list(id=name)
# define the names for the outfiles
pG_identified_filename <- sprintf("proteinGroups_%s.txt",name)
pG_identified_flt_filename <- sprintf("proteinGroups_filtered_%s.txt",name)
png_outfile <- sprintf("sequence_coverage_%s.png",name)

###############################################################################
# filter the proteinGroups 
data <- filterWholeDataset(proteinGroups)
data_filtered <- filterIdentifiedProteins(data)

###############################################################################
# write this filtered dataset to a file
write.table_imb(data_filtered, 
                file=file.path(out_directory,pG_identified_filename))

###############################################################################
column_numbers <- c(
  grep('Fasta.headers',names(data_filtered)),
  grep('Protein.names',names(data_filtered)),
  grep('Gene.names',names(data_filtered)),
  grep('Unique.peptides',names(data_filtered)))

###############################################################################
# write this filtered dataset to a file
write.table_imb(data_filtered[column_numbers], 
                file=file.path(out_directory,pG_identified_flt_filename))

###############################################################################

# checking for missed Cleavage
# remove contaminants etc
peptides_filtered <- filterWholeDataset(peptides,by_bysite = FALSE)

# create data frame for the missed cleavage data
missed_cleavages_df <- getMissedCleavageDF(peptides_filtered)



par(mfrow=c(2,1))
hist(data_filtered$Sequence.coverage...., 
     main=sprintf("%s \nDistribution of %d proteingroups",
                  name, 
                  nrow(data_filtered)),
     xlab= "Sequence Coverage in %",
     ylab= "proteingroups",
     breaks = 50, 
     col='grey',
     xlim = c(0, 100))
missed_cleavages_df$pos <- barplot(missed_cleavages_df$amount, 
              names.arg=missed_cleavages_df$index, 
              col="grey", 
              ylim=c(0, 100),
              main="Missed cleavages in %")
text(missed_cleavages_df$pos, 
     median(missed_cleavages_df$amount) + 15, 
     missed_cleavages_df$round_amount, 
     cex=1,)
  
dev.copy(png,png_outfile)
dev.off()

if(length(search_fasta_header) >= 1) {
  search_string <- paste(search_fasta_header,collapse="|")
  cat(sprintf('\n\n\nsearching for the protein IDs "%s"\n', search_string))
  cat(sprintf('matching results in the FASTA DB:\n'))
  print(grep(search_string,
             readLines(FASTA_DB),
             ignore.case=TRUE,
             value=T))
  
  cat(sprintf('matching results in proteinGroups:\n'))
  search_results <- data_filtered[grep(search_string,
                                       data_filtered$Fasta.headers,
                                       ignore.case=TRUE),]  
  print(search_results$Fasta.headers)
}

