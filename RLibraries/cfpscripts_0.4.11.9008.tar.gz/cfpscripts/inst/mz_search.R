###############################################################################
#
# This script uses myML files to extract specific peaks of an MS2 spectra. It 
# creates also excel files with the extracted peak information.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.1.2
# date: 2019.02.22
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(mzR) #Readin mzML 
library(pracma) #Peaksearch
# options(java.parameters = "-Xmx4096m")
options(java.parameters = "-XX:+UseConcMarkSweepGC")
library(xlsx)
library(ggrepel)
library(rMQanalysis)

copySourcedScript()

# "c:\Program Files\ProteoWizard\ProteoWizard 3.0.11392\msconvert.exe" *.raw


mzfs <- 
  list.files('/Volumes/Proteomics-Data/2017/AG Helm-Patrick/2017-11-09/', pattern='.mzML', full.names=TRUE)

my_masses <- unique(c(316, 342, 571, 415, 341, 355, 577, 601, 343, 371, 396, 541, 557, 426, 338, 353, 386, 321,
                      328, 581, 318, 356, 345, 364, 541, 557, 470, 377, 487, 501, 441,
                      441))
accuracy <- .5 #Da
top_peaks <- 30
precursor_charges <- c(1) #Charge +1
min_intensity <- 1e4


for(mzf in mzfs) {
  ms <- openMSfile(mzf)
  hd <- header(ms)
  
  out_dir <- sub('\\.mzML$', '_corrected', mzf)
  if(!dir.exists(out_dir)) dir.create(out_dir)

  for(my_mass in my_masses) {
    matching_rows <- which(findInterval(hd$precursorMZ, 
                                        (my_mass + c(-accuracy, accuracy))) == 1)
    matching_spectra <- hd[matching_rows,]
    matching_spectra <- subset(matching_spectra, precursorCharge %in% precursor_charges)
    matching_spectra$retentionTimeMin <- matching_spectra$retentionTime / 60
    # write.table_imb(as.data.frame(matching_spectra), 
    #                 file.path(out_dir, sprintf('ms2_precursorMZ_search_%s.txt', my_mass)))
    
    if(nrow(matching_spectra) > 0) { 
      
      excel_wb <- xlsx::createWorkbook()
      main_mass_sheet <- 
        createSheetOfDF(excel_wb, 
                        as.data.frame(matching_spectra), 
                        sprintf('ms2 precursor search at %s', my_mass))
      
      pdf(file.path(out_dir, sprintf('ms2_precursorMZ_search_%s.pdf', my_mass)),
          width=11.69, height=8.27)
      
      for(line in seq(nrow(matching_spectra))) {
        rt <- matching_spectra[line, 'retentionTime'] / 60
        precursor_mz <- matching_spectra[line, 'precursorMZ']
        title <- sprintf('%.5f m/z @ %.2f min', precursor_mz, rt)
        my_peaks <- mzR::peaks(ms, matching_spectra[line, 'acquisitionNum'])
        peakhits <- findpeaks(my_peaks[,2], nups=3, ndown=3, npeaks=30, threshold=min_intensity, sortstr=TRUE)
        peakhits <- cbind(peakhits,NA, NA)
        for(i in seq(nrow(peakhits))) {
          peak <- my_peaks[peakhits[i,3]:peakhits[i,4],]
          df_peak <- as.data.frame(peak)
          names(df_peak) <- c('x', 'y')
          
          # use any model that nicely fits your data
          model <- tryCatch(mgcv::gam(y ~ s(x), data = df_peak),
                            error=function(e) NULL)
          if(is.null(model)) {
            peakhits[i,5:6] <- c(NA,NA)
            } else {
              df_peak$fitted <- predict(model)
              
              max_zone_x <- df_peak$x[tail(order(df_peak$fitted))]
              max_zone <- data.frame(x = seq(max_zone_x[1], max_zone_x[2], length.out = 1000))
              max_zone$y <- predict(model, max_zone)
              
              # plot(peak)
              # abline(v=unlist(max_zone[which.max(max_zone$y), ])[1])
              
              peakhits[i,5:6] <- unlist(max_zone[which.max(max_zone$y), ])
            }
            
          # tryCatch(
          #   {
          #     model <- mgcv::gam(y ~ s(x), data = df_peak)
          #     df_peak$fitted <- predict(model)
          #     
          #     max_zone_x <- df_peak$x[tail(order(df_peak$fitted))]
          #     max_zone <- data.frame(x = seq(max_zone_x[1], max_zone_x[2], length.out = 1000))
          #     max_zone$y <- predict(model, max_zone)
          #     
          #     # plot(peak)
          #     # abline(v=unlist(max_zone[which.max(max_zone$y), ])[1])
          #     
          #     peakhits[i,5:6] <- unlist(max_zone[which.max(max_zone$y), ])
          #   },
          #   error=function(e) {
          #     peakhits[i,5:6] <- c(NA,NA)
          #   }
          # )
        }
        # plot(my_peaks, type = "h", main=title, xlab='m/z', ylab='intensity')
        # points(my_peaks[,1][peakhits[,2]], my_peaks[,2][peakhits[,2]], col="red")
        # 
        
        file_name <- sprintf('%ssearch_%.5fmz_%.2fmin.txt', my_mass, precursor_mz, rt)
        # highest_peaks <- my_peaks[head(order(peaks(ms, matching_spectra[line, 'precursorScanNum'])[,2], decreasing=TRUE), top_peaks),]
        highest_peaks <- as.data.frame(my_peaks)
        highest_peaks_short <- cbind(highest_peaks[sort(peakhits[,2]),],
                                     peakhits[order(peakhits[,2]),5])
        names(highest_peaks_short) <- c('mass','intensity','corrected_mass')
        
        graph <- ggplot(as.data.frame(my_peaks), aes(V1, V2)) + 
          geom_line(alpha=.3) + 
          geom_point(data=highest_peaks_short, aes(mass, intensity), color='red') + 
          geom_text_repel(data=highest_peaks_short, aes(mass, intensity, label=sprintf('%.5f', mass)), size=3) + 
          ylab('intensity') + xlab('mass') + ggtitle(title) +
          theme_bw()
        print(graph)
        # write.table_imb(highest_peaks, file.path(out_dir, file_name))
        
        excel_title <- sprintf('%.5f mz @ %.2f min', precursor_mz, rt)
        main_mass_sheet <- 
          createSheetOfDF(excel_wb, highest_peaks_short, excel_title)
      }
      dev.off()
      xlsx::saveWorkbook(excel_wb, file.path(out_dir, sprintf('ms2_precursorMZ_search_%s.xlsx', my_mass)))
    }
  }
  
}



