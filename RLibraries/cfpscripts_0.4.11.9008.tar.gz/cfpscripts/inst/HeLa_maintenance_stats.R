###############################################################################
#
# This script is to automatically analyse all HeLa runs of QEP1 and QEP2.

# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.8
# date: 2016.09.27
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################



library(zoo)
library(ggplot2)
library(grid)
library(gridExtra)
library(scales)
library(rMQanalysis)



# Set global variables ----------------------------------------------------
rm('documentation')
# home_wd <- file.path('Z:','massspec','MA','automatic_hela_analysis')
# maintenance_script_path <- file.path('Z:','massspec','MA','automatic_hela_analysis')
home_wd <- file.path('/Volumes/massspec/massspec/MA/automatic_hela_analysis')
maintenance_script_path <- system.file('maintenance_analysis.R', 
                                       package='cfpscripts')

setwd(home_wd)
# data_dir <- file.path('E:') #'E:'for MaxQuant Server, 'S:'for private PC
data_dir <- file.path('/Volumes/Proteomics-Data/') #'E:'for MaxQuant Server, 'S:'for private PC
Search_dir <- c('2013','2014','2015','2016')

table_name <- 'HeLa MA statistic table_mac.txt'

#Cleaning Dates to show in Plot.
CleaningQEP1 <- c('','')

       #file.path('combined','txt','summary.txt')

# Set functions -----------------------------------------------------------

AddResultsToTable <- function(foldersToAddToDocument) {
  documentation <- data.frame()
  for (i in 1:length(foldersToAddToDocument)) {
    print(foldersToAddToDocument[i])
    result_filename <- file.path(foldersToAddToDocument[i],'results.txt')
    if(file.exists(result_filename)) {
        print('result found')
        resultFile <- read.delim(result_filename, stringsAsFactors=FALSE)
        rawfile_regex <- '([0-9]+)_([^_]+)_([^_]+)_([^_]+)_([^_]+)_([^_]+)_([^_]+)_([^_]+)'
        date <- sub(rawfile_regex,"\\1", resultFile$V1[1])
        machine <- sub(rawfile_regex,"\\2", resultFile$V1[1])
        concentration <- sub(rawfile_regex,"\\7", resultFile$V1[1])
        documentation <- rbind(documentation, data.frame(
          Date = as.factor(as.Date(date, '%Y%m%d')),
          Machine = machine,
          Conc = concentration,
          Rawfile = resultFile$V1[1],
          MS.MS.ID.rate = as.numeric(resultFile$V1[2]), 
          Peptides.Sequences.ID = as.numeric(resultFile$V1[3]),
          proteinGroups = as.numeric(resultFile$V1[4]),
          SILAC.proteinGroups = as.numeric(resultFile$V1[5]),
          Dir = foldersToAddToDocument[i]))
      }
  }
  return(documentation) 
}


# Find folderpath with specific experiments "HeLa" -------------------------------------------

folderpath_HeLa <- c()
for (folder in Search_dir) {
  foldername_HeLa <- dir(file.path(data_dir,folder), 
                         pattern='_MA_.*_HeLa_',
                         full.names=TRUE,
                         ignore.case=TRUE)
  folderpath_HeLa <- c(folderpath_HeLa, foldername_HeLa) #includes the whole filepath
}

# Check if folderpath_HeLa is already read in the Statistic table ----------------------------

if(file.exists(file.path(home_wd, table_name))) {
  cat('table found\n')
  #Load the table
  documentation <- read.delim(file.path(home_wd, table_name))
  #Remove folderoath which are already read in the table
  matching_folders <- match(folderpath_HeLa, documentation$Dir) 
  foldersToAddToDocument  <- folderpath_HeLa[is.na(matching_folders)] #subset of new HeLa folders
} else{
  documentation  <- data.frame()
  foldersToAddToDocument <- folderpath_HeLa # creates a table, because it didn't exist so far
}

# Check if folders have already results -----------------------------------

for (folder_path in foldersToAddToDocument) {
  cat(sprintf('\nworking in "%s"\n', folder_path))
  if(!file.exists(file.path(folder_path, 'results.txt'))) {
    setwd(folder_path)
    cat(sprintf('working in %s\n', getwd()))
    cat('Run MA script\n')
    try(source(maintenance_script_path))
  }
}

outputTable <- AddResultsToTable(foldersToAddToDocument) #Run function
documentation <- rbind(documentation, outputTable)
                                       
write.table(documentation, file.path(home_wd, table_name), sep = "\t",row.names = FALSE)

# Creating graphical analysis---------------------------------------------------

documentation$Date <- as.Date(documentation$Date)
documentation$Conc <- sub('58ng','50ng',documentation$Conc)
documentation$Conc <- sub('50ng_.*','50ng',documentation$Conc)
documentation$Machine  <- sub('QEP([1-9])_?.*', 'QEP\\1',documentation$Machine)


rectangles <- data.frame(
  xmin = seq(as.Date('2011-01-01'), Sys.Date(), by='+2 year'),
  xmax = seq(as.Date('2012-01-01'), Sys.Date() + 365, by='+2 year'),
  ymin = -Inf,
  ymax = Inf
)

instruments <- unique(documentation$Machine)
conc <- '50ng'

graph_list_peptides <- list()
graph_list_MSMS <- list()
graph_list_PG <- list()
Cleaning_df <- read.delim2(file.path(home_wd,'QEPs Cleaning, ITE, Repair etc.txt'), stringsAsFactors=FALSE)
Cleaning_df$Date <- as.Date(Cleaning_df$Date, '%d-%m-%Y')


for (instrument in instruments) {
  Cleaning <- subset(Cleaning_df, Machine == instrument & Type == 'Cleaning', stringsAsFactors=FALSE)
  ITE <- subset(Cleaning_df, Machine == instrument & Type == 'ITE', stringsAsFactors=FALSE)
  #as.numeric(levels(Value))[Value]))
  machine_conc_df <- subset(documentation, Conc == conc & Machine == instrument)
  max_y <- max(machine_conc_df$Peptides.Sequences.ID)
  
  graph <- 
    ggplot() + # first rectangle datas
    geom_line(data=machine_conc_df, # here we hand over the MA data
              aes(x=Date, y=Peptides.Sequences.ID),colour="#000066",size = 1) + 
    scale_x_date(date_breaks='2 month', date_minor_breaks='1 month',
                 labels=date_format("%b-%Y"),
                 limits = c(as.Date('2014-01-01'),date())) + 
    xlab(NULL) + ylab("Peptides Sequences Identification") + scale_y_continuous(limits=c(0, 13000)) +
    geom_rect(data=rectangles, aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax),
              fill="grey90", alpha=.4, na.rm=TRUE) +
    geom_vline(data=Cleaning, aes(xintercept = as.numeric(Date)), colour="#99CCFF", linetype="F1",size = 1) +
     
    ggtitle(sprintf("PeptideIDs of %s (%s HeLa standard)\n", instrument, conc)) + 
    theme(plot.title = element_text(lineheight=.8, face="bold")) +
    geom_hline(aes(yintercept=8000), colour="#FF3300", linetype="dashed",size = 1) +
    geom_hline(aes(yintercept=10000), colour="#669900", linetype="dashed",size = 1) +
    geom_point(data=ITE, aes(x=Date, y=as.numeric(Value)*2800), color='red', size=3, na.rm=TRUE) +
    geom_text(data=ITE[seq(nrow(ITE),1,-3),], 
              aes(x=Date, y=as.numeric(Value)*2800, label=Value), 
              vjust=0.5, hjust=-.1, angle=45) +
    theme_imb() +
    theme(axis.text.x  = element_text(angle=45, vjust=1, hjust=1))
  
  graph_list_peptides[[instrument]] <- graph
  
  graph <- ggplot() +
    scale_x_date(date_breaks='2 month', date_minor_breaks='1 month',
                 labels=date_format("%b-%Y"),
                 limits = c(as.Date('2014-01-01'),date())) + 
    xlab(NULL) + ylab("MSMS Identification rate") + scale_y_continuous(limits=c(0, 53) ) +
    geom_rect(data=rectangles, aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax),
              fill="grey90", alpha=.4, na.rm=TRUE) +
    geom_line(data=subset(documentation, Conc == conc & Machine == instrument), # here we hand over the MA data
              aes(x=Date, y=MS.MS.ID.rate, group=1),colour="#000066",size = 1, na.rm=TRUE) + geom_point(na.rm=TRUE) + 
    ggtitle(sprintf("MSMS ID rate of %s (%s HeLa standard)\n", instrument, conc)) + 
    theme(plot.title = element_text(lineheight=.8, face="bold")) +
    geom_hline(aes(yintercept=40), colour="#FF3300", linetype="dashed",size = 1) +
    geom_hline(aes(yintercept=45), colour="#669900", linetype="dashed",size = 1) +
    theme_imb() +
    theme(axis.title.x = element_text(),
          axis.text.x  = element_text(angle=45, vjust=1, hjust=1))
  
  graph_list_MSMS[[instrument]] <- graph
  
  graph <- ggplot() +
    scale_x_date(date_breaks='2 month', date_minor_breaks='1 month',
                 labels=date_format("%b-%Y"),
                 limits = c(as.Date('2014-01-01'),date())) + 
    xlab(NULL) + ylab("SILAC protein Groups") + scale_y_continuous(limits=c(0,2700)) +
    geom_rect(data=rectangles, aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax),
              fill="grey90", alpha=.4, na.rm=TRUE) +
    geom_line(data=subset(documentation, Conc == conc & Machine == instrument), # here we hand over the MA data
              aes(x=Date, y=SILAC.proteinGroups, group=1),colour="#000066",size = 1, na.rm=TRUE) + geom_point(na.rm=TRUE) + 
    ggtitle(sprintf("SILAC Protein Groups of %s (%s HeLa standard)\n", instrument, conc)) + 
    theme(plot.title = element_text(lineheight=.8, face="bold")) +
    geom_hline(aes(yintercept=1200), colour="#FF3300", linetype="dashed",size = 1) +
    geom_hline(aes(yintercept=1400), colour="#669900", linetype="dashed",size = 1) +
    theme_imb() +
    theme(axis.title.x = element_text(),
          axis.text.x  = element_text(angle=45,vjust=1, hjust=1))
  
  graph_list_PG[[instrument]] <- graph
}
setwd(home_wd)
g <- do.call(arrangeGrob,graph_list_peptides)
grid.newpage()
grid.draw(g)
ggsave(sprintf('Graph_HeLa_Statistics %s_peptideID.png', conc),g, width=15,height=10)

g <- do.call(arrangeGrob,graph_list_MSMS)
grid.newpage()
grid.draw(g)
ggsave(sprintf('Graph_HeLa_Statistics %s_MSMSID.png', conc),g, width=15,height=10)

g <- do.call(arrangeGrob,graph_list_PG)
grid.newpage()
grid.draw(g)
ggsave(sprintf('Graph_HeLa_Statistics %s_SILAC_pg.png', conc),g, width=15,height=10)


Sys.sleep(5)
mailR::send.mail(from=cfpscripts:::email_settings$from,
                 to='a.freiwald@imb.de',
                 subject="New HeLa statistics",
                 body='We found a new HeLa analysis and checked the quality',
                 smtp=cfpscripts:::email_settings,
                 authenticate=FALSE,
                 attach.files=list.files('.', pattern='Graph_'),
                 send=TRUE)


#save.image(file = "HeLastatistics.RData")
