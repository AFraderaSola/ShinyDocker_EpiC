###############################################################################
#
# Update the package version and date strings in all R files.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 1.0.0
# date: 2015-08-19
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################


library(rMQanalysis)

new_version <- '0.4.10'
new_date <- format(Sys.Date(), '%Y-%m-%d')
# new_date <- '2015-08-19'

r_files <- list.files(pattern='.*\\.R$|.*\\.Rnw$|.*\\.Rmd$', recursive=TRUE)
file_missing_version <- c()
for(f in r_files) {
  f_lines <- readLines(f)
  if(any(grepl('[#%>] package version:', f_lines))) {
    mylog(sprintf('Updating date and version in %s', f), dbg_level=0)
    f_lines <- sub('([#%>]) package version: .*$', 
                   sprintf('\\1 package version: %s', new_version), 
                   f_lines)
    f_lines <- sub('([#%>]) package date: .*$', 
                   sprintf('\\1 package date: %s', new_date), 
                   f_lines)
    writeLines(f_lines, f)
  } else {
    file_missing_version <- c(file_missing_version, f)
  }
}

f <- 'DESCRIPTION'
f_lines <- readLines(f)
mylog(sprintf('Updating date and version in %s', f), dbg_level=0)
f_lines <- sub('^Version: .*$', 
               sprintf('Version: %s', new_version), 
               f_lines)
f_lines <- sub('^Date: .*$', 
               sprintf('Date: %s', new_date), 
               f_lines)
writeLines(f_lines, f)

for(f in file_missing_version) {
  mylog(sprintf('File "%s" has no package version string!', f), dbg_level=0)
}




