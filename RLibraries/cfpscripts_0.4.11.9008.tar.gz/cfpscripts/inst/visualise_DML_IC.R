###############################################################################
#
# This script creates a graph of all DML incorporation checks within a folder.
#
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.2
# date: 2018.11.05
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################


library(tidyr)
library(dplyr)
library(ggrepel)
library(ggplot2)

library(tidyr)
library(dplyr)
library(ggrepel)
library(ggplot2)

setwd('D:/')

ic_tables <- list.files(pattern = 'incorporation_table.txt',
                        full.names = TRUE,
                        recursive = TRUE)

df <- bind_rows(
  lapply(ic_tables, read.delim, stringsAsFactors=FALSE), .id='folder'
)

mdf <- df %>%
  # filter(grepl('_RK_', barcode)) %>%
  # select(barcode, ends_with('peptides')) %>%
  mutate(barcode=factor(barcode), 
         experiment_color=as.factor(as.numeric(folder) %% 2)) %>%
  gather(key, value, -barcode, -experiment_color, -folder) %>%
  extract(key, c("label", "key"), "(.+)_(.+)")

# spread(key, value)
ggplot(mdf, 
       aes(as.numeric(barcode), value, color=label)) +
  geom_rect(aes(fill=experiment_color, ymin=-Inf, ymax=Inf,
                xmin=as.numeric(barcode)-.5, xmax=as.numeric(barcode)+.5),
            alpha=.1, color=NA) +
  geom_point(position = position_dodge(width=.4)) +
  # geom_bar(stat='identity', position = position_dodge(), width=.6) +
  geom_hline(data = data.frame(key = c('inc','peptides'),
                               y = c(95,NA)),
             aes(yintercept=y), color = 'red') +
  geom_text_repel(aes(label=round(value)), color='black', size=2) +
  scale_fill_manual(values=c(NA, 'grey'), guide=FALSE) +
  scale_x_continuous('experiment', 
                     breaks=as.numeric(mdf$barcode),
                     labels=mdf$barcode) +
  facet_wrap(~ key, scales = 'free_y') + theme_bw() +
  theme(axis.text.x = element_text(angle=90, vjust=.5),
        panel.grid.minor.x=element_blank())
ggsave('DML_IC.pdf', width=8.27, height=5.845)







