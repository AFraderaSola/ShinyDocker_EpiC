#
# package version: 0.4.10
# package date: 2018-05-25

#analysis ProteinGroups and Peptides
      
      rm(list = ls()) # remove most objects from the working environment

  # Experiment undiluted
#       setwd("W:/_CF Proteomics User samples/mass spec Files/20140423_QEP1_IMB_HR_0021_hs_IP_NON_120") # sets working directory
      getwd() # sets working directory
      name<-("IMB_HR_0056")
      proteinGroups_outfile <- paste0("proteinGroups_",name,".txt")
      png_outfile <- paste0("sequence_coverage_",name,".png")
      
  # ProteinGroup file loaded
      Groups <- read.delim("proteinGroups.txt")  # import the proteingroup file
      
      reverse <- if (any(is.na(Groups$Reverse))) TRUE else Groups$Reverse!='+'
      contaminant <- if (any(is.na(Groups$Potential.contaminant))) TRUE else Groups$Potential.contaminant!='+'
      identified <- if (any(is.na(Groups$Only.identified.by.site))) TRUE else Groups$Only.identified.by.site!='+'
      temp1 <- Groups[reverse & contaminant & identified,]
      
            
      a<-temp1[which(temp1$Razor...unique.peptides >= 2 & temp1$Unique.peptides >= 1 ),]
      # Writes filtered table      
        write.table(a, file=proteinGroups_outfile, row.names = FALSE, col.names = TRUE, append = FALSE, sep="\t", quote=F)
      b<-nrow(a)
      
#--Missed Cleavage--------------------------------------------------------------------------------------------------
      
      # Peptide file loaded
      peptides <- read.delim("peptides.txt")  # import file
      names(peptides)
      keeps <- c("Sequence","R.Count","K.Count","Missed.cleavages","Reverse","Potential.contaminant") #keeps columns in a table
      peptides<-peptides[keeps]
      reverse <- if (any(is.na(peptides$Reverse))) TRUE else peptides$Reverse!='+'
      contaminant <- if (any(is.na(peptides$Potential.contaminant))) TRUE else peptides$Potential.contaminant!='+'
      temp1 <- peptides[reverse & contaminant,]
      
      # Missed cleavages:
      MCA<-temp1[which(temp1$Missed.cleavages == 0),]
      MCA<-nrow(MCA)
      MCB<-temp1[which(temp1$Missed.cleavages == 1),]
      MCB<-nrow(MCB)
      MCC<-temp1[which(temp1$Missed.cleavages == 2),]
      MCC<-nrow(MCC)
      total<-MCA+MCB+MCC
      MCA<-c(MCA*100/total)
      MCB<-MCB*100/total
      MCC<-MCC*100/total
      
#----------------------------------------------------------------------------------------------------
  
      h<-(a$Sequence.coverage....)
      mp<-barplot(c(MCA,MCB,MCC), names.arg=c("0", "1", "2"), col="grey", ylim=c(0, 100),main="Missed cleavages in %")
      
      par(mfrow=c(2,1))
      hist(h, main=sprintf("%s \nDistribution of %d proteingroups",name, b),xlab= "Sequence Coverage in %",ylab= "proteingroups",
           breaks = 50, col='grey',xlim = c(0, 100))
      barplot(c(MCA,MCB,MCC), names.arg=c("0", "1", "2"), col="grey", ylim=c(0, 100),main="Missed cleavages in %")
      
      text(mp[1], MCA/2, round(MCA,1), cex=1)
      text(mp[2], MCB/2, round(MCB,1), cex=1)
      text(mp[3], MCC*10, round(MCC,1), cex=1)
  
      dev.copy(png,png_outfile)
      dev.off()
