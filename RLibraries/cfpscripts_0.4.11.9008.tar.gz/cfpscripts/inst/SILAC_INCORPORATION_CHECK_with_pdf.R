###############################################################################
#
# Script to do the incorporation check on the MaxQuant output files.
#
# This script has to be executet within the folder with the raw files. So it 
# needs the folder with the combined folder in it. It will generate two .pdf 
# files, one for the corefacility and one for the user. 
# 
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.2.1
# date: 2016.02.29
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

# global variable setting -------------------------------------------------
# Which packages do we need
library(rMQanalysis)
library(gridExtra)
library(grid)
library(ggplot2)
library(cfpscripts)

ignore_requantify <- FALSE
create_pdf <- TRUE
OVERWRITE_barcode <- ''

# Which variables do we have to set to run the script
data_directory <- file.path('combined','txt') # where are the txt files located
out_directory <- file.path('.')

peptides_filename <- 'peptides.txt'
parameters_filename <- 'parameters.txt'
summary_filename <- 'summary.txt'


# Text needs Latex Format, % has to be escaped by two "\". To make a newline
# you have to enter four "\". Ask Mario for help!
email_text_worked <- "Dear user,\\\\
The calculated incorporation rate for your sample %s is at least %.1f\\%%.\\\\
Your incorporation worked.\\\\

Thank you for using the Core Facility Proteomics."

email_text_problem <- "Dear user,\\\\
The calculated incorporation rate for your sample %s is at least %.1f\\%%.\\\\
\\textcolor{red}{\\textbf{Your incorporation is less than 95\\%% and didn't 
work.}}\\\\
Please make a Friday morning appointment to discuss further proceeding 
(proteomics@imb.de).
\\\\

Thank you for using the Core Facility Proteomics."


# read the data files -----------------------------------------------------

parameters <- read.delim(file.path(data_directory, parameters_filename))
summary <- read.delim(file.path(data_directory, summary_filename))
peptides <- read.delim(file.path(data_directory,peptides_filename))

# set runtime variables ---------------------------------------------------


# re-quantify check
re_quantify <- as.logical(parameters[parameters$Parameter == 'Re-quantify','Value'])
if(!ignore_requantify) {
  if(re_quantify) {
    stop('Re-quantify was set to TRUE! You can ignore_requantify if you want!',
         call.=FALSE)
  }
}

# read labels
if('Labels1' %in% names(summary)) {
  trimmed_labels <- as.character(summary$Labels1[summary$Labels1 != ''])
  if(length(trimmed_labels) > 1) {
    stop(sprintf('There are wrong labels defined in "%s"',
                 file.path(data_directory, summary_filename)), call.=FALSE)
  }
} else {
  stop(sprintf('There is no Labels1 column in the %s" file.',
               file.path(data_directory, summary_filename)), call.=FALSE)
}

# read enzyme
enzyme <- as.character(summary$Enzyme[summary$Enzyme != ''])

# read barcode
rawfile <- as.character(summary$Raw.file[summary$Raw.file != 'Total'])
if(length(rawfile) > 1) {
  stop('There is more then one raw file in the summary.', call.=FALSE)
}
barcode <- sub('\\d{8}_[^_]+_[^_]+_([^_]+_[^_]+)_[^_]+_[^_]+_[^_]+_[^_]+$', '\\1', rawfile)
if(OVERWRITE_barcode != '') {
  barcode <- OVERWRITE_barcode
}

# Set variables based on files we just read 
# file names, enzyme, sample barcode etc
# how to handle data which not fit this convention
# stop if re-quantify check fails


# missed cleavage analysis and plot ---------------------------------------

peptides_flt <- filterWholeDataset(peptides, by_bysite=FALSE)
mc_df <- getMissedCleavageDF(peptides_flt)
mc_plot <- plotMissedCleavages(mc_df, enzyme=enzyme) + theme_imb()
print(mc_plot)
ggsave(paste0('IC_', barcode, '_missed_cleavage.pdf'), mc_plot, width=5, height=5)

# incorporation analysis and histogram -------------------------------------------------

incorporation_datas <- list()
incorporation_graphs <- list()
for(label in strsplit(trimmed_labels, ';')[[1]]) {
  aa <- sub('\\d+', '', label)
  weight <- sub('[A-Za-z]+', '', label)
  inc_data <- getIncorporationRate(file.path(data_directory,peptides_filename),
                                   AA(aa, 'one'))
  incorporation_datas[[aa]] <- inc_data
  incorporation_datas[[aa]]$weight <- weight
  
  #################################################################
  # can be removed after installing imbprotemicsr >= 0.1.15
  aa_column <- paste0(AA(aa, 'one'), '.Count')
  incorporation_datas[[aa]]$aminoacid <- aa 
  my_subset <- 
    subset(peptides_flt, Intensity != 0 & Missed.cleavages == 0)
  my_subset <- my_subset[my_subset[,aa_column] == 1, ]
  incorporation_datas[[aa]]$n_peptides <- nrow(my_subset)
  #################################################################
  
  graph <- inc_data$graph +
    ggtitle(sprintf('Incorporation rate of %s-%s is %.2f%%', 
                    aa, weight, inc_data$value))
  incorporation_graphs[[aa]] <- graph
  cat(sprintf('Incorporation rate of %s-%s is %.2f%%\n', 
              aa, weight, inc_data$value))  
}
incorporation_graph <- do.call(arrangeGrob, incorporation_graphs)
grid.newpage()
grid.draw(incorporation_graph)
ggsave(paste0('IC_', barcode, '_incorporation_graph.pdf'), incorporation_graph, 
       width=5, height=5)


# pdf creation ------------------------------------------------------------

# use Marios strange and complicated function to write the PDF
# Think about a way to easily switch it of in case you do not need it

inc_lys <- ifelse(is.null(incorporation_datas$Lys), NA, incorporation_datas$Lys$value)
inc_arg <- ifelse(is.null(incorporation_datas$Arg), NA, incorporation_datas$Arg$value)

if(create_pdf) {
  pdf_data <- getPdfSetup('SILAC_IC')
  createPdfs(pdf_data, barcode)
}

# Some informations  ------------------------------------------------------

cat('\n\n\n')
print(mc_df)
for(ic in incorporation_datas) {
  cat(sprintf('Incorporation rate of %s-%s is %.2f%% with %s peptides.\n', 
              ic$aminoacid, ic$weight, ic$value, ic$n_peptides))
}
cat(sprintf("Re-quantify was set to '%s'.\n", 
            re_quantify))
