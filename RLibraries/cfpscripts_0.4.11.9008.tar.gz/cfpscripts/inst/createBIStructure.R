###############################################################################
#
# This script will create Folders for selected Acid Digestion files.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.2
# date: 2017.07.24
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(cfpscripts)

bi_files <- list.files('.', '*._BI_.*\\.raw$')

# Acid digestion need to be last!
enzyme_list <- c('Trypsine', 'GluC', 'Acid_Digestion')


printNumbering <- function(my_vector) {
  for(i in seq_along(my_vector)) {
    cat(sprintf("% d %s\n", i, my_vector[i]))
  }
}

cat("List of available digestion enzymes:\n")
printNumbering(enzyme_list)
cat("\n\nPlease select an enzyme together with a corresponding file separated by space.\nmultiple files need to be separated by ';'\n")
# printNumbering(bi_files)
printNumbering(bi_files)
bi_string <- strsplit(strsplit(readline("'e.g. 1 12;3 13' so 12 is the Trypsin file and 13 the acid digestion: "), ';')[[1]], ' ')

selected_bi_files <- as.numeric(sapply(bi_string, '[', 2))
used_barcodes <- as.numeric(unlist(sapply(lapply(bi_files[selected_bi_files], RawFile), '[','barcode')))
new_id <- 
  sprintf('_%04d-%04d_', range(used_barcodes)[1], range(used_barcodes)[2])
new_folder <- 
  sub('\\.raw$', '', sub('_\\d{4}_', new_id, bi_files[as.numeric(bi_string[[1]][2])]))
dir.create(new_folder)

files_to_copy <- c()
for(s in bi_string) {
  folder_name <- enzyme_list[as.numeric(s[1])]
  file_name <- bi_files[as.numeric(s[2])]
  dir.create(file.path(new_folder, folder_name))
  if(as.numeric(s[1]) == length(enzyme_list)) {
    file.rename(file_name, file.path(new_folder, folder_name, file_name))
    file.copy(files_to_copy,
              file.path(new_folder, folder_name, basename(files_to_copy)))
  } else {
    files_to_copy <- c(files_to_copy, file.path(new_folder, folder_name, file_name))
    file.rename(file_name, file.path(new_folder, folder_name, file_name))
  }
}


