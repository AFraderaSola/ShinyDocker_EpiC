###############################################################################
# This script starts MQ automatically and is not working within the Queue since
# it uses a newer version of MQ. 
# It should now be fixed and should not start all none labeled TMT at once.
#
# Version: 0.7
# Date: 2018.04.19
#
###############################################################################

parallel_processes <- 8
cores_per_job <- 1
secs_per_report <- 10

working_dir <- file.path('D:','TMT')
setwd(working_dir)
maxquant_cmd <- 'C:/Users/cfproteomics/Desktop/MaxQuant 1.6.0.1/bin/MaxQuantCmd.exe'
mqpar_template <- 
  c(
    'mqpar_TMT.xml',
    'mqpar_none.xml'
  )



printReport <- function() {
  if(loop_count %% 1 == 0) {
    cat('.')
  }
  if(loop_count %% 10 == 0) {
    cat(' ')
  }
  if(loop_count %% 60 == 0) {
    cat(sprintf('\n%s runningProcesses:%s waitingProcesses:%s\n',
                Sys.time(), 
                running_processes, 
                length(my_jobs) - length(done_jobs)))
  }
}


for (mqpar_temp in mqpar_template) {
  setwd(working_dir)
  my_jobs <- c()
  running_processes <- 0
  job_count <- 0
  loop_count <- 1
  
  cat(sprintf('\ncopy %s and raw files into directory\n', mqpar_temp))
  
  raw_files <- list.files(pattern='.raw')
  for(i in seq_along(raw_files)) {
    dir_name <- sub('.raw','',raw_files[i])
    if (!dir.exists(dir_name)) {
      dir.create(dir_name)
      file.copy(raw_files[i], file.path(dir_name, raw_files[i]))
    }
    
    mqpar <- readLines(mqpar_temp)
    raw_file_name <- file.path(getwd(), dir_name, raw_files[i])
    mqpar <- gsub('XXX_RAWFILE_XXX', 
                  gsub('/','\\\\\\\\',raw_file_name),
                  mqpar)
    mqpar_name <- file.path(getwd(), dir_name, 'mqpar.xml')
    my_jobs <- c(my_jobs, mqpar_name)
    writeLines(mqpar, mqpar_name)
  }
  
  
  file.remove(list.files(pattern='Finish_writing_tables.*txt', 
                         recursive=TRUE, 
                         full.names=TRUE))
  cat(sprintf('\nstarting MQ for %s\n', mqpar_temp))
  
  while(job_count < length(my_jobs)) {
    done_jobs <- list.files(pattern='Finish_writing_tables.*txt', 
                            recursive=TRUE, 
                            full.names=TRUE)
    
    if(running_processes - length(done_jobs) < parallel_processes) {
      job_count <- job_count + 1
      cmd <- sprintf('"%s" "%s"', maxquant_cmd, my_jobs[job_count])
      cat(sprintf('%s\n', cmd))
      system(cmd, wait=FALSE)
      running_processes <- running_processes + cores_per_job
    } 
    printReport()
    
    Sys.sleep(secs_per_report)
    
    loop_count <- loop_count + 1
  }
  done_jobs <- list.files(pattern='Finish_writing_tables.*txt', 
                          recursive=TRUE, 
                          full.names=TRUE)
  cat(sprintf('\nall MQ started for %s. waiting to finish\n', mqpar_temp))
  
  while(length(done_jobs) < length(my_jobs)) {
    done_jobs <- list.files(pattern='Finish_writing_tables.*txt', 
                            recursive=TRUE, 
                            full.names=TRUE)
    printReport()
    
    Sys.sleep(secs_per_report)
    loop_count <- loop_count + 1
  }
  
  cat(sprintf('\nMQ for %s finished, renaming txt folders to txt_%s\n', mqpar_temp,mqpar_temp))
  
  setwd(working_dir)
  cfpscripts::scriptEraseUnusedMQFolders(
    workdir = ".", 
    dont_delete_pattern = "Dont_delete.txt", 
    exclude_regex = "automated_hela"
  )
  
  rename <- grep('txt$', list.dirs(), value = TRUE)
  rename <- sub('/txt','', rename)
  rename <- sub('.',working_dir, rename)
  template <- sub('.xml','',sub('mqpar_','',mqpar_temp))
  
  for (i in rename) {
    setwd(i)
    file.rename('txt', paste0('txt_',template))
  }
  cat(sprintf('\n%s DONE\n', mqpar_temp))
}

raw_files_to_remove <- 
  list.files(
    grep('^\\./20', list.dirs(recursive=FALSE), value=TRUE), 
    '.raw$', 
    full.names=TRUE)

cat(sprintf('\nRemoving the following raw files:\n%s', paste(raw_files_to_remove, collapse='\n')))
file.remove(
  raw_files_to_remove
)
