###############################################################################
#
# Script to download all important fasta files from uniprot or ensembl database.
#
# It is also possible to load multiple taxonomiy IDs into a single file but it 
# is only recommended for species from the same genus like in Danaus plexippus, 
# which consists of 3 species.
# For some reason, the ftp download on Windows make some problems yet.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.2.4
# date: 2019.01.29
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(readr)
library(dplyr)

ref_proteomes <- read.delim('~/Downloads/proteomes-reference%3Ayes-2.tab') %>%
  as_tibble()
overwrite_date <- '20190116' # use something like '20170123'



UniprotSpecies <- function(scientific_name, tax_ids, name=NULL, comment=NULL, url=NULL) {
  file_name <- 
    sprintf('%s_%sUniprot_%s%s.fasta',
            gsub(' ', '_', scientific_name),
            ifelse(is.null(name), 
                   '', 
                   sprintf('(%s)_', gsub(' ', '', toupper(name)))),
            ifelse(is.null(comment), 
                   '', 
                   sprintf('(%s)_', gsub(' ', '_', comment))),
            ifelse(is.null(overwrite_date),
                   format(Sys.Date(), '%Y%m%d'),
                   overwrite_date))
  list(scientific_name=scientific_name,
       tax_ids=tax_ids, 
       name=name,
       file_name=file_name, 
       url=url)
}
EnsemblSpecies <- function(scientific_name, url, name=NULL, comment=NULL) {
  file_name <- 
    sprintf('%s_%sEnsembl_%s%s.fasta',
            gsub(' ', '_', scientific_name),
            ifelse(is.null(name), 
                   '', 
                   sprintf('(%s)_', gsub(' ', '', toupper(name)))),
            ifelse(is.null(comment), 
                   '', 
                   sprintf('(%s)_', gsub(' ', '_', comment))),
            ifelse(is.null(overwrite_date),
                   format(Sys.Date(), '%Y%m%d'),
                   overwrite_date))
  list(scientific_name=scientific_name,
       name=name,
       file_name=file_name, 
       url=url)
}

# defining the species to download ----------------------------------------

download_list <- list(
  UniprotSpecies('Arabidopsis thaliana', 3702, 'ARATH'),
  UniprotSpecies('Bombyx mori', 7091, 'Silk moth'),
  UniprotSpecies('Bos taurus', 9913, 'Bovine'),
  UniprotSpecies('Caenorhabditis elegans', 6239, 'CAEEL'),
  UniprotSpecies('Canis lupus', 9615, 'Dog'),
  # UniprotSpecies('Danaus plexippus', 13037, 'Monarch butterfly'),
  UniprotSpecies('Danaus plexippus', 
                 c(278856, 1699404, 278857), 
                 'Monarch butterfly'),
  UniprotSpecies('Danio rerio', 7955, 'Zebrafish'),
  UniprotSpecies('Daphnia magna', 35525),
  UniprotSpecies('Daphnia pulex', 6669),
  UniprotSpecies('Drosophila melanogaster', 7227, 'Fruit fly'),
  EnsemblSpecies('Drosophila melanogaster',
                 url='ftp://ftp.ensembl.org/pub/release-95/fasta/drosophila_melanogaster/pep/Drosophila_melanogaster.BDGP6.pep.all.fa.gz', 
                 name='Fruit fly', comment='release95'),
  UniprotSpecies('Escherichia coli', 83333, 'Ecoli', 'strain K12'),
  UniprotSpecies('Felis catus', 9685, 'Cat'),
  UniprotSpecies('Gallus gallus', 9031, 'Chicken'),
  UniprotSpecies('Homo sapiens', 9606, 'Human'),
  EnsemblSpecies('Homo sapiens',
                 url='ftp://ftp.ensembl.org/pub/release-95/fasta/homo_sapiens/pep/Homo_sapiens.GRCh38.pep.all.fa.gz', 
                 name='Human', comment='release95'),
  UniprotSpecies('Mus musculus', 10090, 'Mouse'),
  EnsemblSpecies('Mus musculus',
                 url='ftp://ftp.ensembl.org/pub/release-95/fasta/mus_musculus/pep/Mus_musculus.GRCm38.pep.all.fa.gz', 
                 name='Mouse', comment='release95'),
  UniprotSpecies('Murine leukemia virus', 
                 c(11786, 11791, 11795, 11801, 368798, 368797), 
                 'MULV'),
  UniprotSpecies('Neurospora crassa', 367110, 'Neurospora', 'strain ATCC 24698'),
  UniprotSpecies('Rattus norvegicus', 10116, 'Rat'),
  UniprotSpecies('Saccharomyces cerevisiae', 559292, 'Yeast', 'strain ATCC 204508'),
  UniprotSpecies('Schizosaccharomyces pombe', 284812, 'Schpo', 'strain ATCC 24843'),
  UniprotSpecies('Sus scrofa', 9823, 'Pig'),
  UniprotSpecies('Trichoplusia ni', 7111, 'Trini'),
  UniprotSpecies('Spodoptera frugiperda', 7108, NULL, 'SF9 cells'),
  UniprotSpecies('Platynereis dumerilii', 6359, 'Clam worm'),
  UniprotSpecies('Xenopus laevis', 8355, 'African clawed frog'),
  UniprotSpecies('Xenopus tropicalis', 8364, 'Western clawed frog'),
  UniprotSpecies('Human cytomegalovirus', 10360, 'HCMVA', 'strain AD169'),
  UniprotSpecies('Human cytomegalovirus', 10359, 'HCMV'),
  UniprotSpecies('Human cytomegalovirus', 10363, 'HCMVT', 'strain Towne'),
  UniprotSpecies('Full reviewed', NULL, 
                 url='http://www.uniprot.org/uniprot/?query=reviewed:yes&compress=no&format=fasta&include=yes')
)


# loop over the species to download ---------------------------------------
f <- function(x, pos) x[grepl('^>', x)]

for(species in download_list) {
  cat(sprintf('Start download for %s: ',
              species[['scientific_name']]))
  download_link <- 
    # sprintf('http://www.uniprot.org/uniprot/?compress=no&query=reviewed:no+AND+organism:%s&format=fasta&include=yes',
    ifelse(!is.null(species[['url']]),
           species[['url']],
           sprintf('http://www.uniprot.org/uniprot/?compress=no&query=organism:%s&format=fasta&include=yes',
            species[['tax_ids']]))
  download_files <- paste0(species[['file_name']], seq(length(download_link)))
  
  jnk <- download.file(download_link,
                       destfile=download_files, 
                       quiet=TRUE)
  complete_file <- do.call("c", lapply(download_files, function(file) {
    readLines(file)
  }))
  jnk <- file.remove(download_files)
  writeLines(complete_file, species[['file_name']])
  
  
  fdata <- unique(as.vector(
    readr::read_lines_chunked(species[['file_name']], 
                              readr::DataFrameCallback$new(f), 
                              chunk_size=50000,
                              progress=FALSE)))
  cat(sprintf('DONE with %d sequences\n',
              length(fdata)))
}


