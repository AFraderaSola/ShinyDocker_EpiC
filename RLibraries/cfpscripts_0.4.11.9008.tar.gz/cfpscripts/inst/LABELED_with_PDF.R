###############################################################################
#
# Script to analyse labeled data such as SILAC or DML. It works with forward
# only experiments, as well as with forward and reverse experiments. For the 
# later case, the raw files need to be defined different 'Experiment' values
# within MaxQuant (ex. for, rev). In case of tripple labeling, the script will
# compare each condition with the others.
#
# This script has to be executet within the main folder where the raw files 
# and the "combined" folder are. It will generate two .pdf files, one for the 
# corefacility and one for the user. Also the graphs get saved as .pdf files.
#
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.3.5
# date: 2020.10.22
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################


# .rs.restartR() # we need to restart R session before executing. Some Java issues
analysis_timestamp <- format(Sys.time(), '%Y%m%d%H%M%S')

library(ggrepel)
library(grid)
library(gridExtra)
library(tidyr)
library(dplyr)
# options(java.parameters = "-Xmx4096m")
options(java.parameters = c("-Xmx4096m", "-XX:+UseConcMarkSweepGC"))
library(xlsx)

library(rMQanalysis)
library(cfpscripts)

cat(sprintf('Working directory is set to: %s\n', getwd()))

# user settings -----------------------------------------------------------

bait_protein <- c() # use 'unprotID' not 'gene.name'
important_ids <- c() # use 'unprotID' not 'gene.name'
normalize <- TRUE
overwrite_sample_id <- ''
database_to_link <- 'uniprot' # can be 'uniprot', 'ensembl', or 'none'

# !!!
# to overwrite the selection in a single scater plot, use this code:
# clicked_list[[SCATTERPLOT_NUMBER]] <- my_highlights ; save(clicked_list, file=clicked_file)
# make sure to execute the script once before, otherwise my_highlights is empty
# !!!

# filtering 
min_peptides <- 2
min_razor_unique_peptides <- 2
unique_peptides <- 1
remove_contaminants <- TRUE
remove_only_by_site <- TRUE

# standard settings -------------------------------------------------------

# create analysis folder
# create timestamp_results folder
#TODO copy raw data into timestamp_results/raw
# create timestamp_results/results folder
# create timestamp_results/scripts folder
#TODO add parameters table to excel file
#TODO add package information to excel file
#TODO copy the results also in the working directory
#TODO change the compare_df to handle normalized and not normalized columns
#TODO overwrite sample numbers with nice labels
#TODO change everything to nice column names
#TODO the scatter_selection should work independent of normalisation T/F
#TODO selected and important proteins should have always the same color
#TODO add table of contaminants to the excel file

data_directory <- file.path('combined', 'txt') # where are the txt files located
out_directory <- file.path('.')
results_directory <- file.path(out_directory)
figures_directory <- file.path(results_directory, 'analysis_figures')
table_directory <- file.path(results_directory, 'output_tables')
raw_directory <- file.path(results_directory, 'raw_data')
scripts_directory <- file.path(results_directory, 'scripts')

for(directory in 
    c(out_directory, figures_directory, table_directory, 
      raw_directory, scripts_directory)) {
  if(!dir.exists(directory)) dir.create(directory)
}
copySourcedScript(scripts_directory)

thresholds <- c(2)
clicked_file <- 'clicked_data.RData'
scatter_selection_file <- 'scatter_selection.RData'
my_label_regex <- 'Ratio\\.(.)\\.(.)\\.(normalized\\.)?(.*)$'

# reading input files -----------------------------------------------------
mylog('Reading input files', dbg_level=0)
mq_summary <- MQSummary$new(file.path(data_directory, 'summary.txt'))
mq_parameters <- MQParameters$new(file.path(data_directory, 'parameters.txt'))
mq_peptides <- MQPeptides$new(file.path(data_directory,'peptides.txt'))
pg <- MQProteinGroups$new(file.path(data_directory, 'proteinGroups.txt'))

# in case we executed the script already and clicked something, we load the
# clicked data file.
if(file.exists(clicked_file))  {
  load(clicked_file)
} else {
  if('clicked_list' %in% ls()) {
    rm(clicked_list)
  }
}
if(file.exists(scatter_selection_file))  {
  load(scatter_selection_file)
} else {
  if('scatter_df' %in% ls()) {
    rm(scatter_df)
  }
}


# creating sample data list -----------------------------------------------

sample_barcodes <- unique(sapply(mq_summary$getRawFile(), function(x) {
  paste(RawFile(x)$group, RawFile(x)$barcode, sep='_')
}))


sample_data <- list(
  id = ifelse(overwrite_sample_id != '',
              overwrite_sample_id,
              paste(sample_barcodes, collapse='_')),
  enzymes = mq_summary$getEnzyme(),
  name = unname(sample_barcodes)
)



# names for output files --------------------------------------------------

table_filenames <- list(
  identified = sprintf("proteinGroups_%s.txt", sample_data$id),
  filtered = sprintf("proteinGroups_%s_filtered.txt", sample_data$id),
  indicated = sprintf("proteinGroups_%s_indicated.txt", sample_data$id),
  imputed = sprintf("proteinGroups_%s_imputed.txt", sample_data$id),
  ratio = sprintf("proteinGroups_%s_filtered_ratio.txt", sample_data$id),
  interesting_peptides = sprintf("peptides_%s_interesting.txt", sample_data$id)
)
table_filenames <- 
  setNames(as.list(file.path(table_directory, table_filenames)), 
           names(table_filenames))

figures_filenames <- list(
  missed_cleavage = sprintf('Missed_Cleavage_%s.pdf', sample_data$id),
  forhistogram = sprintf('Forward_Histogram_%s.pdf',sample_data$id),
  revhistogram = sprintf('Reverse_Histogram_%s.pdf',sample_data$id),
  scatterplot = sprintf('Scatterplot_%s.pdf',sample_data$id),
  abundanceplot = sprintf('Abundanceplot_%s.pdf',sample_data$id),
  pg_count = sprintf('pg_count_%s.pdf', sample_data$id),
  intensity_boxplot = sprintf('intensity_boxplot_%s.pdf', sample_data$id)
)
figures_filenames <- 
  setNames(as.list(file.path(figures_directory, figures_filenames)), 
           names(figures_filenames))

excel_filename <- sprintf('proteinGroups_%s.xlsx', sample_data$id)

# Missed Cleavage analysis ------------------------------------------------
mylog('Missed Cleavage analysis', dbg_level=0)
mq_peptides$filterData()
missed_cleavages_plot <- 
  plotMissedCleavages(mq_peptides$getMissedCleavageDF(), sample_data)
print(missed_cleavages_plot)

ggsave(figures_filenames$missed_cleavage,
       missed_cleavages_plot,
       width=6,height=6)



# interesting peptides ----------------------------------------------------
mylog('interesting peptides', dbg_level=0)
interesting_peptides <- mq_peptides$getPeptides(c(bait_protein, important_ids))
if(nrow(interesting_peptides) > 0) {
  write.table_imb(interesting_peptides,
                  table_filenames$interesting_peptides)
}



# protein counts after filtering ------------------------------------------
mylog('protein counts', dbg_level=0)
pg_df <- pg$getFilterCounts(mq_summary)
mylog(sprintf('We identified %d protein groups.', pg_df[4,2]), dbg_level=0)

# creating a nice figure
y_label_pos <- -max(pg_df$count) * 0.05
pg_count_graph <- ggplot(pg_df, aes(x=dataset, y=count)) + 
  geom_bar(stat='identity', na.rm=TRUE) +
  scale_y_continuous(limits = c(-max(pg_df$count) * 0.07, max(pg_df$count) * 1.1)) +
  geom_text(aes(label=count), y=y_label_pos, color='black', na.rm=TRUE) +
  ylab('protein groups') + xlab('filtering step') +
  ggtitle('protein groups after each filtering step') +
  theme(axis.text.x=element_text(angle=60, hjust=1, vjust=1))
print(pg_count_graph)
ggsave(figures_filenames$pg_count,
       pg_count_graph,
       width=6,height=6)


# Intensity boxplot per label ---------------------------------------------
mylog('intensity boxplot', dbg_level=0)
intensity_df <- 
  pg$getData()[grep('^Intensity(.*)', names(pg$getData()))] %>% 
  gather() %>%
  filter(value > 0) %>% 
  group_by(key) %>% 
  mutate(mean=mean(log2(value)))
max_mean_intensity <- 
  unlist(
    intensity_df %>%
      filter(grepl('Intensity\\.[HML]$', key)) %>%
      arrange(-mean) %>%
      ungroup() %>%
      slice(1) %>%
      select(mean))

prefered_order <- 
  c('Intensity',
    grep('Intensity\\.[^H|^M|^L]', unique(intensity_df$key), value=TRUE),
    grep('Intensity\\.[HML]$', unique(intensity_df$key), value=TRUE),
    grep('Intensity\\.L\\.', unique(intensity_df$key), value=TRUE),
    grep('Intensity\\.M\\.', unique(intensity_df$key), value=TRUE),
    grep('Intensity\\.H\\.', unique(intensity_df$key), value=TRUE))
intensity_df$key <- 
  factor(intensity_df$key, levels=prefered_order)
intensity_df$label <- gsub('Intensity\\.([HML]).*', '\\1', intensity_df$key)

intensity_boxplot <- 
  ggplot(intensity_df, 
         aes(key, log2(value), color=mean)) + 
  geom_point(size=.2, alpha=.3, position=position_jitter(width=.25)) + 
  geom_boxplot(alpha=.5, outlier.shape=NA) + 
  labs(title='Intensity per label',
       x='Label',
       y='log2(Intensity)') +
  theme_imb() + 
  scale_colour_gradientn(colours=c('red','yellow','green'), 
                         limits=c(max_mean_intensity-3,max_mean_intensity), 
                         oob = scales::squish) +
  scale_y_continuous(minor_breaks = seq(1:100)) +
  theme(axis.text.x=element_text(angle=90, hjust=1, vjust=.5))
print(intensity_boxplot)
ggsave(figures_filenames$intensity_boxplot,
       intensity_boxplot,
       width=8, height=6)


# Filtering the protein groups file ---------------------------------------
mylog('filtering pg file', dbg_level=0)
pg$setFilter(TRUE) # reset previous filter setting
pg$filterData(peptides=1, 
              razor_unique=1, 
              unique=unique_peptides,
              contaminants=remove_contaminants,
              by_site=remove_only_by_site)

pg_one_unique <- subset(pg$getData(), Razor...unique.peptides == 1)


pg$setFilter(TRUE) # reset previous filter setting
pg$filterData(peptides=min_peptides, 
              razor_unique=min_razor_unique_peptides, 
              unique=unique_peptides,
              contaminants=remove_contaminants,
              by_site=remove_only_by_site)

write.table_imb(pg$getData(),
                file=table_filenames$identified)



# formating the ratio columns ---------------------------------------------
mylog('formating columns', dbg_level=0)
log2_prefix <- 'log2.'
log2_df <- log2(pg$getData()[pg$getRatioColumnNames(normalized=normalize)])
log2_column_names <- paste0(log2_prefix, names(log2_df))
names(log2_df) <- log2_column_names
pg_ratios <- cbind(pg$getData(), log2_df)

# fill gene names ---------------------------------------------------------

genenames_to_add <- 
  pg_ratios$Gene.names == '' & 
  grepl(' GN=', sapply(strsplit(pg_ratios$Fasta.headers, ';'), '[[', 1))
pg_ratios$Gene.names[genenames_to_add] <- 
  sub('.* GN=([^ ;]+).*',
      'fasta:\\1', 
      sapply(strsplit(pg_ratios$Fasta.headers[genenames_to_add], ';'), '[[', 1))
pg_ratios$plot_label <- rMQanalysis::getLabel(pg_ratios, 
                                              'Gene.names', 'Protein.IDs', 
                                              '([^;]+).*', '([^;]+).*')


# column subset for filtered data set -------------------------------------

columns_to_keep_in_filtered <- 
  c("Protein.IDs", "Fasta.headers",
    grep("Protein.names", names(pg_ratios), value=TRUE),
    grep("Gene.names", names(pg_ratios), value=TRUE),
    "plot_label",
    grep("Peptide.counts.", names(pg_ratios), value=TRUE),
    "Mol..weight..kDa.","Sequence.length",
    switch(remove_contaminants + 1, 'Potential.contaminant', NULL),
    switch(remove_only_by_site + 1, 'Only.identified.by.site', NULL),
    pg$getRatioColumnNames(), pg$getRatioColumnNames(normalized=TRUE),
    grep("Sequence.coverage.", names(pg_ratios), value=TRUE),
    grep("Unique.peptides.", names(pg_ratios), value=TRUE),
    grep("Intensity\\.[HML]\\.", names(pg_ratios), value=TRUE),
    log2_column_names)

pg_ratio_filtered <- pg_ratios[columns_to_keep_in_filtered]

write.table_imb(pg_ratio_filtered, 
                file=table_filenames$filtered)




# histogram per condition -------------------------------------------------
mylog('create histograms', dbg_level=0)
graphsl_hist <- list()
for(i in seq_along(pg$getRatioColumnNames())) {
  column_name <- pg$getRatioColumnNames()[i]
  g <- rMQanalysis::createRatioHistogram(pg_ratios, column_name)
  column_name <- pg$getRatioColumnNames(normalized=TRUE)[i]
  gnorm <- rMQanalysis::createRatioHistogram(pg_ratios, column_name, normalized=TRUE)
  
  gbox <- createRatioBoxplot(pg_ratios, log2_column_names[[i]])
  
  my_label <- sub(my_label_regex, '\\1/\\2', column_name)
  title <- sub(my_label_regex, '\\4 \\1/\\2', column_name)
  
  histogram_plot <- arrangeGrob(g, gnorm, gbox, 
                                layout_matrix=rbind(c(1,3),c(2,3)), 
                                top=paste(title))
  
  grid.newpage()
  grid.draw(histogram_plot)
  ggsave(file.path(figures_directory,
                   paste0('histogram_', 
                          sub('^X','',make.names(title)), 
                          '_', 
                          sample_data$id, 
                          '.pdf')),
         histogram_plot,
         width=8,height=8)
  graphsl_hist[[
    paste(colnameToLabel(pg$getRatioColumnNames()[i]), my_label)]] <- 
    histogram_plot
}


# Ratio Scatter Plots -----------------------------------------------------
mylog('create ratio scatter plots', dbg_level=0)
graphsl_ratio_scatter <- list()
for(i in seq_along(pg$getRatioColumnNames())) {
  column_name <- pg$getRatioColumnNames()[i]
  my_label <- sub(my_label_regex, '\\1/\\2', column_name)
  title <- sub(my_label_regex, '\\4 \\1/\\2', column_name)
  error_appeared <- FALSE
  repeat{
    tryCatch({ # we put everything into a try catch block, because sometimes we get an error
      top_outlier <- maxOutliers(pg_ratios[[log2_column_names[i]]], upper_max=25, lower_max=25)
      gscat <- 
        ggplot(pg_ratios, aes_string(log2_column_names[[i]], 'Intensity')) + 
        geom_point(data=pg_ratios[abs(pg_ratios[[log2_column_names[i]]]) < 1,], 
                   color='black', alpha=.3, na.rm=TRUE) + 
        scale_y_log10(breaks = scales::trans_breaks("log10", function(x) 10^x),
                      labels = scales::trans_format("log10", scales::math_format(10^.x))) + 
        scale_x_continuous(breaks=seq(-500, 500, 1), 
                           minor_breaks=seq(-500, 500, .5), 
                           expand=c(.15,.15)) +
        annotation_logticks(sides='l') +
        geom_point(data=pg_ratios[abs(pg_ratios[[log2_column_names[i]]]) >= 1,], 
                   aes(color=Intensity), na.rm=TRUE) +
        geom_text_repel(data=pg_ratios[unique(top_outlier),], 
                        aes(label=plot_label)) + 
        theme_imb() +
        scale_color_gradient('Intensity', low='blue', high='red') +
        geom_vline(xintercept=c(-1,1), color='red', linetype='dashed')
      
      ggsave(file.path(figures_directory,
                       paste0('intensity_scatter_', 
                              sub('^X','',make.names(title)), 
                              '_', sample_data$id, '.pdf')),
             gscat,
             width=8,height=8)
      plot(gscat)
    },
    error=function(e) {
      mylog('redo the ratioscatterplot.', 'WARN')
      error_appeared <- TRUE
    }
    )
    if(!error_appeared){
      graphsl_ratio_scatter[[
        paste(colnameToLabel(pg$getRatioColumnNames()[i]), my_label)]] <- 
        gscat
      break
    }
  }
}






# Creating Scatter Plots --------------------------------------------------
mylog('prepare scatter plots', dbg_level=0)
graphsl_scatter_plots <- list()
if(!'scatter_df' %in% ls()) {
  scatter_df <- manualCompare(pg, normalized=normalize, column_prefix=log2_prefix)
  save(scatter_df, file=scatter_selection_file)
}

my_highlights <- rep(NA, nrow(pg_ratios))
if(length(important_ids)) {
  my_highlights[grep(paste(important_ids, collapse='|'), 
                     pg_ratios$Protein.IDs, ignore.case=TRUE)] <- 'important protein'
}
if(length(bait_protein)) {
  my_highlights[grep(paste(bait_protein, collapse='|'), 
                     pg_ratios$Protein.IDs, ignore.case=TRUE)] <- 'bait protein'
}
if(!'clicked_list' %in% ls()) {
  clicked_list <- rep(list(my_highlights), nrow(scatter_df))
} else {
  for(i in seq_along(clicked_list)) {
    clicked_list[[i]][!is.na(my_highlights)] <- my_highlights[!is.na(my_highlights)]
  }
}


# Creating Scatter Plots --------------------------------------------------
mylog('create abundance plot', dbg_level=0)

abundance_rank <- rMQanalysis::plotAbundanceRank(
  cbind(pg_ratios, to_highlight=!is.na(my_highlights)), 
  label_column='plot_label',
  subset_column='to_highlight')
ggsave(figures_filenames$abundanceplot,
       abundance_rank,
       width=6, height=6)


# Creating Scatter Plots --------------------------------------------------
mylog('create scatter plots', dbg_level=0)

if(nrow(scatter_df) > 0) {
  for(i in seq(nrow(scatter_df))) {
    
    ###############################################################################
    # create a scatterplot and use identify to select points for labeling.
    # we use this information within ggplot to label the points in the ggplot graph
    max_value <- 
      max(abs(range(pg_ratios[unlist(scatter_df[i,])], na.rm=TRUE)))
    
    threshold_lines <- min(log2(thresholds)) * c(1,-1)
    mymax <- ifelse(max_value >= 7, max_value, 7)
    plot(pg_ratios[[scatter_df[i, 2]]],
         pg_ratios[[scatter_df[i, 1]]],
         col=ifelse(!is.na(clicked_list[[i]]), 'red', 'black'),
         xlab=sprintf('%s (%s)', scatter_df[i, 2], colnameToLabel(scatter_df[i, 2])),
         ylab=sprintf('%s (%s)', scatter_df[i, 1], colnameToLabel(scatter_df[i, 1])),
         main=sprintf('Scatterplot %s', i)
         )
    abline(v=(0),h=(0),col="grey")
    abline (v=threshold_lines, h=threshold_lines, col="red",lty=2)
    
    selected_label <- 'selected protein'
    if(!any(clicked_list[[i]] == selected_label, na.rm=TRUE)) {
      if(is.null(getOption('cfpscripts.test_mode'))) {
        identified <- identify(pg_ratios[[scatter_df[i, 2]]],
                               pg_ratios[[scatter_df[i, 1]]],
                               labels=pg_ratios$plot_label)
        # change label of the unlabeled entries to selected_label
        clicked_list[[i]][identified[
          is.na(clicked_list[[i]][identified])]] <- selected_label
      } else {
        identified <- sample(seq(nrow(pg_ratios)), floor(nrow(pg_ratios) / 8))
      }
    }
    
    
    # column_name <- sprintf('scatterplot_%s', i)
    intercept_df <- data.frame(
      intercept=c(-log2(thresholds), log2(thresholds)), 
      type=factor(paste(thresholds, 'fold', sep='-'), 
                  levels=paste(thresholds, 'fold', sep='-'))
    )
    scatter_plot <- 
      ggplot(pg_ratios,
             aes_string(x=scatter_df[i, 2], y=scatter_df[i, 1])) +
      geom_hline(yintercept=0, color='grey', linetype='solid') +
      geom_vline(xintercept=0, color='grey', linetype='solid') +
      geom_vline(data=intercept_df, 
                 aes(xintercept=intercept, color=type, linetype=type)) +
      geom_hline(data=intercept_df, 
                 aes(yintercept=intercept, color=type, linetype=type)) + 
      geom_point(alpha=.4, size=2, na.rm=TRUE, shape=21, 
                 data=subset(pg_ratios, is.na(clicked_list[[i]])  
                             # is.na(highlight) & 
                             # !is_imputed
                 )) +
      # ggtitle('Scatterplot') + 
      ylab(sprintf('%s (%s)', scatter_df[i, 1], colnameToLabel(scatter_df[i, 1]))) +
      xlab(sprintf('%s (%s)', scatter_df[i, 2], colnameToLabel(scatter_df[i, 2]))) + 
      scale_color_manual('Threshold', values=c('#b30000','#ef6548','#fdbb84','#fee8c8')) +
      guides(linetype=FALSE) +
      theme_imb() +
      scale_x_continuous(breaks=seq(-100,100,1), minor_breaks=seq(-100,100,.5), limits=c(-mymax, mymax)) + 
      scale_y_continuous(breaks=seq(-100,100,1), minor_breaks=seq(-100,100,.5), limits=c(-mymax, mymax))
    if(any(!is.na(clicked_list[[i]]))) {
      scatter_plot <- scatter_plot + 
        geom_point(aes(fill=na.omit(clicked_list[[i]])), shape=21, color='lightgrey', na.rm=TRUE, data=subset(pg_ratios, !is.na(clicked_list[[i]]))) + 
        geom_text_repel(data=subset(pg_ratios, !is.na(clicked_list[[i]])), aes(label=plot_label), 
                  na.rm=TRUE) +
        scale_fill_brewer('Protein', palette='Set1')
    }
    
    print(scatter_plot)
    ggsave(file.path(figures_directory, sprintf('scatterplot_%s.pdf', i)),
           scatter_plot, width=8.8, height=7)
    
    graph_title <- 
      sprintf('%s %s over %s %s', 
              colnameToLabel(scatter_df[i, 1]),
              sub(paste0('log2\\.', my_label_regex), 
                  '\\1/\\2', 
                  scatter_df[i, 1]),
              colnameToLabel(scatter_df[i, 2]),
              sub(paste0('log2\\.', my_label_regex), 
                  '\\1/\\2', 
                  scatter_df[i, 2]))
    graphsl_scatter_plots[[graph_title]] <- scatter_plot
    
  }
}

save(clicked_list, file=clicked_file)








# Creating the excel file -------------------------------------------------
mylog('write excel file', dbg_level=0)
excel_wb <- xlsx::createWorkbook()
filtered_proteins_sheet <- 
  createSheetOfDF(excel_wb, pg_ratio_filtered, 
                  'identified proteins', 
                  link=database_to_link)
selected_proteins_sheet <- 
  createSheetOfDF(excel_wb, 
                  pg_ratios[apply(!sapply(clicked_list, is.na), 1, any),
                            columns_to_keep_in_filtered], 
                  'selected proteins', 
                  link=database_to_link)
if(nrow(interesting_peptides)) {
  interesting_peptides_sheet <- 
    rMQanalysis::createSheetOfDF(
      excel_wb, 
      interesting_peptides, 
      'interesting peptides',
      link='none')
}
identified_proteins_sheet <- 
  createSheetOfDF(excel_wb, pg$getData(), 'full MaxQuant output', 
                  link=database_to_link)
pg_one_unique_sheet <- 
  createSheetOfDF(excel_wb, pg_one_unique, 'only 1 unique peptide', 
                  link=database_to_link)

rMQanalysis::highlightFilteredRows(filtered_proteins_sheet, pg$getData())
rMQanalysis::highlightFilteredRows(selected_proteins_sheet, 
                                   pg_ratios[apply(!sapply(clicked_list, is.na), 1, any),])
rMQanalysis::highlightFilteredRows(identified_proteins_sheet, pg$getData())

rMQanalysis::saveWorkbookMQ(excel_wb, excel_filename)

user_template_file <- 'Labeled_USER_template2.Rmd'
if(!file.exists(file.path(figures_directory, user_template_file))) {
  file.copy(file.path(system.file('extdata', package='cfpscripts'), user_template_file),
            file.path(figures_directory, user_template_file))
}

# writing HTML reports ----------------------------------------------------

mylog('write HTML reports', dbg_level=0)

rmarkdown::render(file.path(figures_directory, user_template_file),
                  output_file=sprintf('report_%s.html', sample_data$id),
                  output_dir='.', quiet=TRUE)

rmarkdown::render(file.path(system.file('extdata', package='cfpscripts'), 'Labeled_CF_template.Rmd'),
                  output_file=sprintf('internal_report_%s.html', sample_data$id),
                  output_dir='.', quiet=TRUE)


files2zip <- c(sprintf('report_%s.html', sample_data$id),
               excel_filename,
               list.files(figures_directory, 'scatterplot_', full.names = TRUE))
zip(zipfile = sprintf('proteomics_sample_%s.zip', sample_data$id), 
    files = files2zip)

writeLines(capture.output(sessionInfo()), 
           file.path(table_directory, 'sessionInfo.txt'))