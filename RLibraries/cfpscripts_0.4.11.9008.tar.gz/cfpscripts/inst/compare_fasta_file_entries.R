###############################################################################
#
# This script creates a bar graph to compare the fasta database counts from 
# multiple years. It needs to be executed within our fasta folder and reads all 
# sequence count tables.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.1
# date: 2018.01.19
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(ggplot2)

files <- c('sequence_count_table_20190116.txt')
jnk <- data.frame()
for(f in files) {
  j <- read.delim(f, stringsAsFactors=FALSE)
  jnk <- rbind(jnk, j)
}

jnk$organism <- gsub('\\./(.*)_\\d{8}\\.fasta', '\\1', jnk$file)
jnk$year <- as.numeric(gsub('.*_(\\d{4})\\d{4}\\.fasta', '\\1', jnk$file))

jnk <- na.omit(jnk)


ggplot(jnk, aes(organism, total, fill=factor(year))) +
  geom_bar(stat='identity', position=position_dodge()) + 
  geom_text(aes(label=total), position=position_dodge(width=1), hjust=0) +
  scale_y_continuous(limits=c(0,700000)) +
  coord_flip() +
  theme_bw(8)
  # theme(axis.text.x=element_text(angle=90, vjust=.5, hjust=1))

ggsave('sequence_count_comparison.pdf', width=8.27, height=11.69)
