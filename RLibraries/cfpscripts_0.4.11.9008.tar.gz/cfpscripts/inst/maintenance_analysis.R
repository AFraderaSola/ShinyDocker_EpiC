###############################################################################
#
# Script to do the analysis of the Maintainance HeLa runs
#
# This script has to be executet within the folder with the raw files. So it 
# needs the folder with the "combined" folder in it. It will create a
# results.txt file with some information to copy paste into Excel late.
# 
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.4
# date: 2018.03.14
#
###############################################################################

library(rMQanalysis)

if(file.exists('summary.txt') & file.exists('proteinGroups.txt')) {
  search_path <- '.'
} else {
  search_path <- file.path('combined','txt')
}

summary <- read.delim(file.path(search_path,'summary.txt'))  # import the proteingroup file
pg <- tryCatch(
  read.delim(file.path(search_path,'proteinGroups.txt')),
  error=function(e) {
    data.frame()
  })


a <- c(summary$MS.MS.Identified....[1])
b <- c(summary$Peptide.Sequences.Identified[1])

if(nrow(pg) > 0) {
  pg_flt <- filterWholeDataset(pg)
  pg_ident <- filterIdentifiedProteins(pg_flt)
  
  pg_ratio <- subset(pg_ident, Ratio.H.L > 0)
  c <- nrow(pg_ident)
  d <- nrow(pg_ratio)
} else {
  c <- 0
  d <- 0
}
df <- data.frame(
  'rawfile               '=summary$Raw.file[1],
  'MSMS.ID               '=a,
  'Peptides.Sequences.ID '=b,
  'proteinGroups         '=c,
  'SILAC.proteinGroups   '=d)
print(t(df))

write.table_imb(t(df),'results.txt',row.names = TRUE)

