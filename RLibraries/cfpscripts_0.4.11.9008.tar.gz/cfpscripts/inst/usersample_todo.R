###############################################################################
#
# Script to create the sequence for an MS run
#
# Creates ToDo entries for new user samples
#
# Thi script will be executed from the launchd process on my local mac. It 
# actually makes no sense on other systems I guess.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.1
# date: 2016.09.15
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################


data_folder <- '/Volumes/Macintosh HD/Users/madejung/Documents/r-projects/'
user_sample_todo <- file.path(data_folder, 'user_sample_todo.txt')
sample_folder <- c('/Volumes/massspec4/CFP/')
at_work <- FALSE

ip_command <- system("/sbin/ifconfig en5 | /usr/bin/awk '/netmask/{print $2}'", 
                     intern=TRUE, ignore.stderr=TRUE)
if(!identical(ip_command, character(0))) {
  if(stringi::stri_startswith(ip_command, fixed='134.')) at_work <- TRUE
}

if(at_work) {
  ignore_before <- as.Date('01.09.2016', "%d.%m.%Y")
  
  user_sample_done <- readLines(user_sample_todo)
  
  if(any(!dir.exists(sample_folder))) {
    drives <- paste(sample_folder[!dir.exists(sample_folder)], collapse=', ')
    system(sprintf('osascript -e \'display notification "%s" with title "Mount massspec drives"\'',
                   drives))
    Sys.sleep(300)
  }
  
  # get all raw files
  measured_rawfiles <- 
    list.files(sample_folder[dir.exists(sample_folder)], 
               pattern='.*\\.raw',
               recursive=TRUE, full.names=TRUE)
  
  # filter washes hela runs and CF stuff
  measured_rawfiles <- 
    data.frame(
      raw_file=measured_rawfiles[!grepl('_wash_|_HeLa|_IMB_CF_', measured_rawfiles)])
  
  # retreive file info
  measured_rawfiles <- 
    do.call(rbind.data.frame, apply(measured_rawfiles, 1, file.info))
  
  # ignore older files
  measured_rawfiles <- 
    measured_rawfiles[as.Date(measured_rawfiles$mtime) > ignore_before,]
  
  # check which are already on the todo list
  measured_rawfiles <- 
    measured_rawfiles[!rownames(measured_rawfiles) %in% user_sample_done,]
  
  # remove small, maybe broken, files
  measured_rawfiles <- 
    measured_rawfiles[measured_rawfiles$size > 1000000,]
  
  # create the reminders
  for(file in basename(rownames(measured_rawfiles))) {
    system(paste('/Users/madejung/bin/newCfSamples', file))
  }
  
  # update the done sheet
  writeLines(c(user_sample_done, rownames(measured_rawfiles)), 
             file.path(data_folder, 'user_sample_todo.txt'))
}




