###############################################################################
#
# Script to analyse DML labeled samples with more then just two experiments.
# The script is under constant development and might produce error messages.
# Remember, the experiment will not be reversed...
#
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.2
# date: 2016.01.27
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(gridExtra)
library(grid)
library(plyr)
library(biomaRt)
library(rMQanalysis)

copySourcedScript()

data_directory <- file.path('combined','txt') # where are the txt files located
out_directory <- file.path('.')
normalize <- TRUE
label_font_size <- 2.5

summary <- read.delim(file.path(data_directory, 'summary.txt'), stringsAsFactors=FALSE)
parameters <- read.delim(file.path(data_directory, 'parameters.txt'), stringsAsFactors=FALSE)
pg <- read.delim(file.path(data_directory, 'proteinGroups.txt'), stringsAsFactors=FALSE)
peptides <- read.delim(file.path(data_directory,'peptides.txt'))

experiments <- unique(summary$Experiment[summary$Experiment != ''])
# compare to expermints variable and use these labels instead.
my_names <- c("LAM_1/ShamPool_1",
              "LAM_2/ShamPool_2",
              "LAM_3/ShamPool_3")


pg_flt <- filterWholeDataset(pg)
pg_ident <- filterIdentifiedProteins(pg_flt)


if (!file.exists('Biomart_out_ensemble.txt')) {
  # list_marts <- listMarts(host='www.ensembl.org')
  #View(list_marts)
  # ensembl = useMart("ENSEMBL_MART_ENSEMBL", host='www.ensembl.org')
  # list_datasets <- listDatasets(ensembl)
  #View(list_datasets)
  # list_datasets$dataset[grep('musculus', list_datasets$description)]
  ensembl <- useMart('ENSEMBL_MART_ENSEMBL', 
                     dataset='mmusculus_gene_ensembl', 
                     host='www.ensembl.org')
  # filters = listFilters(ensembl)
  #View(filters)
  #grep('uniprot', filters$name, value=TRUE)
  # attributes = listAttributes(ensembl)
  #View(attributes)
  #grep('entrez', attributes$name,value=TRUE)
  
  my_ids <- ddply(pg_ident, .(id), summarize,
                  Protein.ID=unlist(strsplit(as.character(Protein.IDs),';')))
  
  query_results <- getBM(attributes = c('ensembl_peptide_id','uniprot_sptrembl',
                                        'uniprot_swissprot','external_gene_name',
                                        'description'),
                         filters = c('ensembl_peptide_id'),
                         values = my_ids[2],
                         mart=ensembl)
  write.table_imb(query_results, file=file.path(out_directory, 'Biomart_out_ensemble.txt'))
} else {
  my_ids <- ddply(pg_ident, .(id), summarize,
                  Protein.ID=unlist(strsplit(as.character(Protein.IDs),';')))
  query_results <- read.delim(file.path(out_directory, 'Biomart_out_ensemble.txt')) 
}

my_ids <- merge(my_ids,
                query_results,
                by.x='Protein.ID',
                by.y='ensembl_peptide_id',
                all.x=TRUE)
my_ids_collapsed <- ddply(my_ids, .(id), summarise,
                          Uniprot_ids=paste(na.omit(uniprot_sptrembl), collapse=';'),
                          Swissprot_ids=paste(na.omit(uniprot_swissprot), collapse=';'),
                          external_gene_names=paste(na.omit(external_gene_name), collapse=';'),
                          description=paste(na.omit(description), collapse=';'))

pg_ident <- merge(pg_ident, my_ids_collapsed)
pg_ident$label <- getLabel(pg_ident, 'external_gene_names', 'Protein.IDs',
                           colname_regex='([^;]+).*', fallback_regex='([^;]+).*')

experiments_strings <- paste0('.', experiments)

ratio_HL_pg <- apply(pg_ident[paste0('Ratio.H.L', experiments_strings)],
                     1,
                     function(x) suppressWarnings(max(x, na.rm=TRUE)) > 0)

pg_df <- data.frame(dataset = factor(c('original', 'filtered', 'identified',
                                       'ratios H/L'), 
                                     levels=c('original', 'filtered', 'identified', 
                                              'ratios H/L', 'pg forward', 'pg reverse',
                                              'ratios H/M', 'ratios M/L')),
                    count = c(nrow(pg), nrow(pg_flt), nrow(pg_ident),
                              sum(ratio_HL_pg)))

y_label_pos <- -max(pg_df$count) * 0.05
pg_count_graph <- ggplot(pg_df, aes(x=dataset, y=count)) + 
  geom_bar(stat='identity') +
  scale_y_continuous(limits = c(-max(pg_df$count) * 0.07, max(pg_df$count) * 1.1)) +
  geom_text(aes(label=count), y=y_label_pos, color='black') +
  ylab('protein groups') + xlab('filtering step') +
  ggtitle('protein groups after each filtering step')
print(pg_count_graph)
ggsave(file.path(out_directory,
                 sprintf('pg_count.pdf')),
       pg_count_graph,
       width=6,height=6)

write.table_imb(pg_ident, 
                file=file.path(out_directory,'proteinGroups.txt'))



peptides_flt <- filterWholeDataset(peptides, by_bysite=F)

# create data frame for the missed cleavage data
missed_cleavages_df <- getMissedCleavageDF(peptides_flt)
missed_cleavages_plot <- plotMissedCleavages(missed_cleavages_df,enzyme='Trypsine')
print(missed_cleavages_plot)

ggsave(file.path(out_directory,
                 sprintf('missed_cleavage.pdf')),
       missed_cleavages_plot,
       width=6,height=6)


pg_ratios <- pg_ident[ratio_HL_pg,]

ratio_regexs <- c('Ratio\\.[HM]\\.[ML]','Ratio\\.[HM]\\.[ML]\\.normalized')
pg_ratios <- cbind(pg_ratios,
                   log2=log2(pg_ratios[grep(paste(ratio_regexs, rep(experiments_strings, each=length(experiments)), '$', sep='', collapse='|'), 
                                            names(pg_ident), value=TRUE)]))



intensity_columns <- sort(grep(paste('Intensity.[HLM]', 
                                     rep(experiments_strings, each=length(experiments)), 
                                     '$', 
                                     sep='', collapse='|'), 
                               names(pg_ratios), value=TRUE))
ratio_columns <- sort(grep(paste('^Ratio\\.[HM]\\.[ML]', 
                                 rep(experiments_strings, each=length(experiments)), 
                                 '$', 
                                 sep='', collapse='|'), 
                           names(pg_ratios), value=TRUE))
ratio_norm_columns <- sort(grep(paste('^Ratio\\.[HM]\\.[ML].normalized', 
                                      rep(experiments_strings, each=length(experiments)), 
                                      '$', 
                                      sep='', collapse='|'), 
                                names(pg_ratios), value=TRUE))
columns_to_use <- ratio_norm_columns

log_columns_to_use <- paste0('log2.', columns_to_use)

columns_to_keep_in_filtered <- 
  c("Protein.IDs","Fasta.headers",
    grep("Protein.names", names(pg_ratios), value=TRUE),
    grep("description", names(pg_ratios), value=TRUE),
    grep("gene", names(pg_ratios), value=TRUE),
    grep("label", names(pg_ratios), value=TRUE),
    "Mol..weight..kDa.","Sequence.length",
    log_columns_to_use,
    paste0(c("Ratio.H.L.normalized.","Ratio.H.L.count."), rep(experiments, each=2)),
    # paste0(c("Ratio.H.L.","Ratio.H.L.normalized.","Ratio.H.L.count."), rep(experiments, each=3)),
    paste0("Sequence.coverage.", experiments, "...."),
    paste0("Unique.peptides.", experiments),
    paste0(c("Intensity.H.", "Intensity.L."), rep(experiments, each=2)))

write.table_imb(pg_ratios[columns_to_keep_in_filtered], 
                file=file.path(out_directory,'proteinGroups_filtered.txt'))

xlim_min <- -5
xlim_max <- 5

graphs_histogram <- list()
graphs_norm_histogram <- list()
graphs_boxplot <- list()
graphsl_combined <- list()
graphsl_ratio_scatter <- list()


tryCatch({ # we put everything into a try catch block, because sometimes we get an error
  for(i in seq(columns_to_use)) {
    median_experiment <- median(pg_ratios[[ratio_columns[i]]], na.rm=TRUE)
    
    title <- my_names[i]
    negative <- FALSE
    ratio_label <- 'H/L'
    graph_string <- ifelse(experiments[i] == '', i,experiments[i])
    boxplot_xlab <- my_names[i]
    
    temp_log2_ratio <- log2(pg_ratios[[ratio_columns[i]]])
    temp_log2_ratio_norm <- log2(pg_ratios[[ratio_norm_columns[i]]])
    graphs_histogram[[graph_string]] <- 
      ggplot(pg_ratios, aes(x=temp_log2_ratio)) + 
      geom_histogram(binwidth=.2,color='black',fill='grey') + 
      xlab(sprintf('log2 ( %s )', ratio_label)) + ylab("Frequency") + xlim(xlim_min,xlim_max) +
      ggtitle(sprintf('%s\nMedian-Ratio: %.2f',
                      my_names[i],
                      median_experiment))
    graphs_norm_histogram[[graph_string]] <- 
      ggplot(pg_ratios, aes(x=temp_log2_ratio_norm)) + 
      geom_histogram(binwidth=.2,color='black',fill='grey') + 
      xlab(sprintf('log2 ( %s )', ratio_label)) + ylab("Frequency") + xlim(xlim_min,xlim_max) +
      ggtitle(sprintf('%s\nnormalized',my_names[i]))
    
    graphs_boxplot[[graph_string]] <- 
      plotRatioBoxplot(pg_ratios, 
                       colname <- columns_to_use[i],
                       # experiment=paste0('.',my_names[i]), 
                       labels='label') +
      xlab(boxplot_xlab) +
      ylab(ifelse(normalize,
                  sprintf('log2 ( %s ) normalized',ratio_label),
                  sprintf('log2 ( %s )', ratio_label)))
    
    graphsl_ratio_scatter[[graph_string]] <- 
      plotRatioScatter(pg_ratios,
                       labels='label',
                       x_col=columns_to_use[i], 
                       negative=negative) +
      theme(legend.position="top")
    
    ###############################################################################
    # arange the boxplots next to the two histograms and save them in files
    graphsl_combined[[graph_string]] <- 
      arrangeGrob(graphs_histogram[[graph_string]], 
                  graphs_norm_histogram[[graph_string]], 
                  graphs_boxplot[[graph_string]], 
                  layout_matrix=rbind(c(1,3),c(2,3)), 
                  top=paste(title))
    #       arrangeGrob(
    #         arrangeGrob(graphs_histogram[[graph_string]], 
    #                     graphs_norm_histogram[[graph_string]], 
    #                     ncol=1), 
    #         graphs_boxplot[[graph_string]], ncol=2,
    #         main=paste(title))
    
    grid.newpage()
    grid.draw(graphsl_combined[[graph_string]])
    ggsave(file.path(out_directory,
                     paste0('histogram_',graph_string,'.pdf')),
           graphsl_combined[[graph_string]],
           width=8,height=8)
    
    print(graphsl_ratio_scatter[[graph_string]])
    ggsave(file.path(out_directory,
                     paste0('ratio_scatter_',graph_string,'.pdf')),
           graphsl_ratio_scatter[[graph_string]],
           width=8,height=8)
  }},
  error=function(e) {
    expected_messages <- c('polygon edge not found')
    if(grepl(paste(expected_messages, collapse='|'), e$message)) {
      stop(sprintf('An error occured but it is a known issue. ;-)\n'), 
           sprintf('Please just execute this script again (up to 5 times) and it will work as expected. ;-)\n'),
           call.=FALSE)
    } else {
      warning(e)
    }
  }
)


pg_ratios$highlight <- NA

indicated_df <- pg_ratios['Protein.IDs']


scatter_df <- data.frame(
  name_a=c(log_columns_to_use[c(1,1,2)]),
  name_b=c(log_columns_to_use[c(2,3,3)]),
  stringsAsFactors=FALSE)
name_df <- data.frame(
  name_a=c(my_names[c(1,1,2)]),
  name_b=c(my_names[c(2,3,3)]),
  stringsAsFactors=FALSE)
graphsl_scatter_plots <- list()

if(nrow(scatter_df) > 0) {
  for(line in seq(nrow(scatter_df))) {
    
    ###############################################################################
    # create a scatterplot and use identify to select points for labeling.
    # we use this information within ggplot to label the points in the ggplot graph
    
    maxx_value <- max(abs(pg_ratios[[scatter_df[line, 1]]]), na.rm=TRUE)
    maxy_value <- max(abs(pg_ratios[[scatter_df[line, 2]]]), na.rm=TRUE)
    scatter_limits <- list(
      x_zoom=c(-0.5, maxx_value + 1),
      y_zoom=c(-maxy_value - 1, 0.5)
    )
    max_value <- max(c(maxx_value, maxy_value))
    
    mymax <- ifelse(max_value >= 5, max_value, 5)
    plot(pg_ratios[[scatter_df[line, 1]]],
         pg_ratios[[scatter_df[line, 2]]],
         xlim = c(-mymax, mymax),ylim = c(-mymax, mymax),
         col=ifelse(!is.na(pg_ratios$highlight), 'red', 'black'))
    abline(v=(0),h=(0),col="grey")
    abline (v=c(1,-1), h=c(1, -1), col="red",lty=2)
    identified <- identify(pg_ratios[[scatter_df[line, 1]]],
                           pg_ratios[[scatter_df[line, 2]]],
                           labels=pg_ratios$label,
                           pos=TRUE)
    pg_ratios$pos <- NA
    pg_ratios[identified$ind,]$pos <- identified$pos
    
    column_name <- sprintf('scatterplot_%s', line)
    indicated_df[column_name] <- pg_ratios$pos
    
    scatter_plot <- 
      ggplot(pg_ratios,
             aes_string(x=scatter_df[line, 1], y=scatter_df[line, 2])) + 
      geom_point(alpha=.2, size=2, shape=21, data=subset(pg_ratios, is.na(pos) & is.na(highlight))) +
      geom_hline(aes(yintercept=0), color='grey') + 
      geom_vline(aes(xintercept=0), color='grey') +
      geom_hline(aes(yintercept=1),linetype='dashed',color='red') +
      geom_hline(aes(yintercept=-1),linetype='dashed',color='red') + 
      geom_vline(aes(xintercept=1),linetype='dashed',color='red') +
      geom_vline(aes(xintercept=-1),linetype='dashed',color='red') +
      ggtitle('Scatterplot') + 
      ylab(sprintf(name_df[line, 2])) +
      xlab(sprintf(name_df[line, 1])) + theme_imb() +
      scale_x_continuous(breaks=seq(-100,100,4), minor_breaks=seq(-100,100,1), limits=c(-mymax, mymax)) + 
      scale_y_continuous(breaks=seq(-100,100,4), minor_breaks=seq(-100,100,1), limits=c(-mymax, mymax))
    if(!length(identified$ind) == 0) {
      scatter_plot <- scatter_plot +
        geom_point(color='red', 
                   data=subset(pg_ratios, !is.na(pos) & is.na(highlight))) +
        geom_text(data=subset(pg_ratios, pos == 1 & is.na(highlight)),
                  aes(label=label),vjust=1.2,size=label_font_size) + 
        geom_text(data=subset(pg_ratios, pos == 2 & is.na(highlight)),
                  aes(label=label),hjust=1.1,size=label_font_size) +
        geom_text(data=subset(pg_ratios, pos == 3 & is.na(highlight)),
                  aes(label=label),vjust=-.6,size=label_font_size) + 
        geom_text(data=subset(pg_ratios, pos == 4 & is.na(highlight)),
                  aes(label=label),hjust=-.1,size=label_font_size)
    }
    if(any(!is.na(pg_ratios$highlight))) {
      scatter_plot <- scatter_plot + 
        geom_point(color='lightgreen', data=subset(pg_ratios, !is.na(highlight))) + 
        geom_text(data=subset(pg_ratios, !is.na(highlight)), aes(label=label), 
                  vjust=1.5, size=label_font_size)
    }
    
    print(scatter_plot)
    ggsave(sprintf('scatterplot_%s.pdf', 
                   paste(sub('.*\\.([^.]+)$','\\1',scatter_df[line,]), collapse='_')), 
           scatter_plot, width=15, height=15)
    
    graphsl_scatter_plots[[line]] <- scatter_plot
    
  }
}

threshold <- log2(2) #log2 threshold
column_regex <- paste0('log2.*normalized.(', paste(experiments, collapse='|'),')')
expa_min2 <- apply(pg_ratios[grep(column_regex, names(pg_ratios), value=TRUE)], 1, 
                   function(x) sum(x >= threshold, na.rm=TRUE) >= 2 | 
                     sum(x <= -threshold, na.rm=TRUE) >= 2)

write.table_imb(pg_ratios[expa_min2, columns_to_keep_in_filtered], 
                file=file.path(out_directory, paste0('proteinGroups_regulated_LAM_min2reg_','log2threshold_',round(threshold,2),'.txt')))


expa_min3 <- apply(pg_ratios[grep(column_regex, names(pg_ratios), value=TRUE)], 1, 
                   function(x) sum(x >= threshold, na.rm=TRUE) >= 3 | 
                     sum(x <= -threshold, na.rm=TRUE) >= 3)

write.table_imb(pg_ratios[expa_min3, columns_to_keep_in_filtered], 
                file=file.path(out_directory, paste0('proteinGroups_regulated_LAM_min3reg_','log2threshold_',round(threshold,2),'.txt')))


pg_ratios$value_count_exp <- 
  unlist(countValuesPerExperiment(pg_ratios[grep(column_regex, names(pg_ratios), value=TRUE)]))
pg_ratios$mean_exp <- apply(pg_ratios[grep(column_regex, names(pg_ratios), value=TRUE)],
                            1,
                            mean, na.rm=TRUE)
df <- subset(pg_ratios, value_count_exp >= 2)
threshold_scatter <- 2

ratio_scatter_plot <-   
  ggplot(df, aes(mean_exp, Intensity)) + 
  geom_point(data=subset(df, mean_exp < threshold_scatter & mean_exp > -threshold_scatter), 
             color="black", alpha=0.3, shape=21) + 
  scale_y_log10(breaks=trans_breaks("log10", function(x) 10^x), labels=trans_format("log10", math_format(10^.x))) + 
  scale_x_continuous(limits=c(min(df$mean_exp, na.rm = TRUE) - 4, max(df$mean_exp, na.rm=TRUE) + 4), 
                     breaks=seq(-500,500, 2), 
                     minor_breaks=seq(-500, 500, 0.5)) + 
  annotation_logticks(sides="l") + 
  geom_point(data=subset(df, mean_exp >= threshold_scatter | mean_exp <= -threshold_scatter), 
             aes(color=factor(value_count_exp))) + 
  geom_text(data=subset(df, mean_exp >= threshold_scatter), 
            hjust=-0.1, size=2, aes(label=label, angle=45)) + 
  geom_text(data=subset(df, mean_exp <= -threshold_scatter), 
            hjust=1.1, size=2, aes(label=label), angle=-45) + 
  theme_imb() + 
  scale_color_hue('in #\nreplicates') + 
  geom_vline(xintercept = c(-threshold_scatter, threshold_scatter), 
             color="red", linetype="dashed") + 
  xlab("mean log2( LAM / ShamPool )") + 
  ylab('Intensity')
ggsave('ratio_scatter_mean.pdf', ratio_scatter_plot,
       height=11.69, width=8.27)

print(ratio_scatter_plot)

ggsave('ratio_scatter_mean_right.pdf', 
       ratio_scatter_plot + scale_x_continuous(limits=c(1, max(df$mean_exp, na.rm=TRUE)*1.2)),
       height=11.69, width=8.27)
ggsave('ratio_scatter_mean_left.pdf', 
       ratio_scatter_plot + scale_x_continuous(limits=c(min(df$mean_exp, na.rm=TRUE)*1.2, -1)),
       height=11.69, width=8.27)

write.table_imb(df[order(df$mean_exp), 
                   c(columns_to_keep_in_filtered, 
                     grep("_exp", names(pg_ratios), value=TRUE))],
                file='proteinGroups_ordered_min2rep.txt')
