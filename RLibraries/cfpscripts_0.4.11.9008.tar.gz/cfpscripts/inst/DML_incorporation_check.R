###############################################################################
#
# This script will remove copies of the raw files from the subfolder structure
# and also cleans the combined folder a little bit.
# After this step, it is analysing the incorporation check for each label.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.9
# date: 2018.10.24
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(gridExtra)
library(grid)
library(dplyr)
library(tidyr)
library(rMQanalysis)

# global variables --------------------------------------------------------
subfolder_prefix <- 'IC_'
subsubfolder_prefix <- 'IC_DML_'
relative_txt_path <- file.path('combined','txt')

delete_raw_files <- TRUE

# labels and fasta files --------------------------------------------------

experiment_folders <- grep(subfolder_prefix, list.dirs(recursive=FALSE), value=TRUE)
ic_df <- data.frame()
for(experiment_folder in experiment_folders) {
  if(delete_raw_files) {
    raw_files <- list.files(experiment_folder, pattern='.raw$', 
                            full.names=TRUE, recursive=TRUE)
    invisible(unlink(raw_files))
  }
  experiment <- sub(paste0('.*', subfolder_prefix, '(.*)'), '\\1', experiment_folder)
  label_folders <- grep(subsubfolder_prefix, list.dirs(experiment_folder, recursive=FALSE), value=TRUE)
  peptide_intensities <- list()
  
  # clean IC folders
  capture.output(cfpscripts::scriptEraseUnusedMQFolders(
    workdir = experiment_folder, 
    dont_delete_pattern = "Dont_delete.txt", 
    exclude_regex = "automated_hela"
  ))

# missed cleavage plots for all labels except NONE ------------------------
  mc_graphs <- list()
  for(label_folder in label_folders) {
    dml_label <- sub('.*_([^_]+)$', '\\1', label_folder)
    txt_path <- file.path(label_folder, relative_txt_path)
    peptide_file <- file.path(txt_path, 'peptides.txt')
    tryCatch({
      peptides <- read.delim(peptide_file)
      peptides_flt <- filterWholeDataset(peptides, by_bysite=FALSE)
      peptide_intensities[[dml_label]] <- peptides_flt[c('Sequence','Intensity')]
      
      mc_df <- getMissedCleavageDF(peptides_flt)
      if(nrow(peptides_flt) == 0) { # in case after filtering where no peptides left.
        warning(sprintf('In %s where no peptides left after filtering.', 
                        label_folder), call.=FALSE)
        mc_df[c('amount','round_amount')] <- 0
      }
    }, error=function(e){
      peptide_intensities[[dml_label]] <<- 
        # data.frame(Sequence=character(0), Intensity=numeric(0))
        data.frame(Sequence=NA, Intensity=NA)
      mc_df <- data.frame(index=0:2, amount=0, round_amount=0)
    }
    )
    mc_graph <- plotMissedCleavages(mc_df) + 
      ggtitle(sprintf('DML-%s missed cleavages', dml_label))
    mc_graphs[[dml_label]] <- mc_graph
  }
  mc_graph <- do.call(arrangeGrob, mc_graphs)
  
# incorporation check -----------------------------------------------------
  dml_labels <- sub('.*_([^_]+)$', '\\1', label_folders)
  cdf <- permuteNames(dml_labels, which('NONE' == dml_labels))
  inc_graphs <- list()
  for(line in seq(nrow(cdf))) {
    jnk <- merge(peptide_intensities[[as.character(cdf[line,2])]], 
                 peptide_intensities[[as.character(cdf[line,1])]], 
                 by='Sequence', all=TRUE)
    if(nrow(jnk) == 0) { # in case we didn't find any peptide we fill this with 0s
      jnk <- rbind(jnk, c(0,0,0))
    }
    names(jnk) <- c('Sequence','Intensity.H','Intensity.L')
    jnk$Intensity.L <- replace(jnk$Intensity.L, is.na(jnk$Intensity.L), 0)  
    jnk$Intensity.H <- replace(jnk$Intensity.H, is.na(jnk$Intensity.H), 0)
    jnk$Intensity <- jnk$Intensity.H + jnk$Intensity.L
    jnk$Missed.cleavages <- 0
    
    # inc_check <- testGetInc(jnk,'DML')
    inc_check <- getIncorporationRate(jnk,'DML')
    
    ic_df <- rbind(ic_df,
                   data.frame(barcode=experiment,
                              none_peptides=sum(jnk$Intensity.L > 0),
                              label=paste0('DML',as.character(cdf[line,2])),
                              peptides=sum(jnk$Intensity.H > 0),
                              inc=inc_check$value))
    
    cat(sprintf('%s %.1f%% incorporation %s DML-%s peptides, %s DML-%s peptides\n',
                experiment, inc_check$value,
                sum(jnk$Intensity.H > 0), as.character(cdf[line,2]), 
                sum(jnk$Intensity.L > 0), as.character(cdf[line,1])))
    graph <- inc_check$graph + 
      ggtitle(sprintf('%.1f%% incorporation\n%s DML-%s peptides, %s DML-%s peptides',
                      inc_check$value,
                      sum(jnk$Intensity.H > 0), as.character(cdf[line,2]), 
                      sum(jnk$Intensity.L > 0), as.character(cdf[line,1])))
    inc_graphs[[as.character(cdf[line,2])]] <- graph
  }
  inc_graph <- do.call(arrangeGrob, inc_graphs)
  #   g <- arrangeGrob(mc_graph, inc_graph, ncol=2, 
  #                    main=textGrob(sprintf('%s', experiment), vjust=1, 
  #                             gp=gpar(cex=1.4)))
  g <-  arrangeGrob(mc_graph, inc_graph, 
                    layout_matrix=rbind(c(1,2)), 
                    top=sprintf('%s', experiment))
  grid.newpage()
  grid.draw(g)
  #   print(g)
  ggsave(sprintf('incorporation_%s.pdf', experiment), g,
         height=12, width=12)
}

ic_dfw <- 
  ic_df %>% 
  gather(variable, value, -(barcode:label)) %>%
  unite(temp, label, variable) %>%
  spread(temp, value) 

write.table_imb(ic_dfw, 'incorporation_table.txt')


