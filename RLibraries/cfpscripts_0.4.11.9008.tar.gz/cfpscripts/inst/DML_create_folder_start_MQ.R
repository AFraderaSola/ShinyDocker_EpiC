###############################################################################
#
# This script will create for each DML raw file a new subfolder with additional
# subfolders for each label. It will copy the raw files in the related 
# subfolders and creates mqpar files to run the analysis. 
# It no longer automatically starts the maxquant analysis in parallel.
# In case it is a triple labeling experiment, please create a file called 
# "TRIPLE.txt" within the working directory.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.22
# date: 2019.02.28
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(reshape2)
library(ggplot2)

library(rMQanalysis)
library(cfpscripts)

copySourcedScript()
# global variables --------------------------------------------------------

tryptic_enzyme <- 'Trypsin/P'

to_email <- '' # Only university or imb email addresses are allowed

fasta_basepath <- getGlobalOption('MQFASTADIR', 'options(MQFASTADIR="path/to/*.fasta")')
mqpar_template <- file.path(
  getGlobalOption('RSCRIPTSDIR', 'options(RSCRIPTSDIR="/massspec/R_script")'), 
  'mqpar_DML_template.xml')
maxquant <- getGlobalOption('MAXQUANTCMD', 
                            'options(MAXQUANTCMD="path/to/MaxQuantCmd.exe")',
                            stop_if_null=FALSE)

subfolder_prefix <- 'IC_'
subsubfolder_prefix <- 'IC_DML_'
processes_to_start <- 6

start_and_watch_MQ <- FALSE

# labels and fasta files --------------------------------------------------

# if(any(file.exists(c('TRIPLE', 'TRIPLE.txt')))) {
  dml_labels <- list('NONE'='',
                     '0'='DimethLys0;DimethNter0',
                     '4'='DimethLys4;DimethNter4',
                     '8'='DimethLys8;DimethNter8')
# } else {
#   dml_labels <- list('NONE'='',
#                      '0'='DimethLys0;DimethNter0',
#                      '4'='DimethLys4;DimethNter4')
# }

fasta_dbs <- list(ce=c(file.path(fasta_basepath, 'Caenorhabditis_elegans_(CAEEL)_Uniprot_20190116.fasta', fsep='\\\\'),
                       file.path(fasta_basepath, 'Escherichia_coli_(ECOLI)_Uniprot_(strain_K12)_20190116.fasta', fsep='\\\\')),
                  hs=c(file.path(fasta_basepath, 'Homo_sapiens_(HUMAN)_Uniprot_20190116.fasta', fsep='\\\\')),
                  mm=c(file.path(fasta_basepath, 'Mus_musculus_(MOUSE)_Uniprot_20190116.fasta', fsep='\\\\')),
                  sc=c(file.path(fasta_basepath, 'Saccharomyces_cerevisiae_(YEAST)_Uniprot_(strain_ATCC_204508)_20190116.fasta', fsep='\\\\')),
                  dm=c(file.path(fasta_basepath, 'Drosophila_melanogaster_(FRUITFLY)_Uniprot_20190116.fasta', fsep='\\\\')),
                  gg=c(file.path(fasta_basepath, 'Gallus_gallus_(CHICKEN)_Uniprot_20190116.fasta', fsep='\\\\')),
                  bt=c(file.path(fasta_basepath, 'Bos_taurus_(BOVINE)_Uniprot_20190116.fasta', fsep='\\\\')),
                  at=c(file.path(fasta_basepath, 'Arabidopsis_thaliana_(ARATH)_Uniprot_20190116.fasta', fsep='\\\\')),
                  bm=c(file.path(fasta_basepath, 'Bombyx_mori_(SILKMOTH)_Uniprot_20190116.fasta', fsep='\\\\')),
                  xl=c(file.path(fasta_basepath, 'Xenopus_laevis_(AFRICANCLAWEDFROG)_Uniprot_20190116.fasta', fsep='\\\\')),
                  dr=c(file.path(fasta_basepath, 'Danio_rerio_(ZEBRAFISH)_Uniprot_20190116.fasta', fsep='\\\\')),
                  pd=c(file.path(fasta_basepath, 'Pdu_HeadRef_Prot_v4.fasta', fsep='\\\\'))
)
  

# Check if MQ exists ------------------------------------------------------

if(is.null(maxquant)) {
  warning('!!! MaxQuantCmd.exe is not provided. !!!\n',
          '!!! The folder structure gets created but not analysed. !!!', 
          immediate.=TRUE, call.=FALSE)
} else {
  if(!file.exists(maxquant)) {
    message(sprintf('"%s" does not exists, please check "%s".',
                    maxquant, file.path(path.expand('~'), '.Rprofile')))
    stop(sprintf('"%s" does not exist.', maxquant))
  }
}

# check if old folders exist ----------------------------------------------

old_subfolders <- grep(subfolder_prefix, list.dirs(recursive=FALSE), value=TRUE)
if(length(old_subfolders) > 0) {
  stop(sprintf('please delete or rename old subfolders: \n%s\n',
               paste(old_subfolders, collapse='\n')), call.=FALSE)
}


# Working on raw files ----------------------------------------------------

commands <- c()

raw_files <- list.files(pattern='*.raw$')

raw_file_list <- list()
for(raw_file in raw_files) {

# subfolder structure for each rawfile ------------------------------------
  raw_file_list[[raw_file]]$name <- raw_file
  regular_rawfile <- suppressWarnings(RawFile(raw_file)$matching)
  if(regular_rawfile) {
    raw_file_list[[raw_file]]$subfolder_name <- 
      sub('.*_QEP\\d_(\\w+_\\w+_\\d{4}-?.?)_([a-z]+)_.*', 
          paste0(subfolder_prefix, '\\1'), 
          raw_file)
    # subfolders <- c(subfolders, subfolder_name)
    raw_file_list[[raw_file]]$species_abbreviation <- 
      sub('.*_QEP\\d_(\\w+_\\w+_\\d{4}-?.?)_([a-z]+)_.*', '\\2', raw_file)

    spec_abb <- raw_file_list[[raw_file]]$species_abbreviation
    if(spec_abb %in% names(fasta_dbs)) {
      raw_file_list[[raw_file]]$fasta_db_string <- 
        paste(sapply(fasta_dbs[spec_abb], 
                     function(x) {
                       sprintf('<string>%s</string>',x)
                     }), 
              collapse='\n')
    } else {
      stop(sprintf('"%s" is not a known abbreviation yet. Please add to "%s" at the beginning of the script.',
                   spec_abb, 'fasta_dbs'), 
           call.=FALSE)
    }
  } else {
    raw_file_list[[raw_file]]$subfolder_name <- 
      paste0(subfolder_prefix, sub('.raw', '', raw_file))
    message(sprintf('We could not find a related fasta file for "%s".', raw_file))
    fasta_question <- 'Please provide global path WITH fasta file (separate multiple by ";" and use TWO "\\"): \n'
    if(getOption('cfpscripts.test_mode', FALSE)) {
      fasta_string <- paste(list.files(), collapse=';')
    } else {
      cat(fasta_question)
      fasta_string <- readline('')
    }
    fasta_files <- strsplit(fasta_string, ';')[[1]]
    while(!all(file.exists(fasta_files))) {
      message('Some of fasta files do not exists, please try again.')
      fasta_string <- readline(fasta_question)
      fasta_files <- strsplit(fasta_string, ';')[[1]]
    }
    raw_file_list[[raw_file]]$fasta_db_string <- 
      paste(sapply(fasta_files, function(x) {
        sprintf('<string>%s</string>',x)
      }), 
      collapse='\n')
  }
}

for(raw_file in raw_file_list) {
  cat(sprintf('creating subfolder "%s" for "%s".\n', 
              raw_file$subfolder_name, 
              raw_file$name))
  dir.create(raw_file$subfolder_name)


# subsubfolder structure for each label -----------------------------------

  for(dml_label in names(dml_labels)) {
    subsubfolder_name <- sprintf('%s%s', subsubfolder_prefix, dml_label)
    cat(sprintf('creating subsubfolder "%s" for "%s".\n', subsubfolder_name, raw_file$name))
    subsubfolder_path <- file.path(raw_file$subfolder_name, subsubfolder_name, fsep='\\\\')
    dir.create(subsubfolder_path)
    subsub_raw_file <- file.path(subsubfolder_path, raw_file$name, fsep='\\\\')
    file.copy(raw_file$name, subsub_raw_file)

# creating mqpar file for each label --------------------------------------
    
    cat(sprintf('creating mqpar.xml file "%s" label.\n', dml_label))
    if(start_and_watch_MQ) {
      mqpar_label <- file.path(subsubfolder_path, 'mqpar_DML_IC.xml')
    } else {
      mqpar_label <- file.path(subsubfolder_path, 'mqpar__DML_IC.xml')
    }
    file.copy(mqpar_template, mqpar_label)
    mqpar <- suppressWarnings(readLines(mqpar_label))
    
    absolute_rawfile <- gsub('/', 
                             '\\\\\\\\', # looks strange but this actually replaces the single / into a single \, no idea why :-)
                             file.path(getwd(), subsub_raw_file, fsep='\\\\')
                             )
    mqpar <- sub('XXX__RAW_FILE_PATH__XXX', 
                 sprintf('<string>%s</string>', absolute_rawfile), 
                 mqpar)
    
    mqpar <- sub('XXX__LABEL_STRING__XXX', 
                 sprintf('<string>%s</string>', dml_labels[dml_label]), 
                 mqpar)
    
    mqpar <- sub('XXX__FASTA_DB__XXX', 
                 raw_file$fasta_db_string, 
                 mqpar)
    
    mqpar <- sub('<string>Trypsin/P</string>',
                 sprintf('<string>%s</string>', tryptic_enzyme),
                 mqpar)
    
    writeLines(mqpar, mqpar_label)

# create max quant command for each label ----------------------------------------

    absolute_mqpar_label <- file.path(getwd(), subsubfolder_path, basename(mqpar_label))
    cmd <- sprintf('"%s" "%s"', maxquant, absolute_mqpar_label)
    commands <- c(commands, cmd)
  }
}

cat(sprintf('\nMaxQuant has to run %d processes, please check back later.\n\n',
            length(commands)))


if(start_and_watch_MQ) {
  job_counter <- 0
  processing_data <- data.frame()
  while(job_counter < length(commands)) {
    p <- processingData()
    while((p$maxquantcmd + p$maxquantimpl) >= processes_to_start) {
      p <- processingData()
      processing_data <- rbind(processing_data, p)
      Sys.sleep(3)
      
      if(nrow(processing_data) == 1) {
        cat(sprintf('\n%s\t%s processes are running, %s are waiting.\n',
                    Sys.time(), p$maxquantcmd + p$maxquantimpl, length(commands) - job_counter))
      }
      
      cat(sprintf('.'))
      if(nrow(processing_data) > 0) {
        if(nrow(processing_data) %% 10 == 0) {
          mdf <- melt(processing_data, 'date')
          g <- ggplot(mdf, aes(x=date, y=value)) + geom_line() +
            scale_x_datetime() + facet_wrap(~ variable, ncol=1, scales='free_y') +
            expand_limits(y=0) + xlab(NULL) + ylab(NULL)
          print(g)
        }
        if(nrow(processing_data) %% 100 == 0) {
          cat(sprintf('\n%s\t%s processes are running, %s are waiting.\n',
                      Sys.time(), p$maxquantcmd + p$maxquantimpl, length(commands) - job_counter))
        }
      }
    }
    
    job_counter <- job_counter + 1
    cmd <- commands[job_counter]
    cat(sprintf('\nStarting job %s/%s\n', job_counter, length(commands)))
    system(cmd, wait=FALSE) # we don't wait to finish the process
    Sys.sleep(5)
    cat(sprintf('\n%s\t%s processes are running, %s are waiting.\n.',
                Sys.time(), p$maxquantcmd + p$maxquantimpl, length(commands) - job_counter))
  }
  
  subfolders <- sapply(raw_file_list, function(x) x$subfolder_name)


  cat(sprintf('checking in the following folders for proteinGroups files: \n"%s"\n',
              paste(subfolders, collapse=', ')))
  
  wait_count <- 0
  while(countFinishedAnalysis(subfolders) != length(commands)) {
    p <- processingData()
    processing_data <- rbind(processing_data, p)
    
    if(wait_count %% 100 == 0) {
      cat(sprintf('\n%s\tMaxQuant is still running, waiting for %s processes to finish.\n.',
                  Sys.time(), length(commands) - countFinishedAnalysis(subfolders)))
    }
    
    if(nrow(processing_data) %% 10 == 0) {
      mdf <- melt(processing_data, 'date')
      g <- ggplot(mdf, aes(x=date, y=value)) + geom_line() +
        scale_x_datetime() + facet_wrap(~ variable, ncol=1, scales='free_y') +
        expand_limits(y=0) + xlab(NULL) + ylab(NULL)
      print(g)
    }
    
    cat(sprintf('.'))
    wait_count <- wait_count + 1
    Sys.sleep(3)
    all_files_created <- countFinishedAnalysis(subfolders) == length(commands)
    if(processingData()$maxquantcmd == 0 & !all_files_created) {
      stop('It looks like a MaxQuant process stopped unexpectedly!', call.=FALSE)
    }
  }
  
  if(!getOption('cfpscripts.test_mode', FALSE)) Sys.sleep(30)
  
  cat(sprintf('\n\n%s\tMaxQuant finished and you can start the Incorporation Check.\n\n.',
              Sys.time()))


  cat(sprintf('We delete the duplicated rawfiles in the subfolders!\n'))
  unlink(list.files(subfolders, '.raw', full.names=TRUE, recursive=TRUE))
  
  p <- processingData()
  processing_data <- rbind(processing_data, p)
  
  if(nrow(processing_data) > 0) {
    mdf <- melt(processing_data, 'date')
    g <- ggplot(mdf, aes(x=date, y=value)) + geom_line() +
      scale_x_datetime() + facet_wrap(~ variable, ncol=1, scales='free_y') +
      expand_limits(y=0) + xlab(NULL) + ylab(NULL) + ggtitle(Sys.time())
    print(g)
    ggsave('load_image.pdf', g,
           width=8.27, height=11.69)
  }
}
if(to_email != '') {
  mailR::send.mail(from=cfpscripts:::email_settings$from,
                   to=to_email,
                   subject="DML IC preparation is DONE",
                   body=sprintf('We executed the the following commands:\n%s',
                                paste(commands, collapse=',\n')),
                   smtp=cfpscripts:::email_settings,
                   authenticate=FALSE,
                   # attach.files='load_image.pdf',
                   send=TRUE)
}



