# LFQ lite
# version 0.2
# date 2016.09.16
# developed by Mario Dejung

library(ggplot2)
library(plotly)

modify_mean <- -3 # imputed values are a bit smaller than original mean
sd_factor <- .3 # the distribution is a bit sharper

# have a look in experiments variable (line 46-49)... 
# always pair index of treatment and control to get treatment on the right within
# volcano plot.
comparison_list <- list(
  c(2,1), # 2 is treatment, 1 is control
  c(3,1) # 3 is treatment, 1 is control
)


pg <- read.delim('proteinGroups.txt')
pg <- pg[pg[['Potential.contaminant']] != '+',] # Filter contaminants
pg <- pg[pg[['Reverse']] != '+',] # Filter reverse binders
pg <- pg[pg[['Only.identified.by.site']] != '+',] # Filter by site identified proteins
pg <- pg[pg[['Unique.peptides']] >= 1 & pg[['Razor...unique.peptides']] >= 2,] # filter for identified proteins (CF criteria)

lfq_columns <- grep('^LFQ', names(pg))
pg[lfq_columns][pg[lfq_columns] == 0] <- NA # replace 0 with NA in all LFQ columns
pg <- cbind(pg, log2=log2(pg[lfq_columns])) # add log2 converted lfq columns
log2_lfq_columns <- grep('^log2\\.LFQ', names(pg))
pg <- cbind(pg, imputed=pg[log2_lfq_columns])
imputed_columns <- grep('^imputed\\.log2\\.LFQ', names(pg))

for(column in imputed_columns){ # imputing needs to be done per replicate
  hist(pg[[column]],100,xlim=c(15,45),col='green',main=names(pg[column]))
  missing_values <- sum(is.na(pg[[column]])) # counting how many values we need
  column_mean <- mean(pg[[column]], na.rm=TRUE) # checking the original dist for this repl
  column_sd <- sd(pg[[column]], na.rm=TRUE) # checking the standard deviation for this repl
  random_numbers <- rnorm(missing_values,
                          mean=column_mean + modify_mean, # impute missing values at the lower end of dist
                          sd=column_sd * sd_factor) # also sharpend the dist a little
  hist(random_numbers,100,add=TRUE,xlim=c(15,45),col='red')
  pg[[column]][is.na(pg[[column]])] <- random_numbers # overwrite the NAs by our new values
}

experiments <- # extracting unique experiment names without replicate number
  unique(sub('^LFQ\\.intensity\\.([^_]+)_\\d+$', 
             '\\1', 
             names(pg)[lfq_columns]))

for(experiment in experiments) { #calculate means for each experiment
  experiment_columns <- # which columns are related to the experiment
    grep(paste0('imputed\\.log2\\.LFQ\\.intensity\\.',experiment), names(pg))
  pg[paste0('mean_',experiment)] <- # new column starting with mean_ and experiment
    rowMeans(pg[experiment_columns])
}

for(comparison in comparison_list) {
  exp_t <- experiments[comparison[1]] # treatment
  exp_c <- experiments[comparison[2]] # control
  difference <- # calculate x axis of volcano
    pg[[paste0('mean_',exp_t)]] - pg[[paste0('mean_',exp_c)]]
  
  cols_t <- # get the correct columns for treatment
    grep(paste0('imputed\\.log2\\.LFQ\\.intensity\\.',exp_t), names(pg))
  cols_c <- # get the correct columns for control
    grep(paste0('imputed\\.log2\\.LFQ\\.intensity\\.',exp_c), names(pg))
  
  # calculating for the cols_t and cols_c the p value
  p_values <- apply(pg[c(cols_t, cols_c)], 1, function(x) {
    t.test(x[1:length(cols_t)], x[(length(cols_t) + 1):length(x)])$p.value
  })
  adjusted_p_values <- p.adjust(p_values, 'BH')
  
  # creating a data frame for plotly
  df <- data.frame(differenc=difference,
                   # p_value=-log10(p_values),
                   p_value=-log10(adjusted_p_values),
                   protein_ids=as.character(pg[['Protein.IDs']]))
  # do a plotly with mouse over and shit
  p <- 
    plot_ly(df, x=difference, y=p_value, text=protein_ids,
            mode='markers', marker=list(symbol='circle-open'))
  p <- layout(p,
              xaxis=list(title=sprintf('difference (%s - %s)', exp_t, exp_c)),
              yaxis=list(title='adjusted p value'))
  print(p)
  
  readline('hit RETURN to continue')
}


