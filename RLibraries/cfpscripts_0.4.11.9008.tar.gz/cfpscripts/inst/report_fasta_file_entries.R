###############################################################################
#
# This script will check for all fasta file within a folder the number of 
# entries and some other hopefully usefull statistics.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.3
# date: 2019.01.16
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(readr)
library(rMQanalysis)

data_dir <- '.'

file_endings <- c('fasta','fa')

faste_file_pattern <- paste(paste0('\\.', file_endings, '$'), collapse='|')

fasta_files <- list.files(path=data_dir, 
                          pattern=faste_file_pattern,
                          full.names=TRUE,
                          recursive=FALSE)
fasta_files <- grep('NCBI', fasta_files, value=TRUE, invert=TRUE)
count_df <- data.frame()
sink(file.path(data_dir, 
               sprintf('sequence_count_%s.txt', 
                       format(Sys.time(), "%Y%m%d"))), 
     type = "output", split=TRUE)

f <- function(x, pos) x[grepl('^>', x)]

files_skipped <- c()

system.time(for(fasta_file in fasta_files) {
  # fdata <- seqinr::read.fasta(fasta_file, seqtype='AA', as.string=T) 
  cat(sprintf('%s\n', fasta_file)) 
  if(file.size(fasta_file) > 900000000) {
    cat(sprintf('Filesize is bigger then 900MB so we skip this file.\n\n'))
    files_skipped <- c(files_skipped, fasta_file)
    next()
  }
  # fdata <- readLines(pipe(paste0('grep "^>" "', fasta_file, '"')))
  fdata <- unique(unlist(
    readr::read_lines_chunked(fasta_file, 
                              readr::ListCallback$new(f), 
                              chunk_size=50000)))
  cat(sprintf('%d sequences\n', length(fdata))) 
  os_definition <- grepl('OS=', fdata)
  if(sum(os_definition) != length(fdata)) {
    cat(sprintf('%d entries (%.2f%%) miss a species definition.\n',
                sum(!os_definition), 
                sum(!os_definition) / length(fdata) * 100))
  }
  species_table <- table(sub('.+OS=([^=]+) [A-Z]{2}=.*|.+OS=([^=]+)$', '\\1\\2', fdata))
  if(length(species_table) > 1) {
    cat(sprintf('There seems more than 1 species in the fasta file, here are the top 5:'))
    print(head(sort(species_table, decreasing=TRUE), 5))
    #     cat(sprintf('And again in percent:\n'))
    #     print(head(sort(species_table, decreasing=TRUE)/length(fdata)*100, 5))
  } else {
    cat(sprintf('The fasta file contains only 1 species: %s',
                names(species_table)))
  }
  cat('\n\n')
  count_df <- rbind(count_df, data.frame(file=fasta_file,
                                         total=length(fdata),
                                         high_abundant_organism=names(head(sort(species_table, decreasing=TRUE), 1)),
                                         high_abundant_count=head(sort(species_table, decreasing=TRUE), 1),
                                         high_abundant_amount=round(head(sort(species_table, decreasing=TRUE), 1)/length(fdata)*100,2)))
})
sink()


rownames(count_df) <- NULL
write.table_imb(count_df, 
                file.path(data_dir, 
                          sprintf('sequence_count_table_%s.txt', 
                                  format(Sys.time(), "%Y%m%d"))))

if(length(files_skipped) > 0) {
  cat(sprintf('!!!\nWe skipped "%s" because to they are bigger than 900MB!\n!!!',
                paste(files_skipped, collapse=', ')))
}

library(ggplot2)


count_df$organism <- gsub('\\./(.*)_\\d{8}\\.fasta', '\\1', count_df$file)
count_df$year <- as.numeric(gsub('.*_(\\d{4})\\d{4}\\.fasta', '\\1', count_df$file))

count_df <- na.omit(count_df)


ggplot(count_df, aes(organism, total, fill=factor(year))) +
  geom_bar(stat='identity', position=position_dodge()) + 
  geom_text(aes(label=total), position=position_dodge(width=1), hjust=0) +
  scale_y_continuous(limits=c(0,700000)) +
  coord_flip() +
  theme_bw(8)
# theme(axis.text.x=element_text(angle=90, vjust=.5, hjust=1))

ggsave('sequence_count_comparison.pdf', width=8.27, height=11.69)

