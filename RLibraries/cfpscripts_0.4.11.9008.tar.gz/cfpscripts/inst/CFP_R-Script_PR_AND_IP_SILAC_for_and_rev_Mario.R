#
# package version: 0.4.10
# package date: 2018-05-25

rm(list = ls()) # remove most objects from the working environment
library(rMQanalysis)
library(ggplot2)

cat(getwd()) # sets working directory

###############################################################################
# define some variables
name_for <- 'CF_0141' # name the experiment, will be automatic later
name_rev <- 'CF_0142'

###############################################################################
# read some files
data_directory <- file.path('combined','txt') # where are the txt files located
summary <- read.delim(file.path(data_directory,'summary.txt'))
proteinGroups <- read.delim(file.path(data_directory,'proteinGroups.txt'))
peptides <- read.delim(file.path(data_directory,'peptides.txt'))


###############################################################################
# read infos from the files
#sample_data$enzymes <- as.character(summary$Enzyme[1]) # get the digesting enzyme
sample_data <- list(enzymes=summary$Enzyme)

###############################################################################
# filter the proteinGroups 
data <- filterWholeDataset(proteinGroups)
data_filtered <- filterIdentifiedProteins(data)

###############################################################################
# write this filtered dataset to a file
write.table_imb(data_filtered, 
            file=sprintf("proteinGroups_%s_%s.txt",name_for,name_rev))


###############################################################################
# now delete the unimportant columns and save this to a file
column_to_keep <- c("Fasta.headers","Protein.names","Gene.names",
        "Mol..weight..kDa.","Sequence.coverage....","Sequence.length",
        "Ratio.H.L.for","Ratio.H.L.normalized.for","Ratio.H.L.count.for",
        "Ratio.H.L.rev","Ratio.H.L.normalized.rev", "Ratio.H.L.count.rev", 
        "Sequence.coverage.for....","Sequence.coverage.rev....",
        "Razor...unique.peptides.for","Unique.peptides.for",
        "Razor...unique.peptides.rev","Unique.peptides.rev",
        "Intensity.L.for", "Intensity.H.for",
        "Intensity.L.rev", "Intensity.H.rev")
data_filtered <- data_filtered[column_to_keep]
write.table_imb(data_filtered, 
            file=sprintf("proteinGroups_%s_%s_filtered.txt",name_for,name_rev))

cat(nrow(data_filtered))


###############################################################################
# checking for missed Cleavage
# remove contaminants etc
peptides_filtered <- filterWholeDataset(peptides)

# create data frame for the missed cleavage data
missed_cleavages_df <- getMissedCleavageDF(peptides_filtered)
missed_cleavages_plot <- plotMissedCleavages(missed_cleavages_df,sample_data)
print(missed_cleavages_plot)

ggsave(sprintf('Missed Cleavage_%s_%s.png',name_for,name_rev),
       missed_cleavages_plot)



#--Calculating-for-and-reverse--------------------------------------------------------------------------------
  
data_for_rev_filtered <- data[which(data$Razor...unique.peptides.for >= 2 & 
                  data$Unique.peptides.for >= 1 & 
                  data$Ratio.H.L.for >0 &
                  data$Razor...unique.peptides.rev >= 2 & 
                  data$Unique.peptides.rev >= 1 & 
                  data$Ratio.H.L.rev >0 ),]
columns_to_keep <- c("Fasta.headers","Protein.names","Gene.names",
          "Mol..weight..kDa.","Sequence.coverage....","Sequence.length",
          "Ratio.H.L.for","Ratio.H.L.normalized.for","Ratio.H.L.count.for",
          "Ratio.H.L.rev","Ratio.H.L.normalized.rev", "Ratio.H.L.count.rev", 
          "Sequence.coverage.for....","Sequence.coverage.rev....",
          "Razor...unique.peptides.for","Unique.peptides.for",
          "Razor...unique.peptides.rev","Unique.peptides.rev",
          "Intensity.L.for", "Intensity.H.for",
          "Intensity.L.rev", "Intensity.H.rev")
data_for_rev_filtered <- data_for_rev_filtered[columns_to_keep]
bb <- nrow(data_for_rev_filtered)
write.table_imb(data_for_rev_filtered, 
                file=sprintf("proteinGroups_%s_%s_filtered_SILAC ratio.txt",
                             name_for,
                             name_rev))

gene_names <- 
  sapply(strsplit(as.character(data_for_rev_filtered$Gene.names),
                  ";",fixed=T),
         "[",1) # Zerhackt die Namen nach ; und behaellt den Ersten
            
h_for <-log2(data_for_rev_filtered$Ratio.H.L.for)
r_for <- round(median(data_for_rev_filtered$Ratio.H.L.for, na.rm = FALSE),2)
h_norm_for <-log2(data_for_rev_filtered$Ratio.H.L.normalized.for)
h_rev <-log2(1/data_for_rev_filtered$Ratio.H.L.rev)
r_rev <- round(median((1/data_for_rev_filtered$Ratio.H.L.rev), na.rm = FALSE),2)
h_norm_rev <-log2(1/data_for_rev_filtered$Ratio.H.L.normalized.rev)
      
breaks <-50
histrv<-hist(h_for, breaks = breaks)
Frequency1 <- max(histrv$counts)*0.8
histrv<-hist(h_rev, breaks = breaks)
Frequency2 <- max(histrv$counts)*0.8
      
par(mfrow=c(2,2))
hist(h_for, main=sprintf('%s\nMedian-Ratio:%s',name_for, r_for),xlab= "LOG2 (H/L)",ylab= "Frequency",
     breaks = 50, col='grey',xlim = c(-5, 5))
hist(h_norm_for, main=sprintf("%s normalized",name_for),xlab= "LOG2 (H/L)",ylab= "Frequency",
     breaks = breaks, col='grey',xlim = c(-5, 5))
     
hist(h_rev, main=sprintf('%s\nMedian-Ratio:%s',name_rev, r_rev),xlab= "LOG2 (L/H)",ylab= "Frequency",
     breaks = breaks, col='grey',xlim = c(-5, 5))
hist(h_norm_rev, main=sprintf("%s normalized",name_rev),xlab= "LOG2 (L/H)",ylab= "Frequency",
     breaks = breaks, col='grey',xlim = c(-5, 5))
      
dev.copy(pdf,sprintf('Histogram_%s_%s.pdf',name_for,name_rev))
dev.off()
      
par(mfrow=c(1,1))
plot(h_norm_for, h_norm_rev, main="Scatterplot",xlim = c(-10, 10),ylim = c(-10, 10),
     xlab=sprintf("LOG2 %s",name_for), ylab=sprintf("LOG2 1/(%s)",name_rev), cex=1 )
abline(v=(0),h=(0),col="grey")
abline (v=c(1,-1), h=c(1, -1), col="red",lty=2)
identify (h_norm_for, h_norm_rev, cex=0.5, labels=(gene_names))
dev.copy(pdf,sprintf('Scatterplot_%s_%s.pdf',name_for,name_rev))
dev.off() 
      
#--SILAC-ProteinGroups-ID----------------------------------------------------------------------------------------------
nrow(data[which(data$Razor...unique.peptides.for >= 2 & data$Unique.peptides.for >= 1 & data$Ratio.H.L.for >0),])
nrow(data[which(data$Razor...unique.peptides.rev >= 2 & data$Unique.peptides.rev >= 1 & data$Ratio.H.L.rev >0),])
