# Multi species workflow start MQ
#
# This script is designed to setup all species and start MQ sequentially. It 
# will further create a complete proteinGroups.txt and peptides.txt file out of
# all the elements in species list.
# For further processing, it will save an multi_species.Rdata file, which has
# informations about the species, path to files, etc.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.6
# date: 2017.02.06
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(rMQanalysis)
library(dplyr)
library(reshape2)

global_fasta_path <- file.path('E:','Fasta_UNIPROT','EvoAnnotate','86')
global_project_path <- file.path('E:','EvoAnnotate')
global_protein_standards <- 
  # set to NULL in case you don't use any standard or fasta used in all analysis
  c(file.path('E:','Fasta_UNIPROT', 'UPS', 'ups1-ups2-sequences.fasta'))

max_quant_command <- 'C:\\Users\\proteomics\\Desktop\\MaxQuant 1.5.2.8 - EVOREG\\bin\\MaxQuantCmd.exe'

cores <- 12 # should be the same as the number of raw files per species

Species <- function(full, short, abb,
                    path, fastas, raw) {
  if(!all(grepl('.raw$', raw))) {
    warning(sprintf('Some rawfiles in %s have the wrong file ending!', full), 
            immediate.=TRUE, call.=FALSE)
  }
  if(!all(grepl('.fasta$|.fa$', fastas))) {
    warning(sprintf('Some fasta files in %s have the wrong file ending!', full),
            immediate.=TRUE, call.=FALSE)
  }
  species <- list(
    full_name=full,
    short_name=short,
    abbreviation=abb,
    project_path=path,
    fasta_files=fastas,
    raw_files=raw
  )
  return(species)
}

rawFileNameConstructor <- function(basename,
                                   replicates=c(1,2,3,4),
                                   slices=c('a','b','c')) {
  paste0(basename,
         rep(replicates, each=length(slices)),
         slices,
         '.raw')
}

species_list <- list(
  human=Species(
    full='Homo sapiens', short='human', abb='hs',
    path=file.path(global_project_path, '2016_11_11_EVO_human'),
    fastas=c(global_protein_standards,
             file.path(global_fasta_path, 
                       c('Homo_sapiens.GRCh38.pep.all.fa',
                         'Homo_sapiens.GRCh38.pep.abinitio.fa',
                         'merged_peptides_human.fasta'))),
    # the rawfiles will be created with this function. Adapt the function to 
    # your filenames. I suggest filename_1a for first replicate upper slice.
    raw=rawFileNameConstructor('20150909_QEP2_FBU_NC_EvoReg_HeLa_reTryp_')),
  
  chicken=Species(
    full='Gallus gallus', short='chicken', abb='gg',
    path=file.path(global_project_path, '2016_11_11_EVO_chicken'),
    fastas=c(global_protein_standards,
             file.path(global_fasta_path, 
                       c('Gallus_gallus.Gallus_gallus-5.0.pep.all.fa',
                         'Gallus_gallus.Gallus_gallus-5.0.pep.abinitio.fa',
                         'merged_peptides_chicken.fasta'))),
    raw=rawFileNameConstructor('20150822_QEP2_FBU_NC_EvoReg_chicken_reTryp_')),
  
  cow=Species(
    full='Bos taurus', short='cow', abb='bt',
    path=file.path(global_project_path, '2016_11_11_EVO_cow'),
    fastas=c(global_protein_standards,
             file.path(global_fasta_path, 
                       c('Bos_taurus.UMD3.1.pep.all.fa',
                         'Bos_taurus.UMD3.1.pep.abinitio.fa',
                         'merged_peptides_cow.fasta'))),
    raw=rawFileNameConstructor('20141112_QEP2_FBU_FB_EVO_cow_')),
  
  duck=Species(
    full='Anas platyrhynchos', short='duck', abb='ap',
    path=file.path(global_project_path, '2016_11_11_EVO_duck'),
    fastas=c(global_protein_standards,
             file.path(global_fasta_path, 
                       c('Anas_platyrhynchos.BGI_duck_1.0.pep.all.fa',
                         'Anas_platyrhynchos.BGI_duck_1.0.pep.abinitio.fa',
                         'merged_peptides_duck.fasta'))),
    raw=rawFileNameConstructor('20150906_QEP2_FBU_NC_EvoReg_duck_reTryp_')),
  
  mouse=Species(
    full='Mus musculus', short='mouse', abb='mm',
    path=file.path(global_project_path, '2016_11_11_EVO_mouse'),
    fastas=c(global_protein_standards,
             file.path(global_fasta_path, 
                       c('Mus_musculus.GRCm38.pep.all.fa',
                         'Mus_musculus.GRCm38.pep.abinitio.fa',
                         'merged_peptides_mouse.fasta'))),
    raw=rawFileNameConstructor('20141112_QEP2_FBU_FB_EVO_mouse_')),
  
  tasdev=Species(
    full='Sarcophilus harrisii', short='tasdev', abb='sh',
    path=file.path(global_project_path, '2016_11_11_EVO_tasdev'),
    fastas=c(global_protein_standards,
             file.path(global_fasta_path, 
                       c('Sarcophilus_harrisii.DEVIL7.0.pep.all.fa',
                         'Sarcophilus_harrisii.DEVIL7.0.pep.abinitio.fa',
                         'merged_peptides_tasdev.fasta'))),
    raw=rawFileNameConstructor('20141112_QEP2_FBU_FB_EVO_tasdev_')),
  
  xenopus=Species(
    full='Xenopus tropicalis', short='xenopus', abb='xt',
    path=file.path(global_project_path, '2016_11_11_EVO_xenopus'),
    fastas=c(global_protein_standards,
             file.path(global_fasta_path, 
                       c('Xenopus_tropicalis.JGI_4.2.pep.all.fa',
                         'Xenopus_tropicalis.JGI_4.2.pep.abinitio.fa',
                         'merged_peptides_xenopus.fasta'))),
    raw=rawFileNameConstructor('20141112_QEP2_FBU_FB_EVO_frog_')),
  
  zebrafish=Species(
    full='Danio rerio', short='zebrafish', abb='dr',
    path=file.path(global_project_path, '2016_11_11_EVO_zebrafish'),
    fastas=c(global_protein_standards,
             file.path(global_fasta_path, 
                       c('Danio_rerio.GRCz10.pep.all.fa',
                         'Danio_rerio.GRCz10.pep.abinitio.fa',
                         'merged_peptides_zebrafish.fasta'))),
    raw=rawFileNameConstructor('20150924_QEP2_FBU_NC_EvoReg_zebrafish_reTryp_')),
  
  zebrafinch=Species(
    full='Taeniopygia guttata', short='zebrafinch', abb='tg',
    path=file.path(global_project_path, '2016_11_11_EVO_zebrafinch'),
    fastas=c(global_protein_standards,
             file.path(global_fasta_path, 
                       c('Taeniopygia_guttata.taeGut3.2.4.pep.all.fa',
                         'Taeniopygia_guttata.taeGut3.2.4.pep.abinitio.fa',
                         'merged_peptides_zebrafinch.fasta'))),
    raw=rawFileNameConstructor('20141112_QEP2_FBU_FB_EVO_zebrafinch_'))
)

save(species_list, file='multi_species.Rdata')


# modifying the mqpar parameter file --------------------------------------

modifyMQParamFile <- function(species, cores=1, template='mqpar_template.txt') {
  # mqpar <- readLines(system.file('multi_species','mqpar_template.txt', 
  #                                package='cfpscripts'))
  mqpar <- readLines('mqpar_template.txt')
  fasta_names <- paste0(
    '<string>', 
    gsub('/', '\\\\\\\\',
         file.path(species$fasta_files)),
    '</string>', collapse='\n')
  
  raw_names <- paste0(
    '<string>', 
    gsub('/', '\\\\\\\\',
         file.path(species$project_path, 
                   species$raw_files)),
    '</string>', collapse='\n')
  
  mqpar <- sub('XXX__FASTADB__XXX', fasta_names, mqpar)
  mqpar <- sub('XXX__RAWFILES__XXX', raw_names, mqpar)
  mqpar <- sub('XXX__CORES__XXX', cores, mqpar)
  return(mqpar)
}


# Creating all mqpar.xml files --------------------------------------------

cmd_list <- list()
for(species in species_list) {
  cat(sprintf('%s: writing mqpar.xml on %s.\n',
              Sys.time(), species$full_name))
  
  mqpar <- modifyMQParamFile(species, cores=cores)
  writeLines(mqpar, file.path(species$project_path, 'mqpar.xml'))
  
  cmd_list[species$full_name] <- 
    sprintf('"%s" "%s"', 
            max_quant_command, file.path(species$project_path, 'mqpar.xml'))
}

cat(sprintf('\n%s: writing mqpar.xml DONE.\n\n', Sys.time()))


# starting MQ sequentially ------------------------------------------------

for(full_name in names(cmd_list)) {
  cat(sprintf('%s: start MQ on %s.\n',
              Sys.time(), full_name))
  
  system(cmd_list[[full_name]], wait=TRUE)
}

cat(sprintf('\n%s: MQ analysis DONE.\n\n', Sys.time()))


# Reading proteinGroups into a table --------------------------------------

proteinGroups <- list()

for(species in species_list) {
  data_dir <- file.path(species$project_path, 'combined','txt')
  file_name <- file.path(data_dir, 'proteinGroups.txt')
  
  if(file.exists(file_name)) {
    proteinGroups[[species$short_name]] <- 
      cbind(species=species$short_name,
            rMQanalysis::read_MQtsv(file_name))
    
    cat(sprintf('%s: %s proteinGroups file read.\n', 
                Sys.time(), species$short_name))
  } else {
    cat(sprintf('%s: "%s" does not exist.\n',
                species$short_name, file_name))
  }
}

cat(sprintf('%s: proteinGroups files read.\n', Sys.time()))
proteinGroups <- dplyr::bind_rows(proteinGroups)

proteinGroups[['Potential contaminant']][is.na(proteinGroups[['Potential contaminant']])] <- ''
proteinGroups[['Reverse']][is.na(proteinGroups[['Reverse']])] <- ''
proteinGroups[['Only identified by site']][is.na(proteinGroups[['Only identified by site']])] <- ''

write.table_imb(proteinGroups, 'combined_proteinGroups.txt')
cat(sprintf('\n%s: combined proteinGroups file written.\n\n', Sys.time()))


# Reading peptides into a table --------------------------------------

peptides <- list()

for(species in species_list) {
  data_dir <- file.path(species$project_path, 'combined','txt')
  file_name <- file.path(data_dir, 'peptides.txt')
  
  if(file.exists(file_name)) {
    peptides[[species$short_name]] <- 
      cbind(species=species$short_name,
            rMQanalysis::read_MQtsv(file_name))
    
    cat(sprintf('%s: %s peptides file read.\n', 
                Sys.time(), species$short_name))
  } else {
    cat(sprintf('%s: "%s" does not exist.\n',
                species$short_name, file_name))
  }
}

cat(sprintf('%s: peptides files read.\n', Sys.time()))
peptides <- dplyr::bind_rows(peptides)
write.table_imb(peptides, 'combined_peptides.txt')
cat(sprintf('\n%s: combined peptides file written.\n\n', Sys.time()))

columns_to_keep <- 
  c('species', 'Protein IDs', 'Majority protein IDs', "Fasta headers", 
    "Peptides", "Razor + unique peptides", 
    "Unique peptides",
    grep('Intensity', names(proteinGroups), value=TRUE),
    grep('iBAQ', names(proteinGroups), value=TRUE),
    grep('LFQ', names(proteinGroups), value=TRUE),
    'id',"Only identified by site", "Reverse", "Potential contaminant")

pg_slim <- proteinGroups[columns_to_keep]

write.table_imb(pg_slim, 'combined_proteinGroups_reduced.txt')

pg_flt <- filter(pg_slim,
                 `Potential contaminant` != '+' & 
                   `Reverse` != '+' & 
                   `Only identified by site` != '+')
pg_ident <- filter(pg_flt,
                   `Razor + unique peptides` >= 2 & 
                     `Unique peptides` >= 1)

count_stat <- 
  proteinGroups %>%
  group_by(species) %>%
  summarise(contaminants=sum(`Potential contaminant` == '+'),
            reverse=sum(`Reverse` == '+'),
            bySite=sum(`Only identified by site` == '+'),
            ENS=sum(grepl('ENS.?.?.?P', `Protein IDs`)),
            GENSCAN=sum(grepl('GENSCAN', `Protein IDs`)),
            TCON=sum(grepl('TCON', `Protein IDs`)),
            GENSCAN_only=sum(grepl('GENSCAN', `Protein IDs`) & !grepl('TCONS', `Protein IDs`) & !grepl('ENS.?.?.?P', `Protein IDs`)),
            GENSCAN_TCON=sum(grepl('GENSCAN', `Protein IDs`) & grepl('TCONS', `Protein IDs`)),
            TCON_only=sum(grepl('TCONS', `Protein IDs`) & !grepl('GENSCAN', `Protein IDs`) & !grepl('ENS.?.?.?P', `Protein IDs`)),
            proteinGroups=n()) %>% 
  mutate(type='without filtering')



ggplot(melt(count_stat[-12], 'species'), aes(species, value, fill=species)) +
  ggtitle('count stats on all species') +
  geom_bar(stat='identity') + 
  facet_wrap(~ variable, scales='free_y') + 
  theme(axis.text.x=element_text(angle=90,vjust=.25, hjust=1))
ggsave('count_stat_before_filtering.pdf', width=11.69, height=8.27)



count_stat_ident <- 
  pg_ident %>%
  group_by(species) %>%
  summarise(ENS=sum(grepl('ENS.?.?.?P', `Protein IDs`)),
            GENSCAN=sum(grepl('GENSCAN', `Protein IDs`)),
            TCON=sum(grepl('TCON', `Protein IDs`)),
            GENSCAN_only=sum(grepl('GENSCAN', `Protein IDs`) & !grepl('TCONS', `Protein IDs`) & !grepl('ENS.?.?.?P', `Protein IDs`)),
            GENSCAN_TCON=sum(grepl('GENSCAN', `Protein IDs`) & grepl('TCONS', `Protein IDs`)),
            TCON_only=sum(grepl('TCONS', `Protein IDs`) & !grepl('GENSCAN', `Protein IDs`) & !grepl('ENS.?.?.?P', `Protein IDs`)),
            proteinGroups=n()) %>% 
  mutate(type='with filtering')

ggplot(melt(count_stat_ident[-9], 'species'), aes(species, value, fill=species)) +
  ggtitle('count stats after removing contaminants etc.') +
  geom_bar(stat='identity') + 
  facet_wrap(~ variable, scales='free_y') + 
  theme(axis.text.x=element_text(angle=90,vjust=.25, hjust=1))
ggsave('count_stat_after_filtering.pdf', width=11.69, height=8.27)


counts <- rbind(count_stat[-c(2,3,4)], count_stat_ident)
counts$type <- factor(counts$type, levels=(c('without filtering','with filtering')))
ggplot(melt(counts, c('species', 'type')), aes(species, value, fill=type)) +
  ggtitle('count stats before and after filtering') +
  geom_bar(stat='identity', position=position_dodge()) + 
  facet_wrap(~ variable, scales='free_y') + 
  theme(axis.text.x=element_text(angle=90,vjust=.25, hjust=1))
ggsave('count_stat_filtering_comparison.pdf', width=11.69, height=8.27)






