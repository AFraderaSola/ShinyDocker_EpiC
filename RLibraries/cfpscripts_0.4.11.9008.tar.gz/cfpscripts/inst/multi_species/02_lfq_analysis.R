# This will be a multi species LFQ script. 
#
# This script will work on mupltiple species and will do the LFQ analysis.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.1
# date: 2017.02.07
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################


# library(biomaRt)
library(reshape2)
library(ggplot2)
library(RColorBrewer)
library(gplots)
library(dplyr)
library(ggrepel)
library(grid)
library(gridExtra)
library(seqinr)
library(stringr)

library(rMQanalysis)


# setting up common settings ----------------------------------------------

load('multi_species.Rdata')

out_dir <- 'main_data_out_05' # output directory for any written file
if(!file.exists(out_dir)) dir.create(out_dir)

# reading and filtering the protein groups
data_dir <- '.' # path to data directory, RELATIVE to THIS MARKDOWN document! 
# Set to "." if it is in the same directory! RECOMMENDED!
# pg_filename <- 'combined_proteinGroups_MSTEP.txt' # The protein groups file name
pg_filename <- 'combined_proteinGroups.txt' # The protein groups file name
razor_peptides <- 2 # minimum razor+unique peptide count for the whole protein group
unique_peptides <- 1 # minimum unique peptide count for the whole protein group
min_quant_events <- 2 # at least measured X times in any experiment replicate

# write output files
pg_basename <- sub('.txt$', '', pg_filename)
pg_quant_filename <- paste0('quantified_', pg_basename, '.txt') 
pg_volcano_filename <- paste0('volcano_', pg_basename, '.txt')



# imputing settings -------------------------------------------------------

impute_method <- 'beta' # can be "beta", "norm" or "original"
beta_min <- 0.001 # Check ?imputeBetaRandomNumbersPerColumn
beta_max <- 0.015
norm_modify_mean <- -4 # Check ?imputeNormRandomNumbersPerColumn
norm_sd_factor <- .2
random_seed <- 1234
original_na_replace <- 0.001
original_average_function <- 'mean'



# main graph settings -----------------------------------------------------

# creating plots for different experiments
compare_to_experiment <- NULL # the standard we compare to (index of experiments). 
# Set to NULL to compare all. You can check this after executing the first few chunks and
# print(experiments) to see the order.
reverse_comparison <- TRUE # Set to TRUE to get the control on the right side of the
# volcano plots.

# using the new getLabel function. Check ?getLabel for more information.
label_column <- 'Gene.names' # set to Gene.names if it is available
label_column_regex <- '' # set to '([^;]+).*' to use as is
fallback_column <- 'Protein.IDs'
fallback_column_regex <- '([^;]+).*' # set to '([^;]+).*' to get just the first ID
# some regular expression examples
#   '([^ ]+).*' # only the first word of the header
#   '([^;]+).*' # only the first protein ID

# Creating correlation heatmap and PCA of the LFQ intensities.
heatmap_column_regex <- '^imputed.log2.LFQ.intensity.' 
heatmap_white_area_size <- 1 # 1 == same area than blue, 2 means the white area 
# is 2 times bigger then the blue area, or the white are is 66% of the spectra
pca_column_regex <- 'imputed.log2.LFQ.intensity.' 
# use '^log2.LFQ.intensity' to create heatmap on measured without imputed values

# highlight important protein IDs. Provide a textfile in the format as highlight.txt!
highlight_file <- 'highlight.txt'




# volcano plot settings ---------------------------------------------------


# Volcano plot setting to write PDF files
do_volcano <- TRUE # switch of volcano plot drawing.
create_volcano_pdfs <- TRUE # If you want to create PDFs
volcano_height <- 8.27 # you might change the pdf size together with the font size
volcano_width <- 11.69
font_size <- 2
volcano_threshold_linetype <- 2
volcano_threshold_linesize <- 0.5
create_volcano_enriched_files <- TRUE # write the enrichment files
# To calculate the difference between two conditions, we substract the mean or median 
# values. There are several possibilities ("median/mean2_naimp_meas_", "median/mean1_meas_" 
# and "mean/median3_less1_imp_"). Check chapter "Calculating mean and median values" to 
# get a description about the column meaning.
difference_volcano_column <- 'mean3_less1_imp_'
# the threshold we use for enrichment
enrich_c <- .5
enrich_s0 <- .5
enrich_pvalue <- .05

ggrepel_threshold <- 150

filter_separately <- TRUE # filters before each volcano plot the quantified proteins
# for the specific experiment comparison. So subseting to at least one of the conditions
# has more or equal min_quant_events.


# scatter plot settings ---------------------------------------------------

do_scatter <- TRUE
scatter_upper_threshold <- 1
scatter_lower_threshold <- 1
scatter_density <- .2
scatter_size <- 1.5
# median1_meas_ will plot the median measured values without imputed, labeling might fail
# median3_less1_imp_ will plot the median measured values and missing values get imputed
difference_scatter_column <- 'mean1_meas_' 
create_scatter_enriched_files <- TRUE
create_scatter_pdfs <- TRUE
scatter_height <- 8 # you might change the pdf size together with the font size
scatter_width <- 8



# reading, filtering the data ---------------------------------------------

pg <- read.delim(file.path(data_dir,pg_filename))
pg <- filter(pg, species != 'Scerevisiae')
pg_flt <- filterWholeDataset(pg)
pg_ident <- filterIdentifiedProteins(pg_flt, razor_peptides, unique_peptides)



# retreive gene names -----------------------------------------------------

has_description <- grepl('description:', pg_ident$Fasta.headers)
pg_ident$description <- ''
pg_ident$description[has_description] <-
  sub('.*\\ description:([^;]+)', '\\1', pg_ident$Fasta.headers[has_description])

has_gene <- grepl('gene:', pg_ident$Fasta.headers)
pg_ident$Gene.names <- ''
pg_ident$Gene.names[has_gene] <-
  sub('.*\\ gene:([^\\ ]+).*', '\\1', pg_ident$Fasta.headers[has_gene])

# listMarts()
# connection <- useMart('ENSEMBL_MART_FUNCGEN')
# listDatasets(connection)

# cleaning column names ---------------------------------------------------

experiments <- rMQanalysis::getExperiments(pg)

## TODO put this into a function like cleanExperimentNames
if(any(grepl('\\.', experiments))) {
  experiments_save <- gsub('\\.', '', experiments)
  for(i in seq_along(experiments)) {
    names(pg) <- gsub(experiments[[i]], experiments_save[[i]], names(pg))
    names(pg_flt) <- gsub(experiments[[i]], experiments_save[[i]], names(pg_flt))
    names(pg_ident) <- gsub(experiments[[i]], experiments_save[[i]], names(pg_ident))
  }
  experiments <- rMQanalysis::getExperiments(pg)
  warning('we had to remove "." from the experiment names.', call.=FALSE)
}

replicates <- unique(gsub('^LFQ\\.intensity\\..*_(\\d+)',
                          '\\1',
                          grep('^LFQ',names(pg),value=TRUE)))


# log transform and impute columns -------------------------------------------

lfq_columns <- grep('^LFQ', names(pg_ident))
pg_ident[lfq_columns][ pg_ident[lfq_columns] == 0 ]  <- NA
pg_ident <- 
  cbind(pg_ident,
        log2=log2(pg_ident[lfq_columns]))

imputed_values_list <- 
  lapply(unique(pg_ident$species), function(x) {
    switch(impute_method,
           beta=filter(pg_ident, species == x) %>%
             select(starts_with('log2.LFQ')) %>%
             imputeBetaRandomNumbersPerColumn(
               .,
               beta_min,beta_max,
               seed=random_seed),
           norm=filter(pg_ident, species == x) %>%
             select(starts_with('log2.LFQ')) %>%
             imputeNormRandomNumbersPerColumn(
               .,
               modify_mean=norm_modify_mean,
               sd_factor=norm_sd_factor,
               seed=random_seed),
           original=filter(pg_ident, species == x) %>%
             select(starts_with('log2.LFQ')) %>%
             imputeOriginalDistributionPerExperiment(
               .,
               na_replace=original_na_replace,
               average_function=original_average_function,
               seed=random_seed),
           stop('please set a correct impute_method!'))
  })

# filter(pg_ident, species == x) %>%
#   select(starts_with('log2.LFQ')) %>%
#   imputeBetaRandomNumbersPerColumn(
#     .,
#     beta_min,beta_max,
#     seed=random_seed)
names(imputed_values_list) <- unique(pg_ident$species)

imputed_values_df <- bind_rows(lapply(imputed_values_list, 
                                      '[[', 
                                      'imputed_values'), .id='species')

pg_ident <- cbind(pg_ident, imputed_values_df[-1])


imputed_values_histogram <- bind_rows(lapply(imputed_values_list, 
                                             '[[', 
                                             'imputed_histogram'), .id='species')

imputed_values_histogram$column <- 
  sub('log2.LFQ.intensity.', '', imputed_values_histogram$column)
imputed_values_histogram$column <- 
  sub('_', ' repl.:', imputed_values_histogram$column)
graph_imputed_values <- 
  plotImputedValues(imputed_values_histogram, ncol=length(replicates)) +
  xlab('log2( LFQ intensity )') + theme_imb(9) + facet_grid(species ~ column)
ggsave(file.path(out_dir, 'imputed_values.pdf'), graph_imputed_values,
       width=8.27, height=11.69)
print(graph_imputed_values)


imputed_bar_df <-
  imputed_values_histogram %>%
  dplyr::group_by(species, column, value_type) %>%
  dplyr::summarise(n=length(value))
graph_imputed_values_bar <-
  ggplot(imputed_bar_df, aes(column, n, fill=value_type)) +
  geom_bar(stat='identity', position=position_dodge(), na.rm=TRUE) +
  ggtitle('comparison imputed vs. measured') +
  facet_wrap(~ species) +
  ylab('count') +
  theme_imb() +
  scale_fill_brewer('', palette='Set1') +
  theme(axis.title.x=element_blank(),
        axis.text.x=element_text(angle=60, hjust=1, vjust=1))
ggsave(file.path(out_dir, 'imputed_values_bar.pdf'), graph_imputed_values_bar,
       width=8.27, height=11.69)
print(graph_imputed_values_bar)


if(impute_method == 'original') {
  imputed_values_data <- bind_rows(lapply(imputed_values_list, 
                                               '[[', 
                                               'imputing_data'), .id='species')
  imputed_values_dis_hist <- bind_rows(lapply(imputed_values_list, 
                                              '[[', 
                                              'dist_hist'), .id='species')
  # print(imputed_values$imputing_data[c(1,4,5)])
  imputed_data2 <- merge(imputed_values_dis_hist, imputed_values_data)
  imputed_data2$title <- sprintf('%s: %s NAs imputed with distribution', imputed_data2$experiment, imputed_data2$NA_values)
  repl_spread_graph <- ggplot(imputed_data2, aes(values)) + 
    geom_histogram(binwidth=.15, na.rm=TRUE) + facet_wrap(species ~ title) +
    ggtitle('replicate distribution per timepoint and # of NAs to impute') +
    theme_imb()
  ggsave(file.path(out_dir, 'replicate_spread.pdf'), repl_spread_graph,
         height=8.27, width=11.69)
  print(repl_spread_graph)
}


intensity_comp_graph <- rMQanalysis::plotIntensityLFQComparison(pg_ident)
ggsave(file.path(out_dir, 'intensity_comparison.pdf'),
       intensity_comp_graph, height=11.69, width=8.27)
print(intensity_comp_graph)



# protein abundance graph -------------------------------------------------

graph_abundance_rank <- rMQanalysis::plotAbundanceRank(pg_ident)
ggsave(file.path(out_dir, 'abundance_rank.pdf'),
       graph_abundance_rank, height=8.27, width=11.69)
print(graph_abundance_rank)



# calculating averages etc ------------------------------------------------

pg_ident <- rMQanalysis::calculateAverages(pg_ident)



# label column ------------------------------------------------------------

pg_ident$my_label <- getLabel(pg_ident, 
                              label_column, fallback_column, 
                              label_column_regex, fallback_column_regex)



# highlight known proteins ------------------------------------------------

pg_ident$highlight <- FALSE
ids_to_highlight <- c()
if(file.exists(highlight_file)) ids_to_highlight <- 
  read.delim(highlight_file, as.is=T)[[1]]
if(length(ids_to_highlight) > 0) {
  ids_searchstring <- paste(ids_to_highlight, collapse='|')
  matching_rows <- grep(ids_searchstring, as.character(pg_ident$Protein.IDs))
  pg_ident$highlight[matching_rows] <- TRUE
}


# filter for quantification -----------------------------------------------

pg_quant <- 
  pg_ident[apply(
    pg_ident[grep('value_count',names(pg_ident))] >= min_quant_events,
    1,
    any),]

pg_data <- rMQanalysis::countProteinGroups(pg, pg_flt, pg_ident)
ggsave(file.path(out_dir, 'protein_counts.pdf'), pg_data$plot,
       width=11.69, height=8.27)
print(pg_data$plot)


write.table_imb(pg_quant,
                file.path(out_dir, pg_quant_filename))




# correlation between replicates heatmap ----------------------------------

replicate_plot_functions <- lapply(unique(pg_ident$species), function(x) {
  filter(pg_quant, species == x) %>%
    select(species, contains(pca_column_regex)) %>%
    rMQanalysis::plotReplicateCorrelation(., 
                                          heatmap_white_area_size, 
                                          heatmap_column_regex)
})

jnk <- lapply(replicate_plot_functions, function(f) f())

pdf(file=file.path(out_dir, 'replicate_correlation_plots.pdf'),
        width=9, height=8, pointsize=8)
jnk <- lapply(replicate_plot_functions, function(f) f())
dev.off()


# PCA analysis ------------------------------------------------------------

prcomp_list <- 
  lapply(unique(pg_ident$species), function(x) {
    filter(pg_quant, species == x) %>%
      select(contains(pca_column_regex)) %>%
      na.omit(.) %>%
      t(.) %>%
      prcomp(., scale.=TRUE)
  })

names(prcomp_list) <- unique(pg_ident$species)



pca_plots <- lapply(names(prcomp_list), 
                    rMQanalysis::multiPCAPlot, 
                    prcomp_list=prcomp_list)

all_pca_filename <- file.path(out_dir, paste0('all_pca_', pg_basename, '_prcomp.pdf'))
pdf(file=all_pca_filename, width=11.69, height=8.27)
jnk <- sapply(pca_plots, function(x) {
  grid.newpage()
  grid.draw(x)
})
jnk <- dev.off()


# preparing the volcano plots ---------------------------------------------

if(is.null(compare_to_experiment)) {
  compare_df <- permuteNames(experiments)
} else {
  compare_df <- permuteNames(experiments, compare_to_experiment)
}
if(reverse_comparison) {
  compare_df <- rev(compare_df)
} else {
  compare_df <- compare_df
} 



replicate_count <- length(replicates)
if(do_volcano & replicate_count > 2) {
  for(line in seq(nrow(compare_df))) {
    exp_a <- compare_df[line,1]
    exp_b <- compare_df[line,2] 
    regex_exp_a <- paste0('^imputed\\..+\\.', exp_a, '_.+')
    regex_exp_b <- paste0('^imputed\\..+\\.', exp_b, '_.+')
    col_a <- grep(regex_exp_a, names(pg_quant))
    col_b <- grep(regex_exp_b, names(pg_quant))
    pvalue_column <- paste('pvalue', exp_a, exp_b, sep='_')
    pg_quant[pvalue_column] <- 
      apply(pg_quant[c(col_a,col_b)],
            1,
            function(x) {
              t.test(x[seq(length(col_a))],
                     x[seq(length(col_b)) + length(col_a)])$p.value
            })
    # pg_quant[paste0('corrected_', pvalue_column)] <- 
    #   p.adjust(pg_quant[[pvalue_column]], 'fdr')
  }
  
  # we have to use a little work around to get the log.pvalue names in case of only one column
  log_pvalues = -log10(pg_quant[grep('^pvalue', names(pg_quant), value=TRUE)])
  colnames(log_pvalues) = paste0('log10.',names(log_pvalues))
  pg_quant <- cbind(pg_quant, log_pvalues)
  max_y_value <- max(pg_quant[grep('^log10.pvalue', names(pg_quant))]) * 1.05
} else {
  if(replicate_count < 3) {
    warning(sprintf('There are to less replicates to create Volcano plots!'))
  }
}


if((do_volcano  & length(replicates) > 2) | do_scatter) {
  for(line in seq(nrow(compare_df))) {
    exp_a <- compare_df[line,1]
    exp_b <- compare_df[line,2] 
    col_a <- paste0(difference_volcano_column, exp_a)
    col_b <- paste0(difference_volcano_column, exp_b)
    difference_column <- paste('difference', exp_a, exp_b, sep='_')
    pg_quant[difference_column] <- 
      pg_quant[col_a] - pg_quant[col_b]
  }
  
  max_x_value <- max(abs(pg_quant[grep('^difference', names(pg_quant))])) * 1.1
  volcano_column_type <- sub('([^[:digit:]]+).*', '\\1', difference_volcano_column)
}

createEnrichmentCurve <- function(c, s0, pvalue=1, step=.01, xlim=50,
                                  linetype=2, size=.1) {
  x <- seq(s0,xlim,step)
  y <- c / (x - s0) + -log10(pvalue)
  return(annotate("path", 
                  x=c(x), 
                  y=c(y), 
                  linetype=linetype, size=size))
}
Enriched <- function(x, y=NULL, c=1, s0=1, pvalue=0.05, ...) {
  if(class(x) == 'data.frame') {
    if(length(x) == 2) {
      y <- x[[2]]
      x <- x[[1]]
    } else {
      stop('x hast to be a data frame with length 2!')
    }
  }
  results <- list()
  results$curve <- createEnrichmentCurve(c, s0, pvalue, ...)
  results$positive <- ( c / (x - s0) - y + -log10(pvalue) <= 0 & x >= s0 )
  results$negative <- ( c / (-x - s0) - y  + -log10(pvalue) <= 0 & -x >= s0 )
  results$enriched <- results$positive | results$negative
  results$background <- !results$enriched
  class(results) <- append(class(results), 'Enriched')
  return(results)
}

if(do_volcano & length(replicates) > 2) {
  for(line in seq(nrow(compare_df))) {
    exp_a <- compare_df[line,1]
    exp_b <- compare_df[line,2] 
    
    if(filter_separately) {
      # This is the part which reduces the background proteins.
      val_count_a <- paste0('value_count_',exp_a) # colname for value count
      val_count_b <- paste0('value_count_',exp_b)
      pg_quant_orig <- pg_quant # saving original pg_quant, because we subset now
      pg_quant <- # subset where value count in ANY of the columns to plot is above threshold
        pg_quant[pg_quant[val_count_a] >= min_quant_events |
                   pg_quant[val_count_b] >= min_quant_events,]
      # we have to save the original pg_quant after EACH volcano plot
    }
    difference <- paste('difference', exp_a, exp_b, sep='_')
    pvalue <- paste('log10.pvalue', exp_a, exp_b, sep='_')
    my_enriched <- Enriched(pg_quant[c(difference, pvalue)],
                            c=enrich_c,
                            s0=enrich_s0,
                            pvalue=enrich_pvalue,
                            linetype=volcano_threshold_linetype,
                            size=volcano_threshold_linesize)
    pg_quant$enriched <- as.factor(my_enriched$positive)
    subtitle <- sprintf('positive: %d; negative: %d; enriched: %d; background: %d; total: %d', 
                        sum(my_enriched$positive), sum(my_enriched$negative), 
                        sum(my_enriched$enriched), sum(my_enriched$background),
                        nrow(pg_quant))
    volcanoplot <- 
      ggplot(pg_quant, aes_string(x=difference, y=pvalue)) + 
      geom_hline(yintercept=0, color='grey80', na.rm=TRUE) +
      geom_vline(xintercept=0, color='grey80', na.rm=TRUE) +
      plot(my_enriched) + # adding the threshold line of our Enriched object
      geom_point(alpha=.5, aes(color=enriched), na.rm=TRUE, 
                 data=subset(pg_quant, highlight == FALSE)) + 
      ggtitle(sprintf('Volcano plot of %s against %s; c:%3.2f S0:%3.2f pvalue:%4.3f\n%s', 
                      exp_a, exp_b, enrich_c, enrich_s0, enrich_pvalue, subtitle)) +
      coord_cartesian(xlim=c(-max_x_value,max_x_value), ylim=c(-.3,max_y_value)) +
      ylab('-log10( pvalue )') + 
      xlab(sprintf('difference: %s %s minus %s %s', 
                   volcano_column_type, exp_a, volcano_column_type, exp_b)) +
      annotate('text', label=exp_a, x=max_x_value / 2, y=-.25) + 
      annotate('text', label=exp_b, x=-max_x_value / 2, y=-.25) +
      geom_point(alpha=1, color='black', data=subset(pg_quant, highlight == TRUE), na.rm=TRUE) +
      geom_text(aes(label=my_label), size=font_size, vjust=1.2, 
                data=subset(pg_quant, highlight == TRUE), na.rm=TRUE) +
      theme_imb(9) + scale_color_brewer(palette='Set2') +
      facet_wrap(~ species)
    if(sum(as.logical(pg_quant$enriched)) > ggrepel_threshold) {
      volcanoplot <- volcanoplot +
        geom_text(aes(label=my_label), size=font_size, vjust=1.2,
                  data=subset(pg_quant, enriched == TRUE), na.rm=TRUE)
    } else {
      volcanoplot <- volcanoplot +
        ggrepel::geom_text_repel(aes(label=my_label), size=font_size,
                                 data=subset(pg_quant, enriched == TRUE), na.rm=TRUE)
    }
    print(volcanoplot)
    out_filename <- sprintf('%s_vs_%s',exp_a,exp_b)
    if(create_volcano_enriched_files) {
      pg_quant_enriched <- 
        pg_quant[as.logical(pg_quant$enriched), -length(pg_quant)]
      
      pg_quant_enriched <- 
        pg_quant_enriched[
          order(-pg_quant_enriched[[difference]] > 0, -pg_quant_enriched[[pvalue]]),]
      
      write.table_imb(pg_quant_enriched,
                      file.path(out_dir,
                                sprintf('volcano_enriched_%s.txt',
                                        out_filename)))
      
      write.table_imb(pg_quant_enriched[
        c('species','Protein.IDs','my_label', difference, pvalue, 
          sub('log10.corrected_', '', pvalue))],
        file.path(out_dir,
                  sprintf('volcano_enriched_reduced_%s.txt',
                          out_filename)))
    }
    if(create_volcano_pdfs) {
      ggsave(file.path(out_dir,sprintf('volcano_%s.pdf',out_filename)),
             volcanoplot,
             height=volcano_height,
             width=volcano_width)
    }
    if(filter_separately) {
      pg_quant <- pg_quant_orig 
    }
  }
  # finally, just removing the enriched column
  if(!filter_separately) {
    pg_quant <- pg_quant[-length(pg_quant)]
  }
}




# extracting fasta files --------------------------------------------------

existing_fasta_files <- 
  list.files('/Volumes/massspec/_MS_DATA_OUT/Mario/lara_multi_species/fastas/',
             pattern='.fa$|.fasta$',
             full.names=TRUE)
fasta_db <- c()
for(fasta_file in existing_fasta_files) {
  fasta_db <- c(fasta_db, seqinr::read.fasta(fasta_file, seqtype='AA', as.string=T))
}

detected_protein_ids <- 
  unlist(stringr::str_split(pg_quant[my_enriched$enriched,]$Protein.IDs,';'))
detected_protein_ids_regex <- 
  paste(gsub('\\|', '\\\\|', detected_protein_ids), collapse='|')
detected_fastas <-
  fasta_db[grep(detected_protein_ids_regex, names(fasta_db))]
seqinr::write.fasta(detected_fastas, 
                    names(detected_fastas),
                    file.out=file.path(out_dir, 'detected.fasta'))

# 
# source('http://www.bioconductor.org/biocLite.R')
# biocLite("msa")



