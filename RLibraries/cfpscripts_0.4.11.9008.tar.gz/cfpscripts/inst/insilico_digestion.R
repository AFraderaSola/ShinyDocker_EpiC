###############################################################################
#
# This script will take a fasta file and in silico digest it. Under 
# development and might miss a lot of information.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.2
# date: 2016.02.05
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(ggplot2)
library(seqinr)
# in case cleaver is not installed, uncomment the following 2 lines and execute them
# source("https://bioconductor.org/biocLite.R")
# biocLite("cleaver")
library(cleaver)


# In R version 3.2.0 and older appears an error message saying something about
# keepNA... This is a little workaround and can be removed in the future.
setMethod("nchar", "ANY", base::nchar)


fasta_file <- '/Volumes/Proteomics-Data/Fasta_UNIPROT/Homo_sapiens_(HUMAN)_Uniprot_20180108.fasta'
fasta_sequences <- read.fasta(fasta_file, seqtype='AA', as.string=TRUE)
tryptic_peptides_per_protein <- cleave(
  unlist(getSequence(fasta_sequences, as.string=TRUE)), 
  enzym="trypsin",
  missedCleavages=2
  )

# the default is to set the sequence as name of the resulting list... This looks
# ugly and we change this with the annotation of each sequence
names(tryptic_peptides_per_protein) <- getAnnot(fasta_sequences)

# putting all peptides in a independent list
all_peptides <- unlist(tryptic_peptides_per_protein)
unique_peptides <- unique(all_peptides)

hist(nchar(unique_peptides), 5000, xlim=c(0,50))

# since max quant is normally using minimum 7 peptides
min_7as_peptides <- unique_peptides[nchar(unique_peptides) >= 7]



counting_df <- data.frame(
  category=factor(c('protein sequences','tryptic peptides',
                    'unique tryptic peptides', 'unique peptides min 7 AA'),
                  levels=c('protein sequences','tryptic peptides',
                           'unique tryptic peptides', 'unique peptides min 7 AA')),
  count=c(length(fasta_sequences), length(all_peptides), 
          length(unique_peptides), length(min_7as_peptides))
)

ggplot(counting_df, aes(category, count)) + 
  geom_bar(stat='identity', fill='grey70') +
  geom_text(aes(label=count), y=diff(sort(counting_df$count)[1:2])/2) +
  theme(axis.text.x=element_text(angle=30, hjust=1, vjust=1), 
        axis.title=element_blank())

ggsave(sprintf('sequence_counting_%s.pdf', 
               sub('(.*)\\.[^\\.]+$', '\\1', basename(fasta_file))),
       width=6, height=6)




