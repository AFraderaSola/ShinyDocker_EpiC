###############################################################################
#
# This script is under development! It will do a GSEA based on Broad Institute
# GSEA tool. It will also produce the .rnk files in advance. It only needs the
# volcano_proteinGroups.txt file created by the LFQ script.
# 
# In general, this java tool is pretty bitchy about file and folder names! No
# spaces or minus in names are alowed. I now created a folder directly on the 
# SSD (e.g. GSEA_David_Herzog) and copied the .rnk files in there.
# On Mac it somehow can not access the network drives. So the .jar and the .rnk
# files need to be local on the machine.
#
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.2
# date: 2018.05.23
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################


gsea_out_dir <- 'D:/GSEA_David_Herzog'
pg <- read.delim('volcano_proteinGroups.txt')

pg <- pg[c('my_label',grep('difference', names(pg), value=TRUE))]

if(!dir.exists(gsea_out_dir)) dir.create(gsea_out_dir)

for(i in (2:length(pg))) {
  filename <- sprintf('%s.rnk', sub('difference_','',names(pg)[i]))
  jnk <- pg[c(1,i)]
  names(jnk) <- c('label', 'difference')
  jnk_unique <- jnk %>%
    group_by(label) %>%
    summarise(difference=max(difference)) %>%
    arrange(-difference)
  write.table(jnk_unique, 
              file = file.path(gsea_out_dir, filename), 
              sep='\t', 
              quote = FALSE,
              row.names = FALSE, 
              col.names = FALSE)
}

rnk_files <- list.files(gsea_out_dir, '.rnk')
gsea_out <- file.path(gsea_out_dir, '.')

gsea_program_path <- "C:/Users/cfproteomics/Desktop/GSEA_3.0/gsea-3.0.jar"
# gsea_program_path <- '~/Downloads/gsea-3.0.jar'


# each individual analysis will be named by the name of the database and the 
# name of the .rnk file (e.g. REACTOME___HC_HNK_1w_HC_Saline_1w). 
# In case of newer versions of GSEA it might be necessary to update the names.
gene_sets_databases <- c(
  KEGG='c2.cp.kegg.v6.1.symbols.gmt',
  REACTOME='c2.cp.reactome.v6.1.symbols.gmt',
  GO_ALL='c5.all.v6.1.symbols.gmt',
  GO_BP='c5.bp.v6.1.symbols.gmt',
  GP_CC='c5.cc.v6.1.symbols.gmt',
  GO_MF='c5.mf.v6.1.symbols.gmt'
)

# This is the command which will be executed in the command line. In case of 
# new version of GSEA, this command can be adapted via the GUI by setting up
# a normal analysis but clicking the "command line" instead of "run".
# NOTE: the %s get replaced in the loop below with the related parameters.
gsea_command <- paste(c(
  'java -cp %s', 
  '-Xmx512m xtools.gsea.GseaPreranked',
  '-gmx gseaftp.broadinstitute.org://pub/gsea/gene_sets_final/%s',
  '-norm meandiv',
  '-nperm 1000',
  '-rnk %s',
  '-scoring_scheme weighted',
  '-rpt_label %s',
  '-create_svgs false',
  '-make_sets true',
  '-plot_top_x 20',
  '-rnd_seed timestamp',
  '-set_max 500',
  '-set_min 5',
  '-zip_report false',
  '-out %s',
  '-gui false'
), collapse=' ')


for(rnk_file in rnk_files) {
  for(gene_set_index in seq_along(gene_sets_databases)) {
    out_name <- sprintf('%s___%s', 
                        names(gene_sets_databases[gene_set_index]),
                        sub('.rnk', '', rnk_file))
    cmd <- sprintf(gsea_command,
                   gsea_program_path,
                   gene_sets_databases[gene_set_index],
                   file.path(gsea_out_dir, rnk_file),
                   out_name,
                   gsea_out)
    cat('\n', cmd, '\n\n')
    system(cmd)
    
    # cat(sprintf('DONE %s!!!!\n\n\n', out_name))
  }
}


