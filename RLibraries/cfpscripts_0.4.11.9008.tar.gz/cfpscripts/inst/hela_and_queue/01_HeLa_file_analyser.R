###############################################################################
#
# This script will check for new DONE MQ analysis on HeLa files. It will execute
# the Maintenance script and moves the folder into the final destination.
#
# The script will use some system variables which can be set in "~/.Rprofile".
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.16
# date: 2019.11.19
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################


# Global variables --------------------------------------------------------

hela_analysis_path <- getOption('cfpscripts.hela_analysis_path')
hela_done_path <- getOption('cfpscripts.proteomics_data_dir')

maintenanscript <- system.file('maintenance_analysis.R', 
                               package='cfpscripts')

# look for new files
available_hela_analysis <- list.dirs(hela_analysis_path, recursive=FALSE)

source(file.path(getOption('cfpscripts.mqqueue_running_threads_path'),
                 '..','email_regex.R'))

home_dir <- getwd()

# move file to new location
for(hela_analysis in available_hela_analysis) {
  year <- substr(basename(hela_analysis), 1, 4)
  
  if(any(grepl('^Finish_writing_tables.*', 
               list.files(file.path(hela_analysis, 'combined','proc')))
         # grepl('proteinGroups.txt',
         #       list.files(file.path(hela_analysis, 'combined', 'txt')))
  )) {
    setwd(hela_analysis)
    
    source(maintenanscript)
    
    receivers <- c('m.dejung@imb.de')
    if(grepl(
      paste(
        sprintf('_%s_', names(email_list)), collapse='|'), 
      basename(hela_analysis))
    ) {
      maintenance_user <- paste(strsplit(basename(hela_analysis), '_')[[1]][2:4], collapse='_')
      email_address <- unname(unlist(email_list[sapply(names(email_list), grepl, maintenance_user)]))
      receivers <- c(receivers, email_address)
    }
    
    mailR::send.mail(from=cfpscripts:::email_settings$from,
                     to=receivers,
                     subject=sprintf("%s peps for %s", b, basename(hela_analysis)),
                     body='check attached files\n',
                     smtp=cfpscripts:::email_settings,
                     authenticate=FALSE,
                     attach.files='results.txt',
                     send=TRUE)
    
    setwd(home_dir)
    Sys.sleep(60)
    cfpscripts::deleteUnusedMQFolders(list.dirs(hela_analysis), quiet=TRUE)
    
    destination_dir <- file.path(hela_done_path, year)
    if(!dir.exists(destination_dir)) dir.create(destination_dir)
    
    copied <- file.copy(hela_analysis, 
                        destination_dir,
                        recursive=TRUE)
    if(copied) {
      invisible(unlink(
        list.files(getOption('cfpscripts.mqqueue_running_threads_path'),
                   pattern=make.names(list.files(hela_analysis,
                                                 pattern='mqpar__hela\\.xml$')),
                   full.names=TRUE)
      ))
      unlink(hela_analysis, recursive=TRUE)
    }
    
  }
}



