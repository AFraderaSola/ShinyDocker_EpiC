library(dplyr)
library(tidyr)
library(ggplot2)


getMQProcesses <- function() {
  res <- system("wmic process get ProcessID,CommandLine", intern=TRUE)
  
  #parse the results to get a nice data.frame
  ans <- trimws(res)[!grepl("^[0-9]", trimws(res))]
  ans <- ans[ans!=""][-1]
  df <- data.frame(
    ProcessId=sapply(strsplit(ans, " "), tail, n=1L),
    CommandLine=sapply(strsplit(ans, " "), function(x) trimws(paste(head(x, n=-1L), collapse=" ")))
  )
  df[grep('maxqua', df$CommandLine, ignore.case = TRUE),]
}
list.dirsN <- function(p, n) {
  res <- grep('RECYCLE.BIN', 
              list.dirs(p, recursive = FALSE), 
              value=TRUE, invert=TRUE)
  if (n > 1) {
    add <- list.dirsN(res, n-1)
    c(res, add)
  } else {
    res
  }
}
waitingProcesses <- function() {
  mqpar_pattern <- '^mqpar__[^_].*\\.xml$'
  all_mqpar_files <- 
    list.files(list.dirsN(getOption('cfpscripts.mqqueue_search_path'), 3), # second level 
               pattern=mqpar_pattern,
               full.names=TRUE, 
               recursive=FALSE)
  mqpar_done_processing <- # check if the analysis is done
    sapply(all_mqpar_files, function(mqpar) {
      x <- dirname(mqpar)
      # need a double check here 
      any( # check if proc Finsh_writing... file exists, but sometimes this folder gets deleted
        isTRUE(file.exists(list.files(file.path(x, 'combined', 'proc'), 
                                      pattern='Finish_writing_tables.*', 
                                      full.names=TRUE))),
        # so we also check for the proteinGroups file, but sometimes the txt folder get renamed :-)
        isTRUE(file.exists(file.path(x, 'combined', 'txt', 'proteinGroups.txt')))
      )
    })
  mqpar_in_process <- # check if the analysis is done
    sapply(all_mqpar_files, function(mqpar) {
      x <- dirname(mqpar)
      # need a double check here 
      all( # check if proc Finsh_writing... file exists, but sometimes this folder gets deleted
        !file.exists(list.files(file.path(x, 'combined', 'proc'), 
                                pattern='Finish_writing_tables.*', 
                                full.names=TRUE)),
        file.exists(file.path(x, 'combined', 'proc')),
        # so we also check for the proteinGroups file, but sometimes the txt folder get renamed :-)
        !file.exists(file.path(x, 'combined', 'txt', 'proteinGroups.txt'))
      )
    })
  
  todo_mqpar_files <- all_mqpar_files[!mqpar_done_processing & !mqpar_in_process]
}

getProcessesDF <- function() {
  data.frame(ts=Sys.time(), getMQProcesses() %>% 
               summarise(
                 mq_task=sum(grepl('MaxQuantTask.exe', CommandLine)), 
                 mq_impl=sum(grepl('MaxQuantImpl.exe', CommandLine)),
                 mq_process=sum(grepl('MAXQUA~1.EXE', CommandLine)),
                 mq_mslibtasks=sum(grepl('MsLibTask.exe', CommandLine)),
                 waiting_processes=length(waitingProcesses())))
}


df <- getProcessesDF()
processes <- nrow(getMQProcesses())
i <- 1
while(processes > -1) {
  df <- rbind(df,
              getProcessesDF())
  if(i%%60 == 0) {
    cat(sprintf(' %s\n', Sys.time()))
    g <- ggplot(df %>% gather(key=key, value=value, -ts), aes(ts, value, color=key)) + 
      geom_line(na.rm = TRUE, position = position_jitter(height=.05), size=1) +
      scale_y_continuous(breaks = seq(0,300,4), minor_breaks = seq(0,300,1)) +
      facet_wrap(~key)
    print(g)
  } else {
    cat('.')
  }
  i <- i + 1
  Sys.sleep(1)
  processes <- nrow(getMQProcesses())
}

