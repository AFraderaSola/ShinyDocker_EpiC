###############################################################################
#
# This script is to automatically analyse all HeLa runs of QEP1 and QEP2.

# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.2.9
# date: 2019.11.19
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################
# options(cfpscripts.proteomics_data_dir='/Volumes/Proteomics-Data')
# options(cfpscripts.new_massspec_files=file.path('/Volumes', 
#                                                 c('massspec2', 'massspec3')))
# options(cfpscripts.hela_analysis_path='/Volumes/SSDarray/automated_hela')
# options(cfpscripts.maintenance_mq_cmd=NULL)
# options(cfpscripts.hela_maintenance_files_processed=
#           '/Volumes/massspec/R_scripts/hela/hela_maintenance_files_processed.txt')
# options(cfpscripts.hela_maintenance_statistic_table=
#           '/Volumes/massspec/R_scripts/hela/hela_MA_statistic_table.txt')

library(zoo)
library(ggplot2)
library(grid)
library(gridExtra)
library(scales)
library(dplyr)
library(tidyr)
library(rMQanalysis)

# What are we doing
# Looking in proteomics dir containing HeLa
# Looking for all HeLa folders with result.txt in it
# Removing the ones we have already analysed in the list
# get creation time of raw file and pair with result.txt
# check if we have new datasets to send email afterwards

# read anjas cleaning protocol
# create plotly graph with dropdown for machine and ng
# write actual counts in the email maybe a small figure of the last 20 measurements

# options(cfpscripts.hela_maintenance_statistic_table=
#           'Z:\\R_scripts\\hela\\hela_MA_statistic_table.txt')
# getOption('cfpscripts.proteomics_data_dir')
paths <- list(
  home=getOption('cfpscripts.hela_maintenance_statistic_table'),
  old_hela_search=file.path(getOption('cfpscripts.proteomics_data_dir'), 
                            c('2018', '2019'))
)
# paths <- list(home='z:\\R_scripts\\hela\\hela_MA_statistic_table.txt', old_hela_search=c("O:/2018", "O:/2019"))

hela_done <- readLines(paths$home)

hela_file_regexs <- list(
  list(pattern='.*_MA_.*_HeLa_.*', amount='50ng', 
       title='50ng maintenance files', filename='Graph_50ng.png'),
  # list(pattern='.*_IMB_CF_HeLa_.*', amount='500ng', 
  #      title='IMB CF 500ng files', filename='Graph_CF_500ng.png'),
  list(pattern='.*_MA_.*_HeLa_.*|.*_IMB_CF_HeLa_.*', amount='500ng', 
       title='500ng maintenance and CF files', filename='Graph_500ng.png')
)
new_graphs <- FALSE
for(hela_file_regex in hela_file_regexs) {
  found_hela_analysis <- 
    grep(paste(sapply(hela_file_regexs, '[[', 'pattern'), collapse='|'), 
         list.dirs(paths$old_hela_search, recursive=FALSE),
         value=TRUE)
  
  analysis_done <- file.exists(file.path(found_hela_analysis, 'results.txt'))
  
  hela_analysis <- found_hela_analysis[analysis_done]
  
  if(!all(basename(hela_analysis) %in% hela_done)) {
    new_graphs <- TRUE
    writeLines(basename(hela_analysis), paths$home)
    
    hela_analysis_per_pattern <- grep(hela_file_regex$pattern, hela_analysis, value=TRUE)
    jnk <- bind_rows(
      lapply(hela_analysis_per_pattern, 
             function(x) as.data.frame(t(read.delim(file.path(x, 'results.txt'))), 
                                       stringsAsFactors=FALSE)))
    
    jnk <- cbind(jnk, 
                 reshape2::colsplit(jnk$rawfile..............., 
                                    '_', 
                                    c('date','machine','group','user','species','label','amount','retentiontime','timestamp')))
    # jnk$timestamp[is.na(jnk$timestamp)] <- 
    #   paste0(substr(jnk$date[is.na(jnk$timestamp)], 3, 8),'000000')
    # jnk$timestamp <- as.POSIXct(strptime(jnk$timestamp, "%y%m%d%H%M%S"))
    hela_files <- sapply(hela_analysis_per_pattern, list.files, pattern='.raw$', full.names=TRUE)
    hela_files[sapply(hela_files, identical, character(0))] <- NA
    
    jnk$timestamp <- 
      as.POSIXct(file.info(unlist(hela_files))$ctime)
    tail(jnk)
    ggplot(filter(jnk, amount == hela_file_regex$amount, 
                  timestamp >= Sys.time() - 365*24*60*60), 
           aes(timestamp, as.numeric(Peptides.Sequences.ID.), 
               group=machine, color=user)) + 
      geom_hline(yintercept=8000, color='red') +
      geom_hline(yintercept=10000, color='green') +
      geom_point(aes(shape=as.numeric(Peptides.Sequences.ID.) < 8000),
                 size=2) + 
      geom_line() +
      ggtitle(hela_file_regex$title) +
      geom_text(data=jnk %>% 
                  filter(amount == hela_file_regex$amount) %>% 
                  group_by(machine) %>% 
                  arrange(desc(timestamp)) %>% slice(1),
                aes(label=Peptides.Sequences.ID.),
                color='black') +
      facet_wrap(~ machine, ncol=1) +
      theme_bw() +
      # guides(size=FALSE) +
      scale_x_datetime(date_breaks = 'month', date_minor_breaks = 'week') +
      scale_shape_manual(values = c(`TRUE`=21, `FALSE`=16), guide=FALSE) +
      # scale_color_brewer(palette='Set3') +
      # scale_fill_manual('User', values=grDevices::colorRampPalette(
      #   RColorBrewer::brewer.pal(9,'Set1'), 
      #   interpolate='spline')(length(unique(jnk$user)))) +
      scale_fill_manual('User', values=RColorBrewer::brewer.pal(12,'Set3')[-2]) +
      theme(axis.text.x = element_text(angle=45, hjust=1))
    ggsave(hela_file_regex$filename, width=10, height=8)
    ggsave(file.path(getOption('cfpscripts.new_massspec_files'), 
                     'MA', 
                     hela_file_regex$filename),
           width=10, height=8)
    
    
  }
}
if(new_graphs) {
  Sys.sleep(5)
  mailR::send.mail(from=cfpscripts:::email_settings$from,
                   to=c('m.dejung@imb.de', 'r.schmitt@imb.de'),
                   subject="New HeLa statistics",
                   body='We found a new HeLa analysis and checked the quality',
                   smtp=cfpscripts:::email_settings,
                   authenticate=FALSE,
                   attach.files=list.files('.', pattern='Graph_'),
                   send=TRUE)
}
# check if there are new files which are not in the list yet, otherwise stop

# time when MQ was started to check if the files are not done yet

# check if the analysis is done yet

# what about dont_use.txt






# Set global variables ----------------------------------------------------
# rm('documentation')
# home_wd <- file.path('Z:','massspec','MA','automatic_hela_analysis')
# maintenance_script_path <- file.path('Z:','massspec','MA','automatic_hela_analysis')
# maintenance_script_path <- system.file('maintenance_analysis.R', 
#                                        package='cfpscripts')

# setwd(home_wd)
# data_dir <- file.path('E:') #'E:'for MaxQuant Server, 'S:'for private PC
# data_dir <- file.path('/Volumes/Proteomics-Data/') #'E:'for MaxQuant Server, 'S:'for private PC
# Search_dir <- c('2013','2014','2015','2016')

# table_name <- file.path(home_wd, 'HeLa MA statistic table_mac.txt')

#Cleaning Dates to show in Plot.
# CleaningQEP1 <- c('','')

#file.path('combined','txt','summary.txt')

# Set functions -----------------------------------------------------------

# AddResultsToTable <- function(foldersToAddToDocument) {
#   documentation <- data.frame()
#   for (i in 1:length(foldersToAddToDocument)) {
#     cat(sprintf('working on %s\n',foldersToAddToDocument[i]))
#     result_filename <- file.path(foldersToAddToDocument[i],'results.txt')
#     resultFile <- read.delim(result_filename, stringsAsFactors=FALSE)
#     rawfile_regex <- '([0-9]+)_([^_]+)_([^_]+)_([^_]+)_([^_]+)_([^_]+)_([^_]+)_([^_]+)'
#     date <- sub(rawfile_regex,"\\1", resultFile$V1[1])
#     machine <- sub(rawfile_regex,"\\2", resultFile$V1[1])
#     concentration <- sub(rawfile_regex,"\\7", resultFile$V1[1])
#     documentation <- rbind(documentation, data.frame(
#       Date = as.factor(as.Date(date, '%Y%m%d')),
#       Machine = machine,
#       Conc = concentration,
#       Rawfile = resultFile$V1[1],
#       MS.MS.ID.rate = as.numeric(resultFile$V1[2]), 
#       Peptides.Sequences.ID = as.numeric(resultFile$V1[3]),
#       proteinGroups = as.numeric(resultFile$V1[4]),
#       SILAC.proteinGroups = as.numeric(resultFile$V1[5]),
#       Dir = foldersToAddToDocument[i]))
#     
#   }
#   return(documentation) 
# }
# 
# 
# # Find folderpath with specific experiments "HeLa" -------------------------------------------
# 
# # folderpath_HeLa <- c()
# # for (folder in Search_dir) {
# #   foldername_HeLa <- dir(file.path(data_dir,folder), 
# #                          pattern='_MA_.*_HeLa_',
# #                          full.names=TRUE,
# #                          ignore.case=TRUE)
# #   folderpath_HeLa <- c(folderpath_HeLa, foldername_HeLa) #includes the whole filepath
# # }
# 
# # Check if folderpath_HeLa is already read in the Statistic table ----------------------------
# 
# # if(file.exists(file.path(home_wd, table_name))) {
# #   cat('table found\n')
# #   #Load the table
# #   documentation <- read.delim(file.path(home_wd, table_name))
# #   #Remove folderoath which are already read in the table
# #   matching_folders <- match(folderpath_HeLa, documentation$Dir) 
# #   foldersToAddToDocument  <- folderpath_HeLa[is.na(matching_folders)] #subset of new HeLa folders
# # } else{
# documentation  <- data.frame(stringsAsFactors=FALSE)
# #   foldersToAddToDocument <- folderpath_HeLa # creates a table, because it didn't exist so far
# # }
# 
# # Check if folders have already results -----------------------------------
# 
# # for (folder_path in hela_analysis) {
# #   cat(sprintf('\nworking in "%s"\n', folder_path))
# #   if(!file.exists(file.path(folder_path, 'results.txt'))) {
# #     setwd(folder_path)
# #     cat(sprintf('working in %s\n', getwd()))
# #     cat('Run MA script\n')
# #     try(source(maintenance_script_path))
# #   }
# # }
# 
# outputTable <- AddResultsToTable(hela_analysis) #Run function
# documentation <- rbind(documentation, outputTable)
# 
# write.table_imb(documentation, paths$home)
# 
# # Creating graphical analysis---------------------------------------------------
# 
# documentation$Date <- as.Date(documentation$Date)
# 
# documentation$Time <- '000000'
# multiple_measurements <- grep('QEP\\d_\\d{12}', documentation$Machine)
# documentation$Time[multiple_measurements] <- 
#   gsub('.*(\\d{6})$', '\\1', documentation$Machine[multiple_measurements])
# documentation$Timestamp <- as.POSIXct(interaction(documentation$Date, documentation$Time, sep=' '),
#                                       format='%Y-%m-%d %H%M%S')
# 
# documentation$Conc <- sub('58ng','50ng',documentation$Conc)
# documentation$Conc <- sub('50ng_.*','50ng',documentation$Conc)
# documentation$Machine  <- sub('QEP([1-9])_?.*', 'QEP\\1',documentation$Machine)
# 
# 
# rectangles <- data.frame(
#   xmin = seq(as.POSIXct('2011-01-01'), as.POSIXct(Sys.Date()), by='+2 year'),
#   xmax = seq(as.POSIXct('2012-01-01'), as.POSIXct(Sys.Date() + 365), by='+2 year'),
#   ymin = -Inf,
#   ymax = Inf
# )
# 
# instruments <- unique(documentation$Machine)
# conc <- '50ng'
# 
# graph_list_peptides <- list()
# graph_list_MSMS <- list()
# graph_list_PG <- list()
# # Cleaning_df <- read.delim2(file.path(home_wd,'QEPs Cleaning, ITE, Repair etc.txt'), stringsAsFactors=FALSE)
# # Cleaning_df$Date <- as.Date(Cleaning_df$Date, '%d-%m-%Y')
# 
# 
# df <- 
#   documentation %>% 
#   select(Timestamp, Rawfile, Machine, Peptides.Sequences.ID, MS.MS.ID.rate, SILAC.proteinGroups) %>% 
#   gather(type, value, -Timestamp, -Rawfile, -Machine)
# 
# last_df <- 
#   df %>% 
#   group_by(Machine, type) %>% 
#   arrange(desc(Timestamp)) %>% 
#   slice(1)
# 
# hline <- data.frame(
#   type=c('MS.MS.ID.rate','MS.MS.ID.rate','Peptides.Sequences.ID','Peptides.Sequences.ID',
#          'Peptides.Sequences.ID','Peptides.Sequences.ID', 'SILAC.proteinGroups','SILAC.proteinGroups'),
#   Machine=c('QEP1','QEP2','QEP1','QEP2','QEP1','QEP2','QEP1','QEP2'),
#   value=c(NA, NA, 10000, 10000, 8000, 8000, NA, NA)
# )
# 
# ggplot() + 
#   geom_rect(data=rectangles, aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax),
#             fill="grey90", alpha=.4, na.rm=TRUE) +
#   geom_line(data=df, aes(Timestamp, value), colour="#000066", size=.5) + 
#   geom_point(data=last_df, aes(Timestamp, value), color='red') +
#   facet_wrap(Machine ~ type, scales='free_y') +
#   scale_x_datetime(
#     date_breaks='3 month',
#     date_minor_breaks='1 month',
#     labels=date_format("%b-%Y"),
#     limits = c(as.POSIXct('2014-02-01'),as.POSIXct(Sys.Date() + 10))
#     # limits = c(as.POSIXct(Sys.Date() - 370),as.POSIXct(Sys.Date() + 10))
#   ) + 
#   xlab(NULL) + ylab(NULL) + 
#   scale_color_manual(values=c('8000'='#FF3300', '10000'='#669900')) +
#   geom_hline(data=hline, aes(yintercept=value, color=as.factor(value)), linetype="dashed",size = 1) +
#   # geom_point(data=ITE, aes(x=Date, y=as.numeric(Value)*2800), color='red', size=3, na.rm=TRUE) +
#   # geom_text(data=ITE[seq(nrow(ITE),1,-3),], 
#   # aes(x=Date, y=as.numeric(Value)*2800, label=Value), 
#   # vjust=0.5, hjust=-.1, angle=45) +
#   theme_imb(9) +
#   theme(axis.text.x=element_text(angle=45, vjust=1, hjust=1)) +
#   guides(color=FALSE)
# 
# for (instrument in instruments) {
#   # Cleaning <- subset(Cleaning_df, Machine == instrument & Type == 'Cleaning', stringsAsFactors=FALSE)
#   # ITE <- subset(Cleaning_df, Machine == instrument & Type == 'ITE', stringsAsFactors=FALSE)
#   #as.numeric(levels(Value))[Value]))
#   machine_conc_df <- subset(documentation, Conc == conc & Machine == instrument)
#   max_y <- max(machine_conc_df$Peptides.Sequences.ID)
#   
#   graph <- 
#     ggplot() + # first rectangle datas
#     geom_line(data=machine_conc_df, # here we hand over the MA data
#               aes(x=Timestamp, y=Peptides.Sequences.ID),colour="#000066",size = 1) + 
#     scale_x_datetime(
#       date_breaks='2 month',
#       date_minor_breaks='1 month',
#       labels=date_format("%b-%Y"),
#       limits = c(as.POSIXct('2014-02-01'),as.POSIXct(Sys.Date() + 10))
#     ) + 
#     xlab(NULL) + ylab("Peptides Sequences Identification") + scale_y_continuous(limits=c(0, 13000)) +
#     geom_rect(data=rectangles, aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax),
#               fill="grey90", alpha=.4, na.rm=TRUE) +
#     # geom_vline(data=Cleaning, aes(xintercept = as.numeric(Date)), colour="#99CCFF", linetype="F1",size = 1) +
#     
#     ggtitle(sprintf("PeptideIDs of %s (%s HeLa standard)\n", instrument, conc)) + 
#     theme(plot.title = element_text(lineheight=.8, face="bold")) +
#     geom_hline(aes(yintercept=8000), colour="#FF3300", linetype="dashed",size = 1) +
#     geom_hline(aes(yintercept=10000), colour="#669900", linetype="dashed",size = 1) +
#     # geom_point(data=ITE, aes(x=Date, y=as.numeric(Value)*2800), color='red', size=3, na.rm=TRUE) +
#     # geom_text(data=ITE[seq(nrow(ITE),1,-3),], 
#     # aes(x=Date, y=as.numeric(Value)*2800, label=Value), 
#     # vjust=0.5, hjust=-.1, angle=45) +
#     theme_imb() +
#     theme(axis.text.x  = element_text(angle=45, vjust=1, hjust=1))
#   
#   graph_list_peptides[[instrument]] <- graph
#   
#   graph <- ggplot() +
#     scale_x_datetime(date_breaks='2 month', date_minor_breaks='1 month',
#                      labels=date_format("%b-%Y"),
#                      limits = c(as.POSIXct('2014-02-01'),as.POSIXct(Sys.Date() + 10))) + 
#     xlab(NULL) + ylab("MSMS Identification rate") + scale_y_continuous(limits=c(0, 53) ) +
#     geom_rect(data=rectangles, aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax),
#               fill="grey90", alpha=.4, na.rm=TRUE) +
#     geom_line(data=subset(documentation, Conc == conc & Machine == instrument), # here we hand over the MA data
#               aes(x=Timestamp, y=MS.MS.ID.rate, group=1),colour="#000066",size = 1, na.rm=TRUE) + geom_point(na.rm=TRUE) + 
#     ggtitle(sprintf("MSMS ID rate of %s (%s HeLa standard)\n", instrument, conc)) + 
#     theme(plot.title = element_text(lineheight=.8, face="bold")) +
#     geom_hline(aes(yintercept=40), colour="#FF3300", linetype="dashed",size = 1) +
#     geom_hline(aes(yintercept=45), colour="#669900", linetype="dashed",size = 1) +
#     theme_imb() +
#     theme(axis.title.x = element_text(),
#           axis.text.x  = element_text(angle=45, vjust=1, hjust=1))
#   
#   graph_list_MSMS[[instrument]] <- graph
#   
#   graph <- ggplot() +
#     scale_x_datetime(date_breaks='2 month', date_minor_breaks='1 month',
#                      labels=date_format("%b-%Y"),
#                      limits = c(as.POSIXct('2014-01-01'),as.POSIXct(Sys.Date()))) + 
#     xlab(NULL) + ylab("SILAC protein Groups") + scale_y_continuous(limits=c(0,2700)) +
#     geom_rect(data=rectangles, aes(xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax),
#               fill="grey90", alpha=.4, na.rm=TRUE) +
#     geom_line(data=subset(documentation, Conc == conc & Machine == instrument), # here we hand over the MA data
#               aes(x=Timestamp, y=SILAC.proteinGroups, group=1),colour="#000066",size = 1, na.rm=TRUE) + geom_point(na.rm=TRUE) + 
#     ggtitle(sprintf("SILAC Protein Groups of %s (%s HeLa standard)\n", instrument, conc)) + 
#     theme(plot.title = element_text(lineheight=.8, face="bold")) +
#     geom_hline(aes(yintercept=1200), colour="#FF3300", linetype="dashed",size = 1) +
#     geom_hline(aes(yintercept=1400), colour="#669900", linetype="dashed",size = 1) +
#     theme_imb() +
#     theme(axis.title.x = element_text(),
#           axis.text.x  = element_text(angle=45,vjust=1, hjust=1))
#   
#   graph_list_PG[[instrument]] <- graph
# }
# # setwd(home_wd)
# g <- do.call(arrangeGrob,graph_list_peptides)
# grid.newpage()
# grid.draw(g)
# ggsave(sprintf('Graph_HeLa_Statistics %s_peptideID.png', conc),g, width=15,height=10)
# 
# g <- do.call(arrangeGrob,graph_list_MSMS)
# grid.newpage()
# grid.draw(g)
# ggsave(sprintf('Graph_HeLa_Statistics %s_MSMSID.png', conc),g, width=15,height=10)
# 
# g <- do.call(arrangeGrob,graph_list_PG)
# grid.newpage()
# grid.draw(g)
# ggsave(sprintf('Graph_HeLa_Statistics %s_SILAC_pg.png', conc),g, width=15,height=10)





#save.image(file = "HeLastatistics.RData")
