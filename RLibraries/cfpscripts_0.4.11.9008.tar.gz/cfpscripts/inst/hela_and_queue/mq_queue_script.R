###############################################################################
#
# Checking files and queueing them. mqpar files named mqpar__hela.xml or with 
# a _FORCE.XML ending will be started directly on the remaining processors. At 
# the moment, there is no way on starting jobs with more than the number of 
# maximum processes.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 1.0.9
# date: 2019-05-27
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################
library(xml2)
library(rMQanalysis)

# options(cfpscripts.mqqueue_max_processes=6)
# options(cfpscripts.mqqueue_search_path='/Volumes/SSDarray')
# options(cfpscripts.mqqueue_running_threads_path='/Volumes/SSDarray/queue')
# options(cfpscripts.mqqueue_mq_command='C:\\Users\\cfproteomics\\Desktop\\MaxQuant 1.5.2.8\\bin\\MaxQuantCmd.exe')

max_processes <- getOption('cfpscripts.mqqueue_max_processes')


paths <- list(
  search=getOption('cfpscripts.mqqueue_search_path'),
  running_threads=getOption('cfpscripts.mqqueue_running_threads_path')
)


mqpar_pattern <- '^mqpar__[^_].*\\.xml$'

list.dirsN <- function(p, n) {
  res <- list.dirs(p, recursive = FALSE)
  if (n > 1) {
    add <- list.dirsN(res, n-1)
    c(res, add)
  } else {
    res
  }
}

all_mqpar_files <- 
  list.files(grep('RECYCLE', list.dirsN(paths$search, 3), value=TRUE, invert=TRUE), # second level 
             pattern=mqpar_pattern,
             full.names=TRUE, 
             recursive=FALSE)
all_mqpar_files <- all_mqpar_files[order(file.info(all_mqpar_files)$atime)]

mqpar_done_processing <- # check if the analysis is done
  sapply(all_mqpar_files, function(mqpar) {
    x <- dirname(mqpar)
    # need a double check here 
    any( # check if proc Finsh_writing... file exists, but sometimes this folder gets deleted
      isTRUE(file.exists(list.files(file.path(x, 'combined', 'proc'), 
                                    pattern='Finish_writing_tables.*', 
                                    full.names=TRUE)))
      # # so we also check for the proteinGroups file, but sometimes the txt folder get renamed :-)
      # isTRUE(file.exists(file.path(x, 'combined', 'txt', 'proteinGroups.txt')))
    )
  })

mqpar_in_process <- # check if the analysis is done
  sapply(all_mqpar_files, function(mqpar) {
    x <- dirname(mqpar)
    # need a double check here 
    all( # check if proc Finsh_writing... file exists, but sometimes this folder gets deleted
      # !file.exists(list.files(file.path(x, 'combined', 'proc'), 
      #                         pattern='Finish_writing_tables.*', 
      #                         full.names=TRUE)),
      file.exists(file.path(x, 'combined', 'proc'))
      # so we also check for the proteinGroups file, but sometimes the txt folder get renamed :-)
      # !file.exists(file.path(x, 'combined', 'txt', 'proteinGroups.txt'))
    )
  })

todo_mqpar_files <- all_mqpar_files[!mqpar_done_processing & !mqpar_in_process]

for(mqpar in all_mqpar_files[mqpar_done_processing]) {
  running_threads <- 
    list.files(paths$running_threads, 
               pattern=make.names(mqpar), 
               full.names=TRUE)
  waiting_threads <- 
    list.files(paths$running_threads, 
               pattern='^WAITING_', 
               full.names=TRUE)
  file.remove(grep('\\.xml$', running_threads, value=TRUE))
  file.remove(grep('\\.xml$', waiting_threads, value=TRUE))
}

cat(sprintf('TO RUN: %s\n', paste(todo_mqpar_files, collapse=', ')))

for(mqpar in todo_mqpar_files) {
  Sys.sleep(5)
  threads <- as.numeric(xml_text(xml_find_all(read_xml(mqpar), 'numThreads')))
  thread_files <- paste0(seq(threads), make.names(mqpar))
  if(
    ((length(list.files(paths$running_threads, pattern='*.xml$')) + 
      length(thread_files)) <= max_processes) | 
    (grepl('mqpar__hela.xml', mqpar) & 
     length(list.files(paths$running_threads, pattern='*.xml$')) < 8) |
    grepl('_FORCE.xml', mqpar)
  ) {
    file.create(file.path(paths$running_threads, thread_files))
    
    # start MQ
    mq_cmd <- getOption('cfpscripts.mqqueue_mq_command')
    cmd <- sprintf('"%s" "%s"', 
                   mq_cmd, mqpar)
    cat(sprintf('EXECUTE: %s\n', cmd))
    system(cmd, wait=FALSE)
  } else {
    cat('NOT ENOUGH RESOURCES AVAILABLE.\n')
    file.create(file.path(paths$running_threads, 
                          paste0('WAITING_',thread_files)))
  }
}

cat('DONE\n')




# getMQProcesses <- function() {
#   res <- system("wmic process get ProcessID,CommandLine", intern=TRUE)
# 
#   #parse the results to get a nice data.frame
#   ans <- trimws(res)[!grepl("^[0-9]", trimws(res))]
#   ans <- ans[ans!=""][-1]
#   df <- data.frame(
#     ProcessId=sapply(strsplit(ans, " "), tail, n=1L),
#     CommandLine=sapply(strsplit(ans, " "), function(x) trimws(paste(head(x, n=-1L), collapse=" ")))
#   )
#   df[grep('maxqua', df$CommandLine, ignore.case = TRUE),]
# }
# library(ggplot2)
# df <- data.frame(ts=Sys.time(), processes=NA)
# processes <- nrow(getMQProcesses())
# i <- 1
# while(processes > -1) {
#   df <- rbind(df,
#               data.frame(ts=Sys.time(), processes=nrow(getMQProcesses())))
#   if(i%%60 == 0) {
#     cat('\n')
#     g <- ggplot(df, aes(ts, processes)) + geom_line(na.rm = TRUE) + ylim(0,max(df$processes))
#     print(g)
#   } else {
#     cat('.')
#   }
#   i <- i + 1
#   Sys.sleep(1)
#   processes <- nrow(getMQProcesses())
# }
