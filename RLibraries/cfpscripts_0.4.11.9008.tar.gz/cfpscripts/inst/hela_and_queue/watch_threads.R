###############################################################################
#
# This script checks for thread files which are not deleted for more than half
# a day and send me an email with a notification. It is likely that these MQ 
# runs failed for some reason.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.1
# date: 2018-02-26
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

thread_files <- 
  list.files(
    getOption('cfpscripts.mqqueue_running_threads_path'), 
    '.xml$', 
    full.names=TRUE)
max_days <- .5
file_age <- difftime(Sys.time(), file.mtime(thread_files), units='days')
old_files <- thread_files[file_age > max_days]

if(length(old_files)) {
  invisible(
    mailR::send.mail(from=cfpscripts:::email_settings$from,
                     to=c('m.dejung@imb.de'),
                     subject="Some MQ processes didn't finished",
                     body=sprintf("Some threads didn't finished within %s day:\n%s",
                                  max_days,
                                  paste(old_files, collapse=',\n')),
                     smtp=cfpscripts:::email_settings,
                     authenticate=FALSE,
                     send=TRUE)
  )
}

