###############################################################################
#
# This script will check for new HeLa files in the massspec folder and moves 
# them to the local drive for further processing. It will start the MQ analysis
# and will finish after starting. 
#
# The script will use some system variables which can be set in "~/.Rprofile".
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.9
# date: 2019.11.19
#
# package version: 0.4.9
# package date: 2018-02-12
#
###############################################################################

library(stringr)

# Global variables --------------------------------------------------------

hela_new_path <- getOption('cfpscripts.new_massspec_files')
hela_analysis_path <- getOption('cfpscripts.hela_analysis_path')
hela_done_path <- getOption('cfpscripts.proteomics_data_dir')
hela_mq_cmd <- getOption('cfpscripts.maintenance_mq_cmd')
hela_fasta_file <- getOption('cfpscripts.maintenance_fasta_file')
hela_files_processed <- 
  readLines(getOption('cfpscripts.hela_maintenance_files_processed'))

# hela_new_path <- 'W:'
# hela_done_path <- 'O:\\Proteomics-Data'
# hela_files_processed <- 
#   readLines("Z:\\R_scripts\\hela\\hela_maintenance_files_processed.txt")

# look for new files
available_hela_files <- 
  cfpscripts::quickFileSearch(path=hela_new_path,
                              pattern='*QEP*_HeLa_SILAC_*.raw')
#####
# Need to check if it is already done...


new_hela_files <- 
  available_hela_files[!basename(available_hela_files) %in% hela_files_processed]

# ignore files older than X days
days <- 14
new_hela_files <- 
  new_hela_files[file.info(new_hela_files)$ctime > Sys.time() - 86400 * days]

new_hela_files <- 
  new_hela_files[file.info(new_hela_files)$size > 2000000]



######
# if more than 8 files, stop and write an email to mario


modifyMQParamFile <- function(file_name) {
  mqpar <- readLines(system.file('extdata','hela_maintenance_template_mqpar.xml', 
                                 package='cfpscripts'))
  replace_regex <- '##_HELA_FILE_##'
  file_name <- paste(strsplit(file_name,'/|\\\\')[[1]], collapse='\\\\')
  mqpar <- sub(replace_regex, file_name, mqpar)
  
  replace_regex <- '##_FASTA_FILE_##'
  file_name <- hela_fasta_file
  mqpar <- sub(replace_regex, file_name, mqpar)
  return(mqpar)
}

# move file to new location
for(hela_file in new_hela_files) {
  dir_name <- file.path(hela_analysis_path, 
                        sub('\\.raw', '', basename(hela_file)))
  if(!dir.exists(dir_name)) {
    invisible(unlink(
      list.files(getOption('cfpscripts.mqqueue_running_threads_path'), 
                 pattern=make.names(list.files(dir_name, 
                                               pattern='mqpar__hela.xml')), 
                 full.names=TRUE)
    ))
    dir.create(dir_name)
    jnk <- file.copy(hela_file, dir_name)
    # dir.create(file.path(dir_name, 'combined'))
    # jnk <- file.copy(file.path(hela_analysis_path, 'search'), 
    #                  dir_name, 
    #                  recursive = TRUE)
    if(jnk) {
      mqpar <- modifyMQParamFile(file.path(dir_name,basename(hela_file)))
      writeLines(mqpar, file.path(dir_name, 'mqpar__hela.xml'))
      
      
      # cmd <- sprintf('"%s" "%s"', 
      #                hela_mq_cmd, file.path(dir_name, 'mqpar__hela.xml'))
      # 
      # system(cmd, wait=FALSE)
      
      hela_files_processed <- c(hela_files_processed, basename(hela_file))
    }
  } 
}


writeLines(hela_files_processed,
           getOption('cfpscripts.hela_maintenance_files_processed'))


