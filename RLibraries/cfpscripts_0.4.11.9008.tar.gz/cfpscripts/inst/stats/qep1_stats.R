
library(zoo)
runs <- read.delim('/Volumes/massspec/R_scripts/statistics/run_summaries.txt')
runs <- runs[!duplicated(runs$Filename),]
runs$date <- as.Date(runs$Timestamp)

runs$year <- as.numeric(sapply(runs$date, format, '%Y'))
runs$month <- as.numeric(sapply(runs$date, format, '%m'))
runs$quarter <- as.yearqtr(runs$date)

runs$machine <- sub('\\d+_([^_]+)_([^_]+)_.*','\\1',runs$Filename)
runs$group <- sub('\\d+_([^_]+)_([^_]+)_.*','\\2',runs$Filename)
runs$runtime <- (runs$MaxRT/60 + 15)/60

qep1 <- subset(runs, machine == 'QEP1' & year %in% c(2014,2015,2016))

library(ggplot2)
library(dplyr)

qep1_df <- 
  qep1 %>%
  filter(group != 'MA') %>%
  mutate(group=replace(group, !group %in% c('PBE', 'JH', 'PB'), 'Core Facility')) %>%
  mutate(group=replace(group, !group %in% c('Core Facility'), 'Petra Beli')) %>%
  group_by(year, group) %>%
  summarise(runtime=round(sum(runtime))) %>%
  mutate(freq = round(runtime / sum(runtime)*100)) 

qep1_df$group <- factor(qep1_df$group, levels=c('Petra Beli','Core Facility'))

ggplot(qep1_df, aes(year, runtime, fill=group)) +
  geom_bar(stat='identity') +
  geom_text(aes(label=sprintf('%d%%',freq)), y=rep(c(1000, 4000), 3)) +
  ylab('Betrieb (Forschung) [h]') +
  scale_x_continuous(breaks=c(2014,2015,2016),
                     minor_breaks=NULL,
                     labels=c('1. Jahr','2. Jahr','3. Jahr')) +
  scale_y_continuous(breaks=seq(0,10000,1000),
                     minor_breaks=NULL) +
  theme_bw(14) +
  theme(axis.title.x=element_blank())
ggsave('dfg.pdf', width=7, height=5)
    
  



