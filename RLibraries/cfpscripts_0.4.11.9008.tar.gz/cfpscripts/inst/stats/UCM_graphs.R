###############################################################################
#
# This script will create the figures for the UCM talk and can be modified to
# produce additional analysis figures as well.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.6
# date: 2019.09.30
#
# package version: 0.4.9
# package date: 2018-02-12
#
###############################################################################


library(dplyr)
library(tidyr)
library(lubridate)
library(ggplot2)
library(ggrepel)




# out_dir <- '/Volumes/imb-proteomicscf/Corefacility user meeting/UCM_figures_20180814'
out_dir <- '/Volumes/groups/Corefacility user meeting/UCM_figures_20201021'
if(!dir.exists(out_dir)) dir.create(out_dir)

run_summaries_file <- '/Volumes/massspec/R_scripts/statistics/run_summaries.txt'
user_sample_submission_file <- '/Volumes/imb-proteomicscf/_CF Proteomics User samples/User Sample submission.xlsx'
user_sample_submission_file <- '/Volumes/groups/_CF Proteomics User samples/User Sample submission.xlsx'



group_abbreviations <- c('CF' = 'IMB CF Proteomics', 
                         'JW' = 'IMB CF Proteomics', 
                         'CK' = 'External User',
                         'CN' = 'IMB Christof Niehrs',
                         'FB' = 'IMB Falk Butter',
                         'GR' = 'IMB George Reid',
                         'HR' = 'IMB Holger Richly',
                         'HU' = 'IMB Helle Ulrich',
                         'JR' = 'IMB Jean-Yves Roignant',
                         'TR' = 'External User',
                         'VT' = 'IMB Vijay Tiwari',
                         'AB' = 'IMB CF Proteomics', # Aline
                         'MO' = 'IMB CF Proteomics', # Matthias
                         'MA' = 'IMB CF Proteomics Maintenance',
                         'EW' = 'IMB Eva Wolf',
                         'MB' = 'External User',
                         'EXT' = 'External User',
                         'NS' = 'IMB Natalia Soshnikova',
                         'RK' = 'IMB Rene Ketting',
                         'EL' = 'IMB Edward Lemke',
                         'AF' = 'IMB CF Proteomics', # Anja
                         'IMB' = 'IMB CF Proteomics',
                         'VR' = 'IMB Vassilis Roukos')
# group_abbreviations <- c('CF' = 'IMB CF Proteomics', 
#                          'JW' = 'IMB CF Proteomics', 
#                          'CK' = 'External User',
#                          'CN' = 'IMB Christof Niehrs',
#                          'FB' = 'IMB Falk Butter',
#                          'GR' = 'IMB former members',
#                          'HR' = 'IMB former members',
#                          'HU' = 'IMB Helle Ulrich',
#                          'JR' = 'IMB Jean-Yves Roignant',
#                          'TR' = 'External User',
#                          'VT' = 'IMB former members',
#                          'AB' = 'IMB CF Proteomics', # Aline
#                          'MO' = 'IMB CF Proteomics', # Matthias
#                          'MA' = 'IMB CF Proteomics Maintenance',
#                          'EW' = 'IMB Eva Wolf',
#                          'MB' = 'External User',
#                          'EXT' = 'External User',
#                          'NS' = 'IMB former members',
#                          'RK' = 'IMB Rene Ketting',
#                          'EL' = 'IMB Edward Lemke',
#                          'AF' = 'IMB CF Proteomics', # Anja
#                          'IMB' = 'IMB CF Proteomics',
#                          'VR' = 'IMB Vassilis Roukos')

if(!all(file.exists(c(run_summaries_file, user_sample_submission_file)))) {
  stop('Make sure "massspec" and "imb-proteomicscf" is mounted.')
}

run_summaries <- read.delim('/Volumes/massspec/R_scripts/statistics/run_summaries.txt',
                            stringsAsFactors=FALSE)

duplicated_rows <- duplicated(run_summaries[c(-1,-2)])
runs <- run_summaries[!duplicated_rows,]

duplicated_filenames <- duplicated(runs$Filename)
runs <- runs[!duplicated_filenames,]

timestamp_problems_filenames <- is.na(runs$Timestamp)
runs <- runs[!timestamp_problems_filenames,]

runs <- runs %>%
  # slice(33980:34000) %>%
  extract(Filename, 
          c('machine','facility','group'), 
          '[^_]+_([^_]+)_([^_]+)_([^_]+)_.*', 
          remove=FALSE) %>%
  mutate(Timestamp=lubridate::as_datetime(Timestamp),
         year=year(Timestamp),
         hours=round((MaxRT/60+15)/60),
         facility=ifelse(grepl('SP3_trail', Filename),
                         'CF', facility))


plot_by_facility <- 
  runs %>%
  group_by(year, facility) %>%
  # group_by(facility) %>%
  summarise(count=n()) %>%
  ggplot(aes(facility, count, fill=facility)) +
  geom_col() +
  geom_label_repel(aes(label=count), 
                   fill='white',
                   direction='y',
                   label.padding=.1) +
  facet_wrap(~ year, scales='free_x') +
  theme(axis.text.x=element_text(angle=45, hjust=1)) +
  scale_fill_viridis_d() +
  ggtitle('Sample count per year and facility')
print(plot_by_facility)
ggsave(file.path(out_dir, 'sample_count_per_facility.pdf'),
       plot_by_facility,
       width=11.69, height=8.27)
ggsave(file.path(out_dir, 'sample_count_per_facility.png'),
       plot_by_facility,
       width=11.69, height=8.27)

cf_runs <- 
  runs %>%
  select(Filename, machine, facility, group, year, hours) %>%
  filter(facility %in% c('IMB','EXT','JGU','MPI'),
         !grepl('_wash_', Filename, ignore.case=T),
         # !grepl('_HeLa_', Filename, ignore.case=T),
         # machine == 'QEP1',
         group != 'MO'
         ) %>%
  mutate(
    location=ifelse(facility %in% c('EXT','JGU','MPI'),
                    'extern',
                    ifelse(group == 'CF' & !facility %in% c('EXT','JGU','MPI'),
                           'CF', 'intern')),
    group_full=case_when(location == 'extern' ~ 'External User',
                         TRUE ~ group_abbreviations[group])
    ) 
  
plot_by_location <- 
  cf_runs %>%
  group_by(year, location) %>% 
  summarise(count=n(),
            hours=sum(hours)) %>% 
  group_by(year) %>% 
  arrange(desc(location)) %>%
  mutate(ylabel=cumsum(hours)) %>%
  ggplot(aes(year, hours, fill=location)) +
  geom_bar(stat='identity') +
  ggtitle('Measuring hours by location') +
  theme_bw() +
  # geom_label_repel(aes(label=hours, y=ylabel), 
  #                  fill='white',
  #                  direction='y',
  #                  label.padding=.1)  +
  theme(axis.text.x=element_text(angle=45, hjust=1),
        axis.title.x=element_blank()) + 
  scale_fill_viridis_d(begin=.3, end=.9) +
  geom_hline(yintercept=1500, linetype=2) +
  scale_x_continuous(breaks=2000:3000)
print(plot_by_location)
ggsave(file.path(out_dir, 'machine_usage_time_per_location.pdf'),
       plot_by_location,
       width=6, height=6)
ggsave(file.path(out_dir, 'machine_usage_time_per_location.png'),
       plot_by_location,
       width=6, height=6)

plot_internal_groups <- 
  cf_runs %>%
  filter(location == 'intern',
         !group_full %in% c('IMB CF Proteomics', 'IMB CF Proteomics Maintenance')) %>%
  group_by(year, group_full) %>%
  summarise(hours=sum(hours)) %>%
  ggplot(aes(group_full, hours, fill=group_full)) +
  geom_bar(stat='identity') +
  ggtitle('Machine usage of internal groups') +
  # geom_label_repel(aes(label=hours), 
  #                  fill='white',
  #                  direction='y',
  #                  label.padding=.1) +
  facet_wrap(~ year, ncol=1, strip.position="right") +
  theme_bw() +
  theme(axis.text.x=element_text(angle=45, hjust=1),
        axis.title.x=element_blank()) + 
  scale_fill_viridis_d() +
  guides(fill=FALSE)
print(plot_internal_groups)
ggsave(file.path(out_dir, 'machine_usage_time_per_internal_group.pdf'),
       plot_internal_groups,
       width=6, height=6)
ggsave(file.path(out_dir, 'machine_usage_time_per_internal_group.png'),
       plot_internal_groups,
       width=6, height=6)



user_sample_data <- xlsx::read.xlsx(user_sample_submission_file, 1, stringsAsFactors=FALSE)

uss_df <- 
  user_sample_data %>%
  select(Date, barcode, User, processed, Species, Service, MS.run, 
         MQ.analysis, results.delivered, Account, Collaboration) %>%
  filter(!grepl('IMB_CF_', barcode)) %>%
  mutate(processed=as_date(as.numeric(processed), origin='1900-01-01'),
         MQ.analysis=as_date(as.numeric(MQ.analysis), origin='1900-01-01'),
         results.delivered=as_date(as.numeric(results.delivered), origin='1900-01-01'),
         analysis_time=results.delivered - Date,
         year=year(results.delivered),
         Collaboration=ifelse(is.na(Collaboration), FALSE, TRUE)
  ) 
 
plot_analysis_time <- 
  ggplot(uss_df %>%
         filter(!is.na(analysis_time)),
       aes(year, as.numeric(analysis_time), fill=Collaboration, group=Collaboration)) +
  geom_violin() +
  # geom_boxplot(alpha=.5) +
  labs(x='Year', y='Days', title='Analysis time of samples') +
  scale_fill_viridis_d(begin=.3, end=.9) +
  facet_wrap(~ year, scales='free_x', nrow=1) +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank(), 
        panel.grid.major.x=element_blank(), 
        panel.grid.minor.x=element_blank())
print(plot_analysis_time)
ggsave(file.path(out_dir, 'analysis_time.pdf'), plot_analysis_time,
       width=7, height=6)
ggsave(file.path(out_dir, 'analysis_time.png'), plot_analysis_time,
       width=7, height=6)


plot_analysis_time_so <- 
  ggplot(uss_df %>%
           filter(!is.na(analysis_time),
                  !Collaboration),
         aes(year, as.numeric(analysis_time), fill=Collaboration, group=Collaboration)) +
  geom_violin() +
  # geom_boxplot(alpha=.5) +
  labs(x='Year', y='Days', title='Analysis time of service only samples') +
  scale_fill_viridis_d(begin=.3, end=.9, guide=FALSE) +
  facet_wrap(~ year, scales='free_x', nrow=1) +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank(), 
        panel.grid.major.x=element_blank(), 
        panel.grid.minor.x=element_blank())
print(plot_analysis_time_so)
ggsave(file.path(out_dir, 'analysis_time_serviceOnly.pdf'), plot_analysis_time_so,
       width=7, height=6)
ggsave(file.path(out_dir, 'analysis_time_serviceOnly.png'), plot_analysis_time_so,
       width=7, height=6)


plot_sample_counts <- 
  uss_df %>% 
  filter(!is.na(year)) %>% 
  mutate(location=ifelse(grepl('EXT|JGU|MPI', barcode), 'extern', 'intern')) %>%
  group_by(year, location, Collaboration) %>% 
  summarise(sample=n()) %>% 
  group_by(location, year) %>% 
  arrange(desc(as.character(Collaboration))) %>%
  mutate(ylabel=cumsum(sample)) %>% 
  ggplot(aes(year, sample, fill=Collaboration)) + 
  geom_bar(stat='identity') +
  ggtitle('Compare service and collaboration sample') +
  facet_wrap(~ location, ncol=1) +
  # geom_label_repel(aes(label=sample, y=ylabel), 
  #                  fill='white',
  #                  direction='y',
  #                  label.padding=.1) +
  labs(x='Year', y='Sample') +
  scale_fill_viridis_d('', begin=.3, end=.9, 
                       labels=c(`FALSE`='Service', `TRUE`='Collaboration')) +
  scale_x_continuous(breaks=2000:3000)
print(plot_sample_counts)
ggsave(file.path(out_dir, 'collab_sample_counts.pdf'), plot_sample_counts,
       width=7, height=6)
ggsave(file.path(out_dir, 'collab_sample_counts.png'), plot_sample_counts,
       width=7, height=6)

plot_hour_counts <- 
  uss_df %>% 
  filter(!is.na(year)) %>% 
  mutate(location=ifelse(grepl('EXT|JGU|MPI', barcode), 'extern', 'intern'),
         hour=as.numeric(sub('h','',MS.run))) %>%
  group_by(year, location, Collaboration) %>% 
  summarise(sample=n(),
            hours=sum(hour)) %>% 
  group_by(location, year) %>% 
  arrange(desc(as.character(Collaboration))) %>%
  mutate(ylabel=cumsum(hours)) %>% 
  ggplot(aes(year, hours, fill=Collaboration)) + 
  geom_col() +
  geom_label_repel(aes(label=hours, y=ylabel), 
                   fill='white',
                   direction='y',
                   label.padding=.1) +
  ggtitle('Compare service and collaboration hours') +
  facet_wrap(~ location, ncol=1) +
  labs(x='Year', y='Hours') + 
  scale_fill_viridis_d('', begin=.3, end=.9, 
                       labels=c(`FALSE`='Service', `TRUE`='Collaboration')) +
  scale_x_continuous(breaks=2000:3000)
print(plot_hour_counts)
ggsave(file.path(out_dir, 'collab_hour_counts.pdf'), plot_hour_counts,
       width=7, height=6)
ggsave(file.path(out_dir, 'collab_hour_counts.png'), plot_hour_counts,
       width=7, height=6)

plot_cfp_beli_compare <- 
  runs %>%
  filter(machine == 'QEP1', 
         facility %in% c('PBE','IMB','EXT', 'FBU'),
         # !grepl('_wash_', raw_file, ignore.case=TRUE),
         group != 'MA') %>%
  select(year, facility, hours) %>%
  mutate(facility=ifelse(facility == 'PBE', 'PBE', 'CFP')) %>%
  group_by(year) %>%
  mutate(total_hours=sum(hours)) %>%
  ungroup() %>%
  group_by(year, facility) %>%
  summarise(count=n(),
            hours=sum(hours),
            percent=unique(hours/total_hours)) %>% 
  ungroup() %>% 
  group_by(year) %>% 
  mutate(ypos=hours/2 + c(0, hours[-1]/2),
         ylabel=cumsum(hours)) %>%
  ggplot(aes(year, y=hours, fill=factor(facility, levels=c('PBE','CFP')))) +
  geom_col() +
  ggtitle('All QEP1 hours except maintenance') +
  geom_label_repel(aes(y=ylabel, 
                       label=sprintf('%.1f%%\n%d h', percent*100, hours)),
                   fill='white',
                   direction='y',
                   label.padding=.1) +
  scale_x_continuous(breaks=seq(1:3000)) +
  scale_fill_viridis_d('group', begin=.3, end=.9)
print(plot_cfp_beli_compare)
ggsave(file.path(out_dir, 'plot_cfp_beli_compare.pdf'), plot_cfp_beli_compare,
       width=7, height=6)
ggsave(file.path(out_dir, 'plot_cfp_beli_compare.png'), plot_cfp_beli_compare,
       width=7, height=6)






# SAB report excel file ---------------------------------------------------

sab_stats <- 
  cf_runs %>%
  filter(
    # location == 'intern',
    !group_full %in% c('IMB CF Proteomics', 'IMB CF Proteomics Maintenance')) %>%
  group_by(year, group_full) %>%
  summarise(hours=sum(hours), 
            samples=n()) 

wb <- xlsx::createWorkbook()
sheet <- xlsx::createSheet(wb, 'year stats')
stat_df <- xlsx::addDataFrame(sab_stats %>% 
                                group_by(year) %>%
                                summarise(samples=sum(samples),
                                          hours=sum(hours)) %>%
                                as.data.frame(),
                              sheet,
                              row.names=FALSE)
for(y in unique(sab_stats$year)) {
  year_sab <- 
    sab_stats %>%
    filter(year == y)
  sheet <- xlsx::createSheet(wb, as.character(y))
  stat_df <- xlsx::addDataFrame(year_sab %>%
                                  as.data.frame(),
                                sheet,
                                row.names=FALSE)
}

merge_df <- data.frame(
  type=c("BI", "IC", "IP", "IP", "other", "PR", 
           "PR", "IP", "PR", "PR", "QC", "BI", "IP"), 
  label=c("NON", "SIL", "NON", "SIL", "other", "NON", 
            "SIL", "DML", "DML", "LFQ", "NON", "DML", "LFQ"),
  project=c('Band Identification', 'SILAC', 'Other', 'SILAC', 'Other', 'Other',
            'SILAC', 'Dimethyl', 'Dimethyl', 'Other', 'Other', 'Other', 'Other'),
  stringsAsFactors=FALSE
)

project_stats <- 
  cf_runs %>%
  as_tibble() %>%
  filter(
    # !grepl('HeLa|BSA', Filename, ignore.case=TRUE),
    # location != 'CF',
    !group_full %in% c('IMB CF Proteomics', 'IMB CF Proteomics Maintenance')
    ) %>%
  mutate(type=sub('.*_(..)_..._\\d\\d\\d.*', '\\1', Filename),
         type=ifelse(nchar(type) != 2, 'other', type),
         label=sub('.*_.._(...)_\\d\\d\\d.*', '\\1', Filename),
         label=ifelse(nchar(label) != 3, 'other', label)) %>%
    left_join(merge_df,
              by=c("type", "label")) %>%
  group_by(year, project) %>%
  summarise(n=n())

sheet <- xlsx::createSheet(wb, 'project stats')
stat_df <- xlsx::addDataFrame(project_stats %>%
                                as.data.frame(),
                              sheet,
                              row.names=FALSE)

xlsx::saveWorkbook(wb, file.path(out_dir, 'sab_report.xlsx'))



