###############################################################################
#
# Script to create the sequence for an MS run
#
# Please always use the "Source" button WITHOUT echo in this script.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.12
# date: 2019.06.19
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(readxl)

setwd("Q:/_MS_DATA_OUT/Jasmin") # uncomment for Jasmin

# figure out in which drive your proteomics data is located
cf_dirs <- c('/Volumes/imb-proteomicscf/_CF Proteomics User samples/', # Marios Mac
             '/Volumes/groups/_CF Proteomics User samples/',
             'W:\\_CF Proteomics User samples', # Anjas computer
             'Y:\\_CF Proteomics User samples' #Jasmins computer
             )
data_path <- cf_dirs[file.exists(cf_dirs)][1] # set the existing folder path


# read in the excel sheets
ms_sample_sheet <- read_excel(file.path(data_path, 'CFP MS sample sheet.xlsx'),
                              skip=1)

##### For some reasone, the file needs now some special treatment ?! ###########
# On Jasmins computer I had to remove column 5.
# Also the columns get named differently. The second 'Pos.' column get renamed 
# to 'Pos..1' and also with the third column and the 'MS.' and 'Sample' column.
# So I overwrite the column names by a new vector... Very dirty! I know!. Let's
# see how long it works...
ms_sample_sheet <- ms_sample_sheet[-5]
names(ms_sample_sheet) <- 
  c("#0001", "1", "2", "3", "Pos.", "Sample", "MS", "Pos.", "Sample",
    "MS", "Pos.", "Sample", "MS", "Backup?", "NO", "")
################################################################################

user_sample_submission <- read_excel(file.path(data_path, 'User Sample submission.xlsx'))

# creating some standard variables
today <- format(Sys.time(), '%Y%m%d')
last_plate <- tail(grep('^#[0-9]{4}',ms_sample_sheet[[1]], value=TRUE),1)

# asking the user some questions
analysis_date <- readline(sprintf('date of analaysis (e.g. 20160831) [default: %s]: ',
                                  today))
if(analysis_date == '') { analysis_date <- today }
lc_pos <- as.numeric(readline('Which tray column first position? (e.g. 1,4,7, etc): '))
plate_number <- readline(sprintf('Which 24 well plate do you use? (default %s): ',
                                last_plate))
if(plate_number == '') { plate_number <- last_plate }

out_file <- sprintf('%s_plate_%s.csv',
                    analysis_date, 
                    sub('#','',plate_number))

# figure out the in which line the plate starts and ends
end_of_cells <- which(is.na(ms_sample_sheet$`#0001`))
start_cell <- grep(plate_number, ms_sample_sheet$`#0001`) + 1
end_cell <- min(end_of_cells[end_of_cells > start_cell]) - 1

# extracting this plate info
ms_ss_subset <- ms_sample_sheet[start_cell:end_cell,]
if(ms_ss_subset[match('cut', ms_ss_subset$`Backup?`),]$NO == 'yes') { # check if it is cut in half
  ms_ss_subset <- ms_ss_subset[1:4,]
} 
# reformating to a long format
df <- rbind(
  ms_ss_subset[5:6],
  ms_ss_subset[8:9],
  ms_ss_subset[11:12]
)
df <- df[!is.na(df$Sample),]


# list of method files related to the "MS run" parameter
method_files_df <- data.frame(
  Label=rep(c("NON", "SIL", "DML", "LFQ"), each=6),
  `MS run`=c("1h", "1.5h", "2h", "3h", "4h", "5h"),
  Method=c("C:\\Xcalibur\\methods\\NSI_TOP10_60min_max4uL_IW1.8_DEW20_225nl_ON", 
           "C:\\Xcalibur\\methods\\NSI_TOP10_90min_max4uL_IW1.8_DEW20_225nl_ON",
           "C:\\Xcalibur\\methods\\NSI_TOP10_120min_max4uL_IW1.8_DEW20_225nl_ON", 
           "C:\\Xcalibur\\methods\\NSI_TOP10_180min_max4uL_IW1.8_DEW20_225nl_ON", 
           "C:\\Xcalibur\\methods\\NSI_TOP10_240min_max4uL_IW1.8_DEW35_225nl_ON", 
           "C:\\Xcalibur\\methods\\NSI_TOP10_300min_max4uL_IW1.8_DEW40_225nl_ON"),
  stringsAsFactors=FALSE, check.names=FALSE
)
method_files_df <- rbind(
  method_files_df,
  data.frame(
    Label=rep(c("TMT"), each=3),
    `MS run`=c("1h", "2h", "4h"),
    Method=c("C:\\Xcalibur\\methods\\NSI_TOP10_60min_TMT_NCE33", 
             "C:\\Xcalibur\\methods\\NSI_TOP10_120min_TMT_NCE33", 
             "C:\\Xcalibur\\methods\\NSI_TOP10_240min_TMT_NCE33"),
    stringsAsFactors=FALSE, check.names=FALSE
  )
)


# we merge the selected plate with the data from the user submission sheet
df_merged <- 
  dplyr::distinct(merge(df, 
        user_sample_submission[c('barcode','MS run','Label','Species','Service')],
        by.x='Sample', by.y='barcode',
        all.x=TRUE, sort=FALSE))

# have to update and create some columns
df_merged$minutes <- sprintf('%03d',as.numeric(sub('h','',df_merged$`MS run`)) * 60)
df_merged$pos_row <- sub('\\d','',df_merged$Pos.)
df_merged$pos_col <- sub('[A-Z]+','',df_merged$Pos.)
# calculating the new position of the wells based on user input
df_merged$lc_pos <- sprintf('%s%02d', 
                            df_merged$pos_row,
                            as.numeric(df_merged$pos_col) + lc_pos - 1)

# for some reason, the order might change on this step so we save original order
# and reorder after merging.
df_order <- df_merged 
df_merged <- merge(df_merged, method_files_df, all.x=TRUE, sort=FALSE)
df_merged <- df_merged[match(df_order$Pos., df_merged$Pos.),]

# sample output data frame with 500ng hela and a wash
out_df <- structure(
  list(Sample.Type=c("QC", "QC"), 
       File.Name=c(paste0(analysis_date, "_QEP1_IMB_CF_HeLa_SILAC_500ng_120"),
                   paste0(analysis_date, "_QEP1_IMB_CF_wash_060")), 
       Sample.ID = c(2L, 2L), Path = c("E:\\","E:\\"), 
       Instrument.Method = c("C:\\Xcalibur\\methods\\NSI_TOP10_120min_max4uL_IW1.8_DEW20_225nl_ON",
                             "C:\\Xcalibur\\methods\\NSI_TOP10_60min_max4uL_IW1.8_DEW20_225nl_ON"), 
       Process.Method = c(NA, NA), Position = c("B02", "A03"), Inj.Vol = c(3.5, 0),
       Level = c(NA, NA), Sample.Wt = c(0, 0), Sample.Vol = c(0, 0), 
       ISTD.Amt = c(0, 0), Dil.Factor = c(1, 1), L1.Study = c(NA, NA), 
       L2.Client = c(NA, NA), L3.Laboratory = c(NA, NA), L4.Company = c(NA, NA), 
       L5.Phone = c(NA, NA), Comment = c(NA, NA), Sample.Name = c(NA,NA), 
       Calibration.File = c(NA, NA), X = c(NA, NA)), 
  .Names = c("Sample Type", "File Name", "Sample ID", "Path", "Instrument Method", "Process Method", 
             "Position", "Inj Vol", "Level", "Sample Wt", "Sample Vol", "ISTD Amt", 
             "Dil Factor", "L1 Study", "L2 Client", "L3 Laboratory", "L4 Company", 
             "L5 Phone", "Comment", "Sample Name", "Calibration File", ""
  ), row.names = 1:2, class = "data.frame")

# looping over our data frame
for(line in seq(nrow(df_merged))) {
  new_line <- c('QC')
  new_line <- c(new_line,
                sprintf('%s_QEP1_%s_%s_%s_%s_%s',
                        analysis_date, 
                        df_merged[line,]$Sample, 
                        tolower(df_merged[line,]$Species), 
                        toupper(df_merged[line,]$Service),
                        toupper(df_merged[line,]$Label),
                        df_merged[line,]$minutes))
  new_line <- c(new_line, '2', 'E:\\')
  new_line <- c(new_line, df_merged[line,]$Method)
  new_line <- c(new_line, NA, df_merged[line,]$lc_pos, '3.5', NA, 0, 0, 0, 1)
  new_line <- c(new_line, NA, NA, NA, NA, NA, NA, NA, NA, NA)
  out_df <- rbind(out_df, new_line)
  out_df <- rbind(out_df, out_df[2,])
}
out_df <- rbind(out_df, out_df[1,])


writeLines('Bracket Type=4', out_file)
suppressWarnings(
  write.table(out_df, out_file, sep=',', append=TRUE, na='', 
            quote=FALSE, row.names=FALSE, col.names=TRUE))

print(df_merged[c(1,10,3,7,4,5,6)])

