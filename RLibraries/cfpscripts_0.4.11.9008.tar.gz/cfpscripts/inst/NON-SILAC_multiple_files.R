###############################################################################
#
# Script to do the analysis for a NON-SILAC experiment with multiple files on 
# the MaxQuant output files.
#
# This script has to be executet within the folder with the raw files. So it 
# needs the folder with the "combined" folder in it. It will generate a 
# filtered proteinGroups file within this folder.
# 
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.4
# date: 2016.01.20
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################
rm(list = ls()) # remove most objects from the working environment
par(mfrow=c(1,1)) # reset number of graphs per image

library(rMQanalysis)
library(ggplot2)
library(gridExtra)

cat(paste0(getwd(),'\n'))

###############################################################################
# define some variables
data_directory <- file.path('combined','txt') # where are the txt files located
out_directory <- file.path('.')
# If you want to overwrite the name, use this variables here...
OVERWRITE_name <- ''
search_fasta_header <- c() 
FASTA_DB <- 'HUMAN.fasta'
fasta_basepath <- getGlobalOption('MQFASTADIR', 'options(MQFASTADIR="path/to/*.fasta")')
fasta_file <- file.path(fasta_basepath, FASTA_DB)

###############################################################################
# read some files
summary <- read.delim(file.path(data_directory,'summary.txt'))
pg <- read.delim(file.path(data_directory,'proteinGroups.txt'))
peptides <- read.delim(file.path(data_directory,'peptides.txt'))


###############################################################################
# read infos from the files
infile <- as.character(summary$Raw.file[-length(summary$Raw.file)])
name <- 
  gsub('.*(\\d{8})_(\\w+)_(\\w+)_(\\w+_\\d{4,}.*)_(\\w+)_(\\w+)_(\\w+)_(\\w+)',
       '\\4',
       infile)

if(!OVERWRITE_name == '') name <- OVERWRITE_name
sample_data <- list(id=paste0(head(name,1), '-', tail(name,1)))

# define the names for the outfiles
pG_identified_filename <- sprintf("proteinGroups_%s.txt", sample_data$id)
pG_identified_flt_filename <- sprintf("proteinGroups_filtered_%s.txt", sample_data$id)

###############################################################################
# missed cleavage plot
missed_cleavage_plot_filename <- 
  sprintf('Missed_Cleavage_%s.pdf',sample_data$id)

peptides_flt <- filterWholeDataset(peptides, by_bysite=F)
missed_cleavages_df <- getMissedCleavageDF(peptides_flt)
missed_cleavages_plot <- plotMissedCleavages(missed_cleavages_df,sample_data)
print(missed_cleavages_plot)
ggsave(file.path(out_directory,
                 sprintf('missed_cleavage_%s.pdf', sample_data$id)),
       missed_cleavages_plot,
       width=6,height=6)


###############################################################################
# filter the proteinGroups 
pg_flt <- filterWholeDataset(pg)
pg_ident <- filterIdentifiedProteins(pg_flt)

###############################################################################
# create plot for identified proteins

pg_df <- data.frame(dataset = factor(c('original', 'filtered', 'identified'), 
                                     levels=c('original', 'filtered', 'identified')),
                    count = c(nrow(pg), nrow(pg_flt), nrow(pg_ident)))
y_label_pos <- -max(pg_df$count) * 0.05
pg_count_graph <- ggplot(pg_df, aes(x=dataset, y=count)) + 
  geom_bar(stat='identity') +
  scale_y_continuous(limits = c(-max(pg_df$count) * 0.07, max(pg_df$count) * 1.1)) +
  geom_text(aes(label=count), y=y_label_pos, color='black') +
  ylab('protein groups') + xlab('filtering step') +
  ggtitle('protein groups after each filtering step')
print(pg_count_graph)
ggsave(file.path(out_directory,
                 sprintf('pg_count_%s.pdf', sample_data$id)),
       pg_count_graph,
       width=6,height=6)

###############################################################################
# write this filtered dataset to a file
write.table_imb(pg_ident, 
                file=file.path(out_directory,pG_identified_filename))

column_numbers <- c(
  grep('Fasta.headers',names(pg_ident)),
  grep('Protein.names',names(pg_ident)),
  grep('Gene.names',names(pg_ident)),
  grep('Unique.peptides..*',names(pg_ident)))


###############################################################################
# write this filtered dataset to a file
write.table_imb(pg_ident[column_numbers], 
                file=file.path(out_directory,pG_identified_flt_filename))



if(length(search_fasta_header) >= 1) {
  search_string <- paste(search_fasta_header,collapse="|")
  cat(sprintf('\n\n\nsearching for the protein IDs "%s"\n', search_string))
  cat(sprintf('matching results in the FASTA DB:\n'))
  print(grep(search_string,
             readLines(FASTA_DB),
             ignore.case=TRUE,
             value=T))
  
  cat(sprintf('matching results in proteinGroups:\n'))
  search_results <- pg_ident[grep(search_string,
                                       pg_ident$Fasta.headers,
                                       ignore.case=TRUE),]  
  print(search_results$Fasta.headers)
}



