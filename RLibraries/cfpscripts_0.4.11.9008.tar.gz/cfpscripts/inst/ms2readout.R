###############################################################################
#
# This script works only on windows machines with proteome wizard installed and
# msFileReader needs to be available as well. 
# It looks for all .raw files in the working directory and reads the ms2 info.
# This gets written into a subfolder and we create a new list with the 
# statistics within the combine txt folder.
#
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.4
# date: 2016.02.10
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(data.table)
library(plyr)
library(reshape2)
library(ggplot2)
library(rMQanalysis)
library(cfpscripts)

copySourcedScript()

msaccess_path <- getGlobalOption('MSACCESSEXE', 
                                 'options(MSACCESSEXE="C:/programs/proteowizard/msaccess.exe")')
mq_data <- file.path('combined', 'txt')

msaccess_parameters <- '-x "spectrum_table delimiter=tab"'
spec_ending <- '.spectrum_table.tsv'
pwiz_dir <- 'pwiz_data'
if(!dir.exists(pwiz_dir)) dir.create(pwiz_dir)


### This function can be removed with rMQanalysis version >= 2.1.0
spectrumTableFromRaw <- function(rawfile,  
                                 pwiz_dir='pwiz_data',
                                 msaccess_path=NULL) {
  spec_ending <- '.spectrum_table.tsv'
  msaccess_parameters <- '-x "spectrum_table delimiter=tab"'
  
  if(is.null(msaccess_path)) {
    msaccess_exe <- getGlobalOption(
      'MSACCESSEXE', 
      'options(MSACCESSEXE="C:/programs/proteowizard/msaccess.exe")')
  } else {
    if(file.exists(msaccess_path)) {
      msaccess_exe <- msaccess_path
    } else {
      stop(sprintf('File "%s" does not exist.', msaccess_path))
    }
  }
  
  if(!dir.exists(pwiz_dir)) dir.create(pwiz_dir)
  
  cmd_line <- sprintf('"%s" %s %s', 
                      msaccess_exe, 
                      msaccess_parameters, 
                      rawfile, intern=TRUE)
  
  message(sprintf('Create spectra table for %s', basename(raw_file)))
  system(cmd_line)
  
  spec_file <- paste0(rawfile, spec_ending)
  if(file.exists(spec_file)) {
    file.rename(spec_file, file.path(pwiz_dir, spec_file))
  } else {
    message(sprintf('looks like %s was not created!', spec_file))
  }
}

raw_files <- list.files(pattern='.raw$', full.names=TRUE)
for(raw_file in raw_files) {
  spectrumTableFromRaw(raw_file, pwiz_dir)
}

### This function can be removed with rMQanalysis version >= 2.1.0
spectrumTableStatistics <- function(pwiz_directory='pwiz_data') {
  spec_ending <- '.spectrum_table.tsv'
  pwiz_files <- list.files(pwiz_directory, full.names=TRUE)
  pwiz_list <- list()
  for(pwiz_file in pwiz_files) {
    pwiz_df <- read.delim(pwiz_file, comment.char='#', stringsAsFactors=FALSE)
    raw_file <- sub(spec_ending, '', basename(pwiz_file))
    pwiz_df <- cbind(Raw.file=raw_file,
                     pwiz_df)
    pwiz_list[[raw_file]] <- pwiz_df
  }
  pwiz_df <- as.data.frame(rbindlist(pwiz_list), stringsAsFactors=FALSE)
  pwiz_df <- pwiz_df[order(pwiz_df$rt),]
  pwiz_df$minute <- round(pwiz_df$rt / 60)
  
  pwiz_stat <- ddply(pwiz_df, .(Raw.file, minute), summarize,
                     ms1=sum(event == 1),
                     ms2=sum(event == 2))
  return(pwiz_stat)
}


pwiz_stat <- spectrumTableStatistics()
write.table_imb(pwiz_stat, 
                file.path(mq_data, 'pwiz_stat.txt'))


### This function can be removed with rMQanalysis version >= 2.1.0
psmOverTime <- function(evidence, pwiz_stat=NULL, wrap=TRUE, ncol=1,
                        title=NULL) {
  evidence <- read.delim(evidence)
  evidence$minute <- round(evidence$Retention.time)
  evidence_stats <- ddply(evidence, .(Raw.file, minute), summarize,
                          n=length(id),
                          ms2id=sum(MS.MS.Count))
  
  if(!is.null(pwiz_stat)) {
    if(typeof(pwiz_stat) == typeof('')) {
      pwiz <- read.delim(pwiz_stat)
    } else {
      pwiz <- pwiz_stat
    }
    pwiz$Raw.file <- sub('.raw','',pwiz$Raw.file)
    pwiz_stats <- ddply(pwiz, .(Raw.file, minute), summarize,
                        ms1=sum(ms1),
                        ms2=sum(ms2))
    ms_stats <- merge(pwiz_stats, evidence_stats, all.x=TRUE)
  } else {
    ms_stats <- evidence_stats
  }
  m_stats <- melt(ms_stats, c('Raw.file','minute','n'))
  
  breaks_max <- max(m_stats$n, na.rm=TRUE)
  breaks_steps <- round(breaks_max / 10)
  graph <- ggplot(m_stats, aes(minute, value, color=variable, group=variable)) + 
    geom_line() + ggtitle(title) + ylab('count') +
    geom_point(data=subset(m_stats, variable == 'ms2id'), aes(size=n)) + 
    scale_size_continuous(name="peptides", 
                          breaks=seq(0, breaks_max, breaks_steps)) +
    scale_y_continuous(breaks=seq(0, 500000, 50)) +
    theme_imb()
  if(wrap) graph <- graph + facet_wrap(~ Raw.file, ncol=1, scales='free')
  return(graph)
}

title <- basename(getwd())

p <- psmOverTime(file.path(mq_data, 'evidence.txt'), 
                 pwiz_stat,
                 title=title)
print(p)
ggsave(paste0(title, '_ms2stats_perRaw.pdf'), p, width=8.27, height=11.69)
