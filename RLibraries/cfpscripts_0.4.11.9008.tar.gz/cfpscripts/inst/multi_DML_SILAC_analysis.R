###############################################################################
#
# Script to analyse multiple DML/SILAC experiments together.
#
# To get the setup quickly, all MQ analysis should be done in the same way and 
# the experiments should also names the same, like for and rev or so...
# PLEASE CHECK SOURCE CODE FOR LINES WITH #RENAME and rename thos parts.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.2
# date: 2019.01.22
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(dplyr)
library(tidyr)
library(ggplot2)
library(ggrepel)

foldchange <- log2(2)
rounding_digits <- 2

out_dir <- 'multi_IP'
if(!dir.exists(out_dir)) dir.create(out_dir)

important_ids <- c(
  'P30536'
)

regex <- paste0(
  sapply(important_ids, function(x) {
    paste0(
      c('^', ';', '^', ';'),
      rep(x, 4),
      c('$', '$', ';', ';'),
      collapse='|')
  }), collapse='|'
)

# !!! Please name experiments properly! !!!---------------------------------
# Use dput(setNames(list.dirs(recursive=FALSE), paste('exp', seq_along(list.dirs(recursive=FALSE)))))
# to generate an easy to edit list of experiments like in this example.
dml_dirs <- 
  c(`KO IP1` = "../20190112_QEP1_EXT_CF_0439-0440_hs_IP_DML_090", 
    `KO IP2` = "../20190112_QEP1_EXT_CF_0441-0442_hs_IP_DML_090", 
    `KO IP3` = "../20190112_QEP1_EXT_CF_0443-0444_hs_IP_DML_090", 
    `KO IP4` = "../20190112_QEP1_EXT_CF_0445-0446_hs_IP_DML_090"
  )

renameFunction <- function(strings) {
  name_dictionary <- c(
    forward='0439.0440',
    reverse='0440.0439',
    forward='0441.0442',
    reverse='0442.0441',
    forward='0443.0444',
    reverse='0444.0443',
    forward='0445.0446',
    reverse='0446.0445'
  )
  new_strings <- strings
  for(i in seq_along(name_dictionary)) {
    new_strings <- sub(name_dictionary[i],
                       names(name_dictionary)[i],
                       new_strings)
  }
  return(new_strings)
}

pg_list <- 
  lapply(dml_dirs, function(dml_dir) {
    df <- read.delim(list.files(file.path(dml_dir, 'txt_directory'), 
                                'proteinGroups_.*_filtered.txt',
                                full.names=TRUE),
                     stringsAsFactors=FALSE)
    names(df) <- renameFunction(names(df))
    return(df)
  })

pg <- bind_rows(pg_list, .id = 'experiment') %>%
  as_tibble() %>%
  mutate(forward=log2.Ratio.H.L.normalized.forward, # RENAME
         reverse=log2.Ratio.H.L.normalized.reverse * -1, # RENAME
         enriched=forward >= foldchange & reverse >= foldchange,
         highlight=grepl(regex, Protein.IDs),
         category=ifelse(highlight, 
                         'highlight', 
                         ifelse(enriched, 'enriched','background'))
  )

pg_enriched <- 
  pg %>% 
  filter(enriched) %>%
  select(plot_label) %>%
  distinct()

pg %>%
  ggplot(aes(forward, reverse, color=category, size=category)) +
  geom_hline(yintercept=foldchange, color='darkgrey', linetype='dashed') +
  geom_vline(xintercept=foldchange, color='darkgrey', linetype='dashed') +
  geom_hline(yintercept=0, color='black') +
  geom_vline(xintercept=0, color='black') +
  geom_point(alpha=.5) +
  geom_text_repel(data=. %>% filter(highlight),
                  aes(label=plot_label),
                  color='black',
                  box.padding = 1) +
  ggtitle(sprintf('Scatterplot: "enriched" >= threshold (%.1f)', 
                  2^foldchange)) +
  scale_color_manual('category', values=c(background='grey',
                                          enriched='#377eb8',
                                          highlight='#e41a1c')) +
  scale_size_manual(values=c(background=.8,
                             enriched=1.3,
                             highlight=2)) +
  guides(size=FALSE) +
  facet_wrap(~ experiment) +
  theme_bw()

ggsave(file.path(out_dir,'scatter.pdf'), 
       height=8.27, width=11.69)

log2_range <- range(c(pg$forward, pg$reverse), na.rm = TRUE)

order_df <- pg %>%
  # filter(enriched | highlight) %>%
  filter(plot_label %in% pg_enriched$plot_label) %>%
  select(experiment,  plot_label, forward, reverse) %>%
  gather('replicate','log2.ratio', -experiment, -plot_label) %>%
  mutate(log2.ratio=round(log2.ratio, rounding_digits)) %>%
  unite('experiment', experiment, replicate) %>%
  spread(experiment, log2.ratio) %>%
  as.data.frame()
rownames(order_df) <- order_df$plot_label
order_df[is.na(order_df)] <- 0

heatmap_order <- hclust(dist(as.matrix(order_df[-1])))$order

pg %>%
  # filter(enriched | highlight) %>%
  filter(plot_label %in% pg_enriched$plot_label) %>%
  select(experiment, Protein.IDs, plot_label, forward, reverse) %>%
  gather('replicate','log2.ratio', -experiment, -Protein.IDs, -plot_label) %>%
  unite('experiment', experiment, replicate) %>%
  mutate(plot_label=factor(plot_label, levels=rownames(order_df)[heatmap_order])) %>%
  ggplot(aes(experiment, plot_label, fill=log2.ratio)) +
  geom_tile() +
  ggtitle(sprintf('Heatmap: color midpoint is set to threshold (%.1f)', 
                  2^foldchange)) +
  scale_fill_gradient2('log2(ratio)',
                       high='#ca0020', mid='#f7f7f7', low='#0571b0',
                       midpoint=foldchange, 
                       limit=log2_range) +
  theme_bw(10) +
  theme(axis.text.x = element_text(angle=45, hjust=1),
        axis.title = element_blank())
ggsave(file.path(out_dir,'heatmap.pdf'), 
       width=8.27, height=11.69)



wb <- xlsx::createWorkbook()
sheet1 <- xlsx::createSheet(wb, sheetName='enriched & highlighted')
jnk1 <- xlsx::addDataFrame(pg %>%
                             filter(enriched | highlight) %>%
                             select(experiment, Protein.IDs, plot_label, forward, reverse) %>%
                             gather('replicate','log2.ratio', -experiment, -Protein.IDs, -plot_label) %>%
                             mutate(log2.ratio=round(log2.ratio, rounding_digits)) %>%
                             unite('experiment', experiment, replicate) %>%
                             spread(experiment, log2.ratio) %>%
                             as.data.frame(),
                           sheet1,
                           col.names = TRUE, row.names = FALSE)
sheet2 <- xlsx::createSheet(wb, sheetName='all')
jnk2 <- xlsx::addDataFrame(pg %>%
                             select(experiment, Protein.IDs, plot_label, forward, reverse) %>%
                             gather('replicate','log2.ratio', -experiment, -Protein.IDs, -plot_label) %>%
                             mutate(log2.ratio=round(log2.ratio, rounding_digits)) %>%
                             unite('experiment', experiment, replicate) %>%
                             spread(experiment, log2.ratio) %>%
                             as.data.frame(),
                           sheet2,
                           col.names = TRUE, row.names = FALSE)
sheet3 <- xlsx::createSheet(wb, sheetName='unique plot_label')
jnk3 <- xlsx::addDataFrame(pg %>%
                             select(experiment, Protein.IDs, plot_label, forward, reverse) %>%
                             gather('replicate','log2.ratio', -experiment, -Protein.IDs, -plot_label) %>%
                             mutate(log2.ratio=round(log2.ratio, rounding_digits)) %>%
                             unite('experiment', experiment, replicate) %>%
                             spread(experiment, log2.ratio) %>%
                             select(-Protein.IDs) %>%
                             group_by(plot_label) %>%
                             summarise_all(mean, na.rm=TRUE) %>%
                             as.data.frame(),
                           sheet2,
                           col.names = TRUE, row.names = FALSE)
sheet4 <- xlsx::createSheet(wb, sheetName='full')
jnk4 <- xlsx::addDataFrame(pg %>%
                             as.data.frame(),
                           sheet3,
                           col.names = TRUE, row.names = FALSE)
xlsx::saveWorkbook(wb, file.path(out_dir,'multi_proteinGroups.xlsx'))





