###############################################################################
#
# Script to analyse labeled data such as SILAC or DML. It works with forward
# only experiments, as well as with forward and reverse experiments. For the 
# later case, the raw files need to be defined different 'Experiment' values
# within MaxQuant (ex. for, rev). In case of tripple labeling, the script will
# compare each condition with the others.
#
# This script has to be executet within the main folder where the raw files 
# and the "combined" folder are. It will generate two .pdf files, one for the 
# corefacility and one for the user. Also the graphs get saved as .pdf files.
#
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.1.5
# date: 2017.07.26
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

# loading packages --------------------------------------------------------

library(plotly)
library(grid)
library(gridExtra)
library(plyr)
library(seqinr)
library(ggplot2)
library(ggrepel)

library(rMQanalysis)
library(cfpscripts)

cat(sprintf('Working directory is set to: %s\n', getwd()))
copySourcedScript()

# global variable setting -------------------------------------------------

# list of IDs to mark like c('Q13619','E9PCT1'), will search in the Fasta 
# headers for the pattern. Leave empty "c()" for no highlight
search_fasta_header <- c() 
normalize <- TRUE
impute <- FALSE
zoom_quadrant <- 'UL' # use UL (upper left) or LR (lower right)
#!!! under development!!!
interactive_plot <- FALSE # Switch to TRUE to get an interactive plot

# overwrite standard settings ---------------------------------------------

# directory to read files and save output
data_directory <- file.path('combined','txt') # where are the txt files located
out_directory <- file.path('.')

# If you want to overwrite the for and rev names within graphs, use these two 
# variables, otherwise leave empty.
OVERWRITE_forward_name <- ''
OVERWRITE_reverse_name <- ''

label_font_size <- 2.5 # 3 seems to be a good size for the labels

# impute the missing Intensities 
impute_low <- 0.001
impute_high <- 0.05

# reading files -----------------------------------------------------------

summary <- read.delim(file.path(data_directory, 'summary.txt'), stringsAsFactors=FALSE)
parameters <- read.delim(file.path(data_directory, 'parameters.txt'), stringsAsFactors=FALSE)
pg <- read.delim(file.path(data_directory, 'proteinGroups.txt'), stringsAsFactors=FALSE)
peptides <- read.delim(file.path(data_directory,'peptides.txt'))


# Reading type of experiment ----------------------------------------------

experiment_type <- c()
if(grepl('Dimeth', summary$Labels1[1])) {
  experiment_type <- c(experiment_type, 'DML')
} else {
  experiment_type <- c(experiment_type, 'SILAC')
}

# test for experiment names -----------------------------------------------

forward_only <- FALSE
if('Experiment' %in% names(summary)) {
  experiments <- unique(na.omit(summary$Experiment[summary$Experiment != '']))
  expected_experiments <- c('for', 'rev')
  
  if(length(experiments) == 2) {
    # this should be the case in forward and reverse experiments
    if(!any(experiments %in% expected_experiments)) {
      warning(sprintf('The experiments (%s) are not defined as expected (%s).\n',
                      paste(experiments, collapse=', '), 
                      paste(expected_experiments, collapse=', ')),
              sprintf('We will treat "%s" as forward and "%s" as reverse experiment.\n',
                      experiments[1], experiments[2]),
              call.=FALSE)
      expected_experiments <- experiments
    } else {
      experiments <- experiments[match(experiments, expected_experiments)]
      cat(sprintf('We will treat "%s" as forward and "%s" as reverse experiment.\n',
                  experiments[1], experiments[2]))
    }
    experiment_type <- c(experiment_type, 'FOR', 'REV')
  } else if(length(experiments) == 1) {
    # This is the standard case, if only a forward experiment is given
    message(sprintf('There is only one experiment ("%s") defined.\n', experiments))
    experiment_type <- c(experiment_type, 'FOR')
  } else {
    stop(sprintf('To much experiments defined in MaxQuant (%s). This script can only handle up to 2 experiments (for, rev).\n',
                 paste(experiments, collapse=', ')),
         call.=FALSE)
  }
} else {
  message(sprintf('There are no experiments defined! Assuming this is just a forward experiment.\n'))
  forward_only <- TRUE
  experiments <- c('')
  experiment_type <- c(experiment_type, 'FOR')
}

# Checking if it is a triple label experiment
is_triple <- FALSE
if(summary$Multiplicity[1] == 3) {
  experiment_type <- c(experiment_type, 'TRIPLE')
  is_triple <- TRUE
}


# Extract labels from file name -------------------------------------------

if(length(summary$Raw.file) == 2) {
  rawfile_names <- head(summary$Raw.file, -1)
} else {
  rawfile_names <- head(summary$Raw.file, -(length(experiments) + 1))
}

filename_df <- 
  ldply(as.list(unique(
    sub('(.*_\\d{4})-[A-Z](_.*)','\\1\\2',rawfile_names))), 
    function(x) as.data.frame(RawFile(x)))
filename_df$name <- interaction(filename_df$group, filename_df$barcode, sep='_')
# In case an overwrite is set, we use these names
if(!OVERWRITE_forward_name == '') filename_df$name[1] <- OVERWRITE_forward_name
if(!OVERWRITE_reverse_name == '') filename_df$name[2] <- OVERWRITE_reverse_name

filename_df$experiments <- 
  unique(na.omit(summary$Experiment[summary$Experiment != '']))
if(!is.null(summary$Experiment)) {
  filename_df <- filename_df[match(filename_df$experiments, expected_experiments),]
}

filename_df$plot_label <- as.character(filename_df$barcode)
if(is.null(getOption('cfpscripts.test_mode')) & 'DML' %in% experiment_type) {
  for(i in seq(nrow(filename_df))) {
    user_input <- readline(sprintf('Rename "%s" experiment (default: "%s"): ', 
                                   filename_df$experiments[i], filename_df$plot_label[i]))
    if(user_input != '') filename_df$plot_label[i] <- user_input
  }
}

# creating sample data list -----------------------------------------------

sample_data <- list()
sample_data$id <- paste(filename_df$name, collapse='_')
sample_data$enzymes <- summary$Enzyme[1]
sample_data$name <- filename_df$name

# defining some names for the output files -------------------------------- 

pG_identified_filename <- sprintf("proteinGroups_%s.txt",sample_data$id) 
pG_filtered_filename <- 
  sprintf("proteinGroups_%s_filtered.txt",sample_data$id)
pG_indicated_filename <- 
  sprintf("proteinGroups_%s_indicated.txt",sample_data$id)
pG_imputed_filename <- 
  sprintf("proteinGroups_%s_imputed.txt",sample_data$id)
pG_silac_filename <- 
  sprintf("proteinGroups_%s_filtered_SILAC_ratio.txt",sample_data$id)

missed_cleavage_plot_filename <- 
  sprintf('Missed_Cleavage_%s.pdf',sample_data$id)
forhistogram_plot_filename <- 
  sprintf('Forward_Histogram_%s.pdf',sample_data$id)
revhistogram_plot_filename <- 
  sprintf('Reverse_Histogram_%s.pdf',sample_data$id)
scatterplot_filename <- 
  sprintf('Scatterplot_%s.pdf',sample_data$id)


# Filtering the protein groups --------------------------------------------

graphsl_stats <- list()

pg$label <- getLabel(pg, 'Gene.names', 'Protein.IDs',
                     colname_regex='([^;]+).*', fallback_regex='([^;]+).*')

pg_flt <- filterWholeDataset(pg)
pg_ident <- filterIdentifiedProteins(pg_flt)

if(experiments[1] != '') {
  experiments_strings <- paste0('.', filename_df$experiments)
} else {
  experiments_strings <- ''
}

ratio_HL_pg <- apply(pg_ident[paste0('Ratio.H.L', experiments_strings)],
                      1,
                      function(x) suppressWarnings(max(x, na.rm=TRUE)) > 0)

pg_df <- data.frame(dataset = factor(c('original', 'filtered', 'identified',
                                       'ratios H/L'), 
                                     levels=c('original', 'filtered', 'identified', 
                                              'ratios H/L', 'pg forward', 'pg reverse',
                                              'ratios H/M', 'ratios M/L')),
                    count = c(nrow(pg), nrow(pg_flt), nrow(pg_ident),
                              sum(ratio_HL_pg)))

if(!forward_only) {
  ratio_forward_pg <- apply(pg_ident[paste0(c('Razor...unique.peptides','Unique.peptides'), experiments_strings[1])], 
                            1, 
                            function(x) { x[1] >= 2 & x[2] >= 1})
  ratio_reverse_pg <- apply(pg_ident[paste0(c('Razor...unique.peptides','Unique.peptides'), experiments_strings[2])], 
                            1, 
                            function(x) { x[1] >= 2 & x[2] >= 1})
  pg_df <- rbind(pg_df,
                 data.frame(dataset=factor(c('pg forward', 'pg reverse')),
                            count=c(sum(ratio_forward_pg, na.rm=TRUE),
                                    sum(ratio_reverse_pg, na.rm=TRUE))))
}

if(is_triple) {
  ratio_HM_pg <- apply(pg_ident['Ratio.H.M'],
                       1,
                       function(x) suppressWarnings(max(x, na.rm=TRUE)) > 0)
  ratio_ML_pg <- apply(pg_ident['Ratio.M.L'],
                       1,
                       function(x) suppressWarnings(max(x, na.rm=TRUE)) > 0)
  pg_df <- rbind(pg_df,
                 data.frame(dataset=factor(c('ratios H/M', 'ratios M/L')),
                            count=c(sum(ratio_HM_pg, na.rm=TRUE),
                                    sum(ratio_ML_pg, na.rm=TRUE))))
}

y_label_pos <- -max(pg_df$count) * 0.05
pg_count_graph <- ggplot(pg_df, aes(x=dataset, y=count)) + 
  geom_bar(stat='identity', na.rm=TRUE) +
  scale_y_continuous(limits = c(-max(pg_df$count) * 0.07, max(pg_df$count) * 1.1)) +
  geom_text(aes(label=count), y=y_label_pos, color='black', na.rm=TRUE) +
  ylab('protein groups') + xlab('filtering step') +
  ggtitle('protein groups after each filtering step')
print(pg_count_graph)
ggsave(file.path(out_directory,
                 sprintf('pg_count_%s.pdf', sample_data$id)),
       pg_count_graph,
       width=6,height=6)

graphsl_stats[['pg_count']] <- pg_count_graph

write.table_imb(pg_ident, 
                file=file.path(out_directory,pG_identified_filename))


# Filter peptides ---------------------------------------------------------

peptides_flt <- filterWholeDataset(peptides, by_bysite=F)

# create data frame for the missed cleavage data
missed_cleavages_df <- getMissedCleavageDF(peptides_flt)
missed_cleavages_plot <- plotMissedCleavages(missed_cleavages_df,sample_data)
print(missed_cleavages_plot)

graphsl_stats[['missed_cleavage']] <- missed_cleavages_plot

ggsave(file.path(out_directory,
                 sprintf('missed_cleavage_%s.pdf', sample_data$id)),
       missed_cleavages_plot,
       width=6,height=6)


# filter for intensities --------------------------------------------------

if(is_triple) {
  pg_ratios <- pg_ident[ratio_HL_pg | ratio_HM_pg | ratio_ML_pg,]
} else {
  pg_ratios <- pg_ident[ratio_HL_pg,]
}


# log2 ratios -------------------------------------------------------------

ratio_regexs <- c('Ratio\\.[HM]\\.[ML]','Ratio\\.[HM]\\.[ML]\\.normalized')
# create log2 columns for all ratio types
pg_ratios <- cbind(pg_ratios,
                   log2=log2(pg_ratios[grep(paste(ratio_regexs, rep(experiments_strings, each=length(experiments)), '$', sep='', collapse='|'), 
                                            names(pg_ident), value=TRUE)]))
# defining column names to use --------------------------------------------------

intensity_columns <- sort(grep(paste('Intensity.[HLM]', 
                                     rep(experiments_strings, each=length(experiments)), 
                                     '$', 
                                     sep='', collapse='|'), 
                               names(pg_ratios), value=TRUE))
ratio_columns <- sort(grep(paste('^Ratio\\.[HM]\\.[ML]', 
                                 rep(experiments_strings, each=length(experiments)), 
                                 '$', 
                                 sep='', collapse='|'), 
                           names(pg_ratios), value=TRUE))
ratio_norm_columns <- sort(grep(paste('^Ratio\\.[HM]\\.[ML].normalized', 
                                      rep(experiments_strings, each=length(experiments)), 
                                      '$', 
                                      sep='', collapse='|'), 
                                names(pg_ratios), value=TRUE))
if(normalize) {
  columns_to_use <- ratio_norm_columns
} else {
  columns_to_use <- ratio_columns
}
log_columns_to_use <- paste0('log2.', columns_to_use)

if(forward_only & !is_triple) {
  columns_to_keep_in_filtered <- 
    c("Protein.IDs","Fasta.headers",
      grep("Protein.names", names(pg_ratios), value=TRUE),
      grep("Gene.names", names(pg_ratios), value=TRUE),
      "Mol..weight..kDa.","Sequence.length",
      "Ratio.H.L","Ratio.H.L.normalized","Ratio.H.L.count",
      "Sequence.coverage....","Unique.peptides",
      "Intensity.H", "Intensity.L",
      log_columns_to_use)
} else if (!forward_only & !is_triple) {
  columns_to_keep_in_filtered <- 
    c("Protein.IDs","Fasta.headers",
      grep("Protein.names", names(pg_ratios), value=TRUE),
      grep("Gene.names", names(pg_ratios), value=TRUE),
      "Mol..weight..kDa.","Sequence.length",
      paste0(c("Ratio.H.L.","Ratio.H.L.normalized.","Ratio.H.L.count."), experiments[1]),
      paste0(c("Ratio.H.L.","Ratio.H.L.normalized.","Ratio.H.L.count."), experiments[2]),
      paste0("Sequence.coverage.", experiments, "...."),
      paste0("Unique.peptides.", experiments),
      paste0(c("Intensity.H.", "Intensity.L."), experiments[1]),
      paste0(c("Intensity.H.", "Intensity.L."), experiments[2]),
      log_columns_to_use)
} else if (forward_only & is_triple) {
  columns_to_keep_in_filtered <- 
    c("Protein.IDs","Fasta.headers",
      grep("Protein.names", names(pg_ratios), value=TRUE),
      grep("Gene.names", names(pg_ratios), value=TRUE),
      "Mol..weight..kDa.","Sequence.length",
      "Ratio.H.L","Ratio.H.M","Ratio.M.L",
      "Ratio.H.L.normalized","Ratio.H.M.normalized","Ratio.M.L.normalized",
      "Ratio.H.L.count","Ratio.H.M.count","Ratio.M.L.count",
      "Sequence.coverage....","Unique.peptides",
      "Intensity.H", "Intensity.M", "Intensity.L",
      log_columns_to_use)
} else (
  stop(sprintf('Something went wrong, it is a condition I did not implement so far.\n'),
       call.=FALSE)
)

write.table_imb(pg_ratios[columns_to_keep_in_filtered], 
                file=file.path(out_directory,pG_filtered_filename))





# Imputing missing ratios -------------------------------------------------
# impute <- getOption('cfpscripts.impute_mode', FALSE)
if(impute | getOption('cfpscripts.impute_mode', FALSE)) {
  # imputing the missing intensities and calculating a ration on these
  
  # saving the names of the intensity and ratio columns
  # setting the 0 intensities to NA, because the imputation only replaces NA
  # values
  pg_ratios[intensity_columns][ pg_ratios[intensity_columns] == 0] <- NA 
  # appending the original columns to the data set, in case we need them 
  pg_ratios <- cbind(pg_ratios,original=pg_ratios[intensity_columns])
  # if(length(ratio_columns) == 1) {
    pg_ratios[paste0('original.', ratio_columns)] <- pg_ratios[ratio_columns]
    pg_ratios[paste0('original.', ratio_norm_columns)] <- pg_ratios[ratio_norm_columns]
#   } else {
#     pg_ratios <- cbind(pg_ratios,original=pg_ratios[ratio_columns])
#     pg_ratios <- cbind(pg_ratios,original=pg_ratios[ratio_norm_columns])
#   }
#   
  imputed_intensities <- 
    imputeBetaRandomNumbersPerColumn(pg_ratios[intensity_columns],
                                     start=impute_low,
                                     end=impute_high)
  # I append these imputed values to the filtered data
  pg_ratios <- cbind(pg_ratios, imputed_intensities$imputed_values)
  # I calculate all ratios of the imputed intensity values, but will not 
  # overwrite the old ones!
  
  if(forward_only & is_triple) {
    for(s in experiments_strings) {
      pg_ratios[paste0('imputed.Ratio.H.L', s)] <- 
        pg_ratios[[paste0('imputed.Intensity.H', s)]] / 
        pg_ratios[[paste0('imputed.Intensity.L', s)]]
      pg_ratios[paste0('imputed.Ratio.H.M', s)] <- 
        pg_ratios[[paste0('imputed.Intensity.H', s)]] / 
        pg_ratios[[paste0('imputed.Intensity.M', s)]]
      pg_ratios[paste0('imputed.Ratio.M.L', s)] <- 
        pg_ratios[[paste0('imputed.Intensity.M', s)]] / 
        pg_ratios[[paste0('imputed.Intensity.L', s)]]
      
      # Since there is no single normalize correction factor, I calculate a median
      # value for correction.
      normalize_factors_HL <- 
        median(pg_ratios[[paste0('Ratio.H.L.normalized', s)]] / 
                 pg_ratios[[paste0('Ratio.H.L', s)]], na.rm=T)
      normalize_factors_HM <- 
        median(pg_ratios[[paste0('Ratio.H.M.normalized', s)]] / 
                 pg_ratios[[paste0('Ratio.H.M', s)]], na.rm=T)
      normalize_factors_ML <- 
        median(pg_ratios[[paste0('Ratio.M.L.normalized', s)]] / 
                 pg_ratios[[paste0('Ratio.M.L', s)]], na.rm=T)
      
      pg_ratios$Ratio.H.L.is_imputed <- 
        is.na(pg_ratios[[paste0('original.Ratio.H.L', experiments_strings[1])]]) 
      pg_ratios$Ratio.H.M.is_imputed <- 
        is.na(pg_ratios[[paste0('original.Ratio.H.M', experiments_strings[1])]]) 
      pg_ratios$Ratio.M.L.is_imputed <- 
        is.na(pg_ratios[[paste0('original.Ratio.M.L', experiments_strings[1])]]) 
      
      for(ratio_column in ratio_columns) {
        pg_ratios[[ratio_column]] <- 
          ifelse(is.na(pg_ratios[[ratio_column]]), 
                 pg_ratios[[paste0('imputed.',ratio_column)]], 
                 pg_ratios[[ratio_column]])
      }
      for(i in seq(ratio_norm_columns)) {
        pg_ratios[[ratio_norm_columns[i]]] <- 
          ifelse(is.na(pg_ratios[[ratio_norm_columns[i]]]), 
                 pg_ratios[[paste0('imputed.',ratio_columns[i])]] * normalize_factors[[i]], 
                 pg_ratios[[ratio_norm_columns[i]]])
      }
      
    }
  } else if (!forward_only & !is_triple) {
    normalize_factors <- list()
    for(s in experiments_strings) {
      pg_ratios[paste0('imputed.Ratio.H.L', s)] <- 
        pg_ratios[[paste0('imputed.Intensity.H', s)]] / 
        pg_ratios[[paste0('imputed.Intensity.L', s)]]
      
      # Since there is no single normalize correction factor, I calculate a median
      # value for correction.
      normalize_factors[[s]] <- 
        median(pg_ratios[[paste0('Ratio.H.L.normalized', s)]] / 
                 pg_ratios[[paste0('Ratio.H.L', s)]], na.rm=T)
    }
    pg_ratios$Ratio.H.L.is_imputed <- 
      is.na(pg_ratios[[paste0('original.Ratio.H.L', experiments_strings[1])]]) | 
      is.na(pg_ratios[[paste0('original.Ratio.H.L', experiments_strings[2])]])
    
    for(ratio_column in ratio_columns) {
      pg_ratios[[ratio_column]] <- 
        ifelse(is.na(pg_ratios[[ratio_column]]), 
               pg_ratios[[paste0('imputed.',ratio_column)]], 
               pg_ratios[[ratio_column]])
    }
    for(i in seq(ratio_norm_columns)) {
      pg_ratios[[ratio_norm_columns[i]]] <- 
        ifelse(is.na(pg_ratios[[ratio_norm_columns[i]]]), 
               pg_ratios[[paste0('imputed.',ratio_columns[i])]] * normalize_factors[[i]], 
               pg_ratios[[ratio_norm_columns[i]]])
    }
  } else if (forward_only & !is_triple) {
    pg_ratios['imputed.Ratio.H.L'] <- 
      pg_ratios[['imputed.Intensity.H']] / 
      pg_ratios[['imputed.Intensity.L']]
    
    # Since there is no single normalize correction factor, I calculate a median
    # value for correction.
    normalize_factors_HL <- 
      median(pg_ratios[['Ratio.H.L.normalized']] / 
               pg_ratios[['Ratio.H.L']], na.rm=T)
    
    pg_ratios$Ratio.H.L.is_imputed <- 
      is.na(pg_ratios[['original.Ratio.H.L']])
    
    for(ratio_column in ratio_columns) {
      pg_ratios[[ratio_column]] <- 
        ifelse(is.na(pg_ratios[[ratio_column]]), 
               pg_ratios[[paste0('imputed.',ratio_column)]], 
               pg_ratios[[ratio_column]])
    }
    for(i in seq(ratio_norm_columns)) {
      pg_ratios[[ratio_norm_columns[i]]] <- 
        ifelse(is.na(pg_ratios[[ratio_norm_columns[i]]]), 
               pg_ratios[[paste0('imputed.',ratio_columns[i])]] * normalize_factors[[i]], 
               pg_ratios[[ratio_norm_columns[i]]])
    }
  } else {
    stop('we can not impute in case of triple label AND for and reverse...')
  }
  
  pg_ratios <- pg_ratios[-grep('^log2.', names(pg_ratios))]
  pg_ratios <- cbind(pg_ratios,
                     log2=log2(pg_ratios[grep(paste(ratio_regexs, rep(experiments_strings, each=length(experiments)), '$', sep='', collapse='|'), 
                                              names(pg_ident), value=TRUE)]))
  
  
  write.table_imb(pg_ratios, 
                  file=file.path(out_directory,pG_imputed_filename))
}

# Histograms and intensity scatter plots---------------------------------------

xlim_min <- -5
xlim_max <- 5

graphs_histogram <- list()
graphs_norm_histogram <- list()
graphs_boxplot <- list()
graphsl_combined <- list()
graphsl_ratio_scatter <- list()



for(i in seq(columns_to_use)) {
  median_experiment <- median(pg_ratios[[ratio_columns[i]]], na.rm=TRUE)
  median_norm_experiment <- median(pg_ratios[[ratio_norm_columns[i]]], na.rm=TRUE)
  graph_string <- ifelse(experiments[i] == '', i,experiments[i])
  boxplot_xlab <- sample_data$name[i]
  ratio_label <- 'H/L'
  if(forward_only) {
    negative <- FALSE
    title <- sub('Ratio\\.([HM])\\.([LM]).*', '\\1/\\2', columns_to_use)[i]
    ratio_label <- title
    graph_string <- sub('Ratio\\.([HM])\\.([LM]).*', '\\1\\2', columns_to_use)[i]
    boxplot_xlab <- sample_data$name[1]
  } else {
    if(i == 2) {
      title <- 'Reverse Experiment'
      negative <- TRUE
    } else {
      title <- 'Forward Experiment'
      negative <- FALSE
    }
  }
  temp_log2_ratio <- log2(pg_ratios[[ratio_columns[i]]])
  temp_log2_ratio_norm <- log2(pg_ratios[[ratio_norm_columns[i]]])
  graphs_histogram[[graph_string]] <- 
    ggplot(pg_ratios, aes(x=temp_log2_ratio)) + 
    geom_histogram(binwidth=.2,color='black',fill='grey', na.rm=TRUE) + 
    xlab(sprintf('log2 ( %s )', ratio_label)) + ylab("Frequency") + xlim(xlim_min,xlim_max) +
    ggtitle(sprintf('%s\nMedian-Ratio: %.2f',
                    boxplot_xlab,
                    median_experiment))
  graphs_norm_histogram[[graph_string]] <- 
    ggplot(pg_ratios, aes(x=temp_log2_ratio_norm)) + 
    geom_histogram(binwidth=.2,color='black',fill='grey', na.rm=TRUE) + 
    xlab(sprintf('log2 ( %s )', ratio_label)) + ylab("Frequency") + xlim(xlim_min,xlim_max) +
    ggtitle(sprintf('%s normalized\nMedian-Ratio: %.2f', 
                    boxplot_xlab,
                    median_norm_experiment))
  
  graphs_boxplot[[graph_string]] <- 
    plotRatioBoxplot(pg_ratios, 
                     colname <- columns_to_use[i],
                     # experiment=paste0('.',experiments[i]), 
                     labels='label') +
    xlab(boxplot_xlab) +
    ylab(ifelse(normalize,
                sprintf('log2 ( %s ) normalized',ratio_label),
                sprintf('log2 ( %s )', ratio_label)))
  
  ###############################################################################
  # arange the boxplots next to the two histograms and save them in files
  graphsl_combined[[graph_string]] <- 
    arrangeGrob(graphs_histogram[[graph_string]], 
                 graphs_norm_histogram[[graph_string]], 
                 graphs_boxplot[[graph_string]], 
                 layout_matrix=rbind(c(1,3),c(2,3)), 
                 top=paste(title))
#   grid.arrange(
#       grid.arrange(graphs_histogram[[graph_string]], 
#                    graphs_norm_histogram[[graph_string]], 
#                   ncol=1), 
#       graphs_boxplot[[graph_string]], ncol=2,
#       main=paste(title))
  
  grid.newpage()
  grid.draw(graphsl_combined[[graph_string]])
  ggsave(file.path(out_directory,
                   paste0('histogram_',graph_string,'_',sample_data$id,'.pdf')),
         graphsl_combined[[graph_string]],
         width=8,height=8)
  
  error_appeared <- FALSE
  repeat{
    tryCatch({ # we put everything into a try catch block, because sometimes we get an error
      graphsl_ratio_scatter[[graph_string]] <- 
        plotRatioScatter(pg_ratios,
                         labels='label',
                         x_col=columns_to_use[i], 
                         negative=negative) +
        theme(legend.position="top") +
        xlab(sprintf('%s (%s)', log_columns_to_use[i], filename_df$plot_label[i]))
      
      print(graphsl_ratio_scatter[[graph_string]])
      ggsave(file.path(out_directory,
                       paste0('ratio_scatter_',graph_string,'_',sample_data$id,'.pdf')),
             graphsl_ratio_scatter[[graph_string]],
             width=8,height=8)
    },
    error=function(e) {
      mylog('redo the ratioscatterplot.', 'WARN')
      error_appeared <- TRUE
    }
    )
    if(!error_appeared){
      break
    }
  }
}

# Highlight provided uniport IDs ------------------------------------------

pg_ratios$highlight <- NA
if(length(search_fasta_header) > 0) {
  found_uniprot_ids <- unique(
    c(grep(paste(search_fasta_header,collapse="|"),
           pg_ratios$Fasta.headers,
           ignore.case=TRUE),
      grep(paste(search_fasta_header,collapse="|"),
           pg_ratios$Protein.IDs,
           ignore.case=TRUE)))
  if(length(found_uniprot_ids) > 0) {
    pg_ratios[found_uniprot_ids,]$highlight <- TRUE
  }
}

indicated_df <- pg_ratios['Protein.IDs']


# scatter plot creation ---------------------------------------------------

scatter_df <- permuteNames(log_columns_to_use)
graphsl_scatter_plots <- list()
if(nrow(scatter_df) > 0) {
  for(line in seq(nrow(scatter_df))) {
    
    ###############################################################################
    # create a scatterplot and use identify to select points for labeling.
    # we use this information within ggplot to label the points in the ggplot graph
    
    if(any(grepl('is_imputed$', names(pg_ratios)))) {
      is_imputed <- apply(pg_ratios[sub('log2\\.(Ratio.[HM].[LM]).*','\\1.is_imputed',scatter_df[1,])],
                          1, any)
    } else {
      is_imputed <- FALSE
    }
    
    maxx_value <- max(abs(pg_ratios[[scatter_df[line, 2]]]), na.rm=TRUE)
    maxy_value <- max(abs(pg_ratios[[scatter_df[line, 1]]]), na.rm=TRUE)
    minx_value <- min(abs(pg_ratios[[scatter_df[line, 2]]]), na.rm=TRUE)
    miny_value <- min(abs(pg_ratios[[scatter_df[line, 1]]]), na.rm=TRUE)
    scatter_limits <- 
      switch(zoom_quadrant, 
             LR=list(
               x_zoom=c(-0.5, maxx_value + 1),
               y_zoom=c(-maxy_value - 1, 0.5)),
             UL=list(
               x_zoom=c(-maxx_value - 1, 0.5),
               y_zoom=c(-0.5, maxy_value + 1 ))
      )
    max_value <- max(c(maxx_value, maxy_value))
    
    mymax <- ifelse(max_value >= 10, max_value, 10)
    plot(pg_ratios[[scatter_df[line, 2]]],
         pg_ratios[[scatter_df[line, 1]]],
         xlim = c(-mymax, mymax),ylim = c(-mymax, mymax),
         col=ifelse(!is.na(pg_ratios$highlight), 'red', 'black'),
         pch=ifelse(is_imputed, 19, 1),
         cex=ifelse(is_imputed, .5, 1))
    abline(v=(0),h=(0),col="grey")
    abline (v=c(1,-1), h=c(1, -1), col="red",lty=2)
    
    pg_ratios$pos <- NA
    
    if(is.null(getOption('cfpscripts.test_mode'))) {
    identified <- identify(pg_ratios[[scatter_df[line, 2]]],
                           pg_ratios[[scatter_df[line, 1]]],
                           labels=pg_ratios$label,
                           pos=TRUE)
    pg_ratios[identified$ind,]$pos <- identified$pos
    } else {
      identified <- 
        list(ind=sample(seq(nrow(pg_ratios)), floor(nrow(pg_ratios) / 8)), 
             pos=sample(c(1,2,3,4), floor(nrow(pg_ratios) / 8), replace=TRUE))
    }
    
    column_name <- sprintf('scatterplot_%s', line)
    indicated_df[column_name] <- pg_ratios$pos
    
    scatter_plot <- 
      ggplot(pg_ratios,
             aes_string(x=scatter_df[line, 2], y=scatter_df[line, 1])) + 
      geom_point(alpha=.2, size=2, na.rm=TRUE, shape=21, 
                 data=subset(pg_ratios, is.na(pos) & 
                               is.na(highlight) & 
                               !is_imputed)) +
      geom_hline(aes(yintercept=0), color='grey') + 
      geom_vline(aes(xintercept=0), color='grey') +
      geom_hline(aes(yintercept=1),linetype='dashed',color='red') +
      geom_hline(aes(yintercept=-1),linetype='dashed',color='red') + 
      geom_vline(aes(xintercept=1),linetype='dashed',color='red') +
      geom_vline(aes(xintercept=-1),linetype='dashed',color='red') +
      ggtitle('Scatterplot') + 
      ylab(sprintf('%s (%s)', scatter_df[line, 1], filename_df$plot_label[1])) +
      xlab(sprintf('%s (%s)', scatter_df[line, 2], filename_df$plot_label[2])) + 
      theme_imb() +
      scale_x_continuous(breaks=seq(-100,100,4), minor_breaks=seq(-100,100,1), limits=c(-mymax, mymax)) + 
      scale_y_continuous(breaks=seq(-100,100,4), minor_breaks=seq(-100,100,1), limits=c(-mymax, mymax))
    if(!length(identified$ind) == 0) {
      scatter_plot <- scatter_plot +
        geom_point(color='red', na.rm=TRUE, 
                   data=subset(pg_ratios, !is.na(pos) & is.na(highlight))) +
        geom_text_repel(data=subset(pg_ratios, pos >= 1 & is.na(highlight)),
                        aes(label=label), na.rm=TRUE, size=label_font_size)
    }
    if(any(!is.na(pg_ratios$highlight))) {
      scatter_plot <- scatter_plot + 
        geom_point(color='lightgreen', na.rm=TRUE, data=subset(pg_ratios, !is.na(highlight))) + 
        geom_text(data=subset(pg_ratios, !is.na(highlight)), aes(label=label), 
                  vjust=1.5, size=label_font_size, na.rm=TRUE)
    }
    if(impute | getOption('cfpscripts.impute_mode', FALSE)) {
      scatter_plot <- scatter_plot + 
        geom_point(data=subset(pg_ratios, is_imputed), color='blue', na.rm=TRUE,
                   aes_string(x=scatter_df[line, 2], y=scatter_df[line, 1]))
    }
    
    print(scatter_plot)
    ggsave(file.path(out_directory, sprintf('scatterplot_%s.pdf', line)),
           scatter_plot, width=7, height=7)
    
    graphsl_scatter_plots[[line]] <- scatter_plot
    
  }
  
  clicked_pg <- apply(indicated_df[-1], 1, function(x) any(!is.na(x)))
  write.table_imb(pg_ratios[unique(c(which(pg_ratios$highlight), which(clicked_pg))), 
                            columns_to_keep_in_filtered], 
                  file=file.path(out_directory,pG_indicated_filename))
}


experiment_type_string <- paste(experiment_type, collapse='_')
cat(sprintf('We are using the following PDF setup: "%s"\n', experiment_type_string))

switch(experiment_type_string,
       SILAC_FOR_REV={
         pdf_setup <- getPdfSetup('SILAC_FOR_REV')
         createPdfs(pdf_setup, sample_data$id)},
       DML_FOR_REV={
         pdf_setup <- getPdfSetup('DML_FOR_REV')
         createPdfs(pdf_setup, sample_data$id)},
       SILAC_FOR={
         pdf_setup <- getPdfSetup('SILAC_FOR')
         createPdfs(pdf_setup, sample_data$id)},
       DML_FOR={
         pdf_setup <- getPdfSetup('SILAC_FOR')
         createPdfs(pdf_setup, sample_data$id)},
       SILAC_FOR_TRIPLE={
         pdf_setup <- getPdfSetup('SILAC_FOR_TRIPLE')
         createPdfs(pdf_setup, sample_data$id)},
       cat(sprintf('The is no PDF setup for "%s".\n',
                   experiment_type_string)))


# Checking existence of proteins in FASTA or PG ---------------------------

fasta_db <- strsplit(parameters[parameters$Parameter == 'Fasta file','Value'], ';')[[1]]
if(!all(file.exists(fasta_db))) {
  fasta_db <- 
    sapply(fasta_db, function(x) {
      ifelse(grepl('Fasta_UNIPROT',x), 
             sub('.*Fasta_UNIPROT.(.*$)', '/Volumes/Proteomics-Data/Fasta_UNIPROT/\\1', x),
             file.path('.',basename(x)))
    })
}

if(length(search_fasta_header) >= 1) {
  if(any(file.exists(fasta_db))) {
    cat(sprintf('\nChecking if "search_fasta_header" names are matching in fasta or proteinGroups file.\n'))
    search_string <- paste(search_fasta_header,collapse="|")
    fasta <- unlist(lapply(fasta_db, read.fasta, seqtype='AA', as.string=T))
    fasta_results <- grep(search_string, names(fasta), ignore.case=TRUE)
    cat(sprintf('For %s elements (%s), we found %s matching fasta entries in "%s".\n',
                length(search_fasta_header), 
                paste(search_fasta_header, collapse=', '), 
                length(fasta_results),
                paste(fasta_db, collapse=', ')))
    pg_id_results <- grep(search_string, pg$Protein.IDs, ignore.case=TRUE)
    cat(sprintf('For %s elements (%s), we found %s matching protein groups (Protein.IDs) entries.\n',
                length(search_fasta_header), paste(search_fasta_header, collapse=', '), length(pg_id_results)))
    pg_fasta_results <- grep(search_string, pg$Fasta.headers, ignore.case=TRUE)
    cat(sprintf('For %s elements (%s), we found %s matching protein groups (Fasta.headers) entries.\n',
                length(search_fasta_header), paste(search_fasta_header, collapse=', '), length(pg_fasta_results)))
    pg_id_results <- grep(search_string, pg_ident$Protein.IDs, ignore.case=TRUE)
    cat(sprintf('For %s elements (%s), we found %s matching identified protein groups (Protein.IDs) entries.\n',
                length(search_fasta_header), paste(search_fasta_header, collapse=', '), length(pg_id_results)))
    pg_fasta_results <- grep(search_string, pg_ident$Fasta.headers, ignore.case=TRUE)
    cat(sprintf('For %s elements (%s), we found %s matching identified protein groups (Fasta.headers) entries.\n',
                length(search_fasta_header), paste(search_fasta_header, collapse=', '), length(pg_fasta_results)))
  } else {
    warning(sprintf('Fasta file "%s" could not be found.\n', fasta_db),
            sprintf('Please set variable "OVERWRITE_fasta_db" and set it to the correct path.'),
            call.=FALSE)
  }
}

interactivePlot <- function(data, x_col, y_col, 
                            x_label='', y_label='', 
                            x_threshold=1, y_threshold=1) {
  mymax <- max(abs(data[c(x_col, y_col)]), na.rm=TRUE)
  plotly_limits <- c(-mymax, mymax) * 1.1
  g <- ggplot(data, aes_string(x=x_col, y=y_col)) + 
    theme_imb() +
    geom_hline(aes(yintercept=0), color='grey', size=.2) + 
    geom_vline(aes(xintercept=0), color='grey', size=.2) +
    geom_hline(yintercept=c(-1,1),linetype='dashed',color='red', size=.1) +
    geom_vline(xintercept=c(-1,1),linetype='dashed',color='red', size=.1) +
    geom_point(aes(text = sprintf("Label: %s<br />First ProtID: %s", 
                                  label, sub(';.*','', Protein.IDs))), na.rm=TRUE) +
    ggtitle('Scatterplot') + 
    scale_x_continuous(x_label, breaks=seq(-100,100,1), 
                       minor_breaks=seq(-100,100,.5), limits=plotly_limits) + 
    scale_y_continuous(y_label, breaks=seq(-100,100,1), 
                       minor_breaks=seq(-100,100,.5), limits=plotly_limits)
  (gg <- ggplotly(g))
  print(gg)
}

if(interactive_plot) {
  interactivePlot(pg_ratios, scatter_df[line, 2], scatter_df[line, 1],
                  'reverse','forward')
}

###############################################################################
# filter modification files
rMQanalysis::filterModifications(sample_data$id, data_directory)


