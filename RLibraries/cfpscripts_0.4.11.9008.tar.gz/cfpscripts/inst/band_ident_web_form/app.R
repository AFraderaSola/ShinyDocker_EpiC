#
# shiny App to order a band identification 
# 
# developer: Timur Horn
# version: 0.0.2
# date: 2018.12.05
# 
#

library(shiny)
#library(shinyhelper)
library(shinyBS)
library(shinyjs)
# package "V8" needed
library(yaml)
library(seqinr)
library(cfpscripts)
library(rmarkdown)


##Mario General ToDo
##Mario * we should create an extra package for the GUI, fancy names could be fouRS for Shiny Sample Submission Sheet :) but it reminds me on the iPhone 4S joke saying iPhone for Ass :-)
##Mario * Swithcing to package, we split code into ui.R, server.R and global.R files. All functions go in individual files into R folder
##Mario * add documentation to functions, shouldn't be much but roughly telling what they do and what they return
##Mario * recommended but not mendatory, add the package to the related function, e.g. shinyjs::useShinyjs()



width <- "5cm" ##Mario which width? species_dropdown_width? Other with as well?
#Output directory for all orders
orders_directory <- file.path(".", "outputs")

maximum_upload_megabytes <- 40
options(shiny.maxRequestSize=maximum_upload_megabytes * 1024^2)

user_inputs_file_name <- "user_inputs.yaml"

species_dbs <- ##Mario this is the default LIST and will be replaced by a VECTOR! Something might go wrong here
  list(h.sapiens="H.sapiens", 
       m.musclus="M.musclus",
       x.laevis="X.laevis", 
       c.elegans="C.elegans")

available_proteases <- c("undefined","AspN", "GluC", "LysC", "Chymotrypsin")

if(file.exists("Available_species_DBs.csv")){
  available_dbs <- read.csv2("Available_species_DBs.csv", stringsAsFactors=FALSE)
  species_dbs <- available_dbs$species_names
}

##Mario better name might be "extend_js_code"
jsCode <- 'shinyjs.winopenAndPrint = function(url){ 
    myWindow = window.open(url, "_blank");
    myWindow.print()
}'

background_dbs <- list(E.coli="E.coli", S.cerevisiae="S.cerevisiae") ##Mario background might be the same as species_dbs in the end
ui <- fluidPage(theme="style.css",
  
   shinyjs::useShinyjs(), ##Mario adding package:: makes everything more robust but a lot of work!
   extendShinyjs(text=jsCode),
   fluidRow(
     ##Mario Some comments like HEADER or MAIN CONTENT might be usefull here. Maybe by "Code -> Insert Section" 
     ##Mario option so you get a bookmark in the lower left.
     column(3,
        img(src="imb_logo.png",
            align="left", 
            width="250")
     ),
     column(9,
       shiny::h1("IMB Proteomics"),
       shiny::h2("Sample Submission Form: Band Identification")
     )
   ),
   
   fluidRow(
       ##TODO coockies as service
       ##TODO credentials 
        shiny::actionButton(inputId="testMark", label="TEST MARK ELEMENTS"),
      column(12,
       h3("User Informations"),
       tags$div(class="userinfos",
         textInput("firstname", "First name"),
        
         textInput("surname", "Surname"),
        
         textInput("group","Group"),
      
         textInput("phone","Phone"),
         ##TODO list with valid values? or dynamic check
         textInput("billing","Billing"),
         textInput("email","E-mail")
         ##Mario also commented below, these fields should be created with a list since you will use ALL these names again for validation.
         ##Mario maybe you can also add the validation to the list as well as width
         ##Mario might be a bit complicated if we now also add dropdown for group info but should be feasable like
# list(
#   list(type='textInput', variable='firstname', name='First name', validation='\\w'),
#   list(type='dropdown', variable='group', name='Group', 
#        values=c(IMB_EW='Eva Wolf',
#                 IMB_BU='Falk Butter',
#                 EXT_CF='External'))
# )
        ##Mario and we could loop over this list
       )
      )
    ),
   h3("Digestion"),
fluidRow(
  column(4, 
         shiny::textInput(inputId="barcode_acid", label="Acid Hydrolysis",
                          placeholder = "barcode format IMB_XX_9999"),
         tags$p(style="color:red", ##Mario this text needs to be adapted since we need up to 3 times the material for all proteases one amount
                "Please provide enough material(= two identical band but two 
                  different sticker numbers). One sample will be digested with 
                  trypsin and the other hydrolysed with 3M HCl")
  ),
  column(4, 
         shiny::textInput(inputId="barcode_trypsin", label="Trypsin",
                          placeholder="barcode format IMB_XX_9999")),
  column(4,
         shiny::selectizeInput(inputId="name_protease", label="Protease",
                               choices=available_proteases),
         shiny::textInput(inputId="barcode_protease", label="Barcode", 
                          placeholder="barcode format IMB_XX_9999"))
),

   fluidRow(
   column(4,
     h3("Species"),
    
      shiny::selectInput(inputId="species_dbs", label="Databases:",
                          selectize=F,
                          choices=species_dbs,
                          multiple=T, size=length(species_dbs)),
              
     shiny::textInput(inputId="custom_species_db", label="Other:", width=width),
     hidden( ##Mario does hidden make sense here? I would comment out the rows or does this has an advantage
       shiny::fileInput(inputId="custom_species_db_file",
                             label="or custom DB file",
                             buttonLabel="Upload File",
                             multiple=TRUE)
     )
   ),
   column(4,
     h3("Background"),
     shiny::selectInput(inputId="background_dbs",label="Database:",
                        selectize=F,
                        choices=background_dbs),
     shiny::textInput(inputId="custom_background_db", label="Other:", width=width),
     hidden(
       shiny::fileInput(inputId="custom_background_db_file",
                             label="or custom DB file",
                             buttonLabel="Upload File"))
     
   ),
   column(3,
     h3("Comments"),
     shiny::textAreaInput(inputId="dbs_comments", label="Additional comments:",
                          height="200")
   )),
   
   h3("Band Identification"),
   fluidRow(
     
     column(4,
       shiny::numericInput(inputId="band_weight_kda",
                           label="Moleculare weight(kDa) of band", 
                           min=0, max=1000, value=50),
       shiny::selectizeInput(inputId="target_protein",
                             label="Choose protein accesion number if known",
                             choices=NULL, options=list(create=TRUE, maxItems=4),
                             multiple=TRUE),
       shinyBS::popify(
          shiny::textAreaInput(inputId="fasta_sequence",
                            label="Or/and protein sequence(s)",
                            placeholder="fasta sequence with headers",
                            width="100%", rows=6),
          title="<b>Usage:</b>", content=paste("Use the standard fasta format",
                                            "<b>No whitespaces in sequence and we recommend no whitespace in names.</b>",
                                             "Example:",
                                             ">ProteinXY_SpeciesZ_FunctionW...",
                                             "QSGAGNNWAKGHYTEGAELVDQVLDV...",
                                            ">ProteinABC_SP....",
                                            "WAKGHYTEGAEL..."),
          placement="right", trigger="hover")
     ),
     column(4, ##Mario so many!!!! spaces... :-(
     shiny::textInput(inputId = "protease", label = "Protease",
                      placeholder = "used in case of partial digestion"),
     shiny::textInput(inputId = "modification", label = "Modification",
                      placeholder="name"),
     shiny::fileInput(inputId = "gel_picture", label = "Gel picture",
                      accept = c("image/jpeg","image/png"),
                      buttonLabel = "Gel picture", multiple = F)
     ),
     column(3,
            h3("Comments"),
            shiny::textAreaInput(inputId="bandIdent_comments", label="Additional comments:",
                                 height="200")
     )
   ),
   
   h3("Staining"),
   shiny::radioButtons(
     inputId="staining", 
     label="Staining",
     choices=c("Coomassie",
               "Silver stain (for optimal results we recommend Life Technology LC6070)")),
   
   
   hr(),
   
   verbatimTextOutput("message"),
   
   shiny::actionButton(inputId="submit", label="Print"),
   
   
   hr()
   
  
)


# Define server logic 
server <- function(input, output, session) {
  
  observeEvent(input$submit,{
    apply_submit(input, output)
    
  })
  
  observeEvent(input$testMark,{
    markRequiredInput("surname", "Bitte ausfühlen Bitte ausfühlen Bitte ausfühlen Bitte ausfühlen") ##Mario ausfüHlen :-D
    markRequiredInput("barcode_acid", "Bitte ausfühlen Bitte ausfühlen Bitte ausfühlen Bitte ausfühlen")
    
  })
  
  #I have no idea why "paste" works here. Observe several inputs ##Mario looks dirty but you paste together all inputs into a single string. This string is changing ALLWAYS when any of the inputs change!
  observeEvent({paste(input$species_dbs, input$custom_species_db_file)},
  {
    #print(typeof(input$custom_species_db_file))
    file_names <- getFilenamesFromChosenDBs(input)            
    
    if(!is.null(input$custom_species_db_file)){
      file_names <- c(file_names, input$custom_species_db_file[["datapath"]])
    }
    
    prot_ids <- unlist(sapply(file_names, function(f){
      extrProtIdsFromFasta(f)
    }, USE.NAMES=FALSE))
    #print(str(prot_ids))
    target_proteins <- isolate(input$target_protein)
    #print(target_proteins)
    shiny::updateSelectizeInput(session, inputId="target_protein",
                                choices=prot_ids, server=TRUE,
                                selected=target_proteins)
    
  })
  
  observeEvent({input$name_protease},
  {
    
    if(input$name_protease == "undefined"){
      disable("barcode_protease")
      updateTextInput(session,"barcode_protease",value="")
    } else {
      enable("barcode_protease")
    }
  
  })
}

#reaction to submit button
apply_submit <- function(input,output){
  
  #create output directory name
  directory_name <- format(Sys.time(), "%Y%m%d_%H%M%S")
  directory_name <- 
    paste(directory_name, input$firstname, input$surname, input$group, 
          sep="_")
  directory_name <- gsub("\\s+", "_", directory_name)
  out_directory <- file.path(orders_directory, directory_name)

  allInputs <- isolate(reactiveValuesToList(input))
  allInputs$timestamp <- directory_name
  
  output$message <- renderText("Validate user inputs...")
  
  validation_results <- validateInputValues(allInputs)
  
  result_valid = sapply(validation_results, function(result) result$valid)
  
  if(all(result_valid)) {
    
    submitCompletedForm(allInputs, out_directory)
    
  } else {
    output$message <- 
      renderText(paste(collapse="\n", 
                       sapply(validation_results[!result_valid], 
                              function(result) {
                                sprintf("%s: %s", 
                                        result$input_elem_id, result$message)
                              })))
    
    
    removeAllRequiredMarks()
    sapply(validation_results[!result_valid], 
           function(result) {
             markRequiredInput(result$input_elem_id, result$message)
           })
    
  }

}

getFilenamesFromChosenDBs <- function(input) {
  file_names <- c()
  if(!is.null(input$species_dbs) && exists("available_dbs")) {
    db_indecies <- (unique(match(input$species_dbs, available_dbs$species_names)))
    file_names <- available_dbs$absolute_path[db_indecies]
    #print(file_names)
  }
  return(file_names)
}

validateInputValues <- function (inputs) {

  #list of named lists whith the following members
  
  #input_elem_id
  #valid (locgical)
  #message
  
  results = list()
  results = c(results, validateUserInformation(inputs))
  results = c(results, validateDataBases(inputs))
  results = c(results, validateBarCodes(inputs))
  results = c(results, validateFastaInputs(inputs))
  
##Mario have you tested this way of assigning the list instead of letting it grow?
  # results = list(
  #   validateUserInformation(inputs),
  #   validateDataBases(inputs),
  #   validateBarCodes(inputs),
  #   validateFastaInputs(inputs)
  # )
  
 
  ##TODO: validate other input field
  return(results)
}

validateUserInformation <- function(inputs) {
  results <- list()
  
  ##Mario I guess we create a global object with these information and create the fields as well as the clear names directly from this list
  user_inputs_info_names <- c("surname", "firstname", "group", "phone", "billing", "email")
  
  ##TODO avoid loops
  for(inputId in user_inputs_info_names){
    if(inputs[[inputId]] == '') {
      results[[length(results) + 1]] <- list(input_elem_id=inputId,
                                             valid=FALSE,
                                             message='Field is mandatory')
    } else {
      results[[length(results) + 1]] <- list(input_elem_id=inputId,
                                             valid=TRUE,
                                             message='Field is OK')
    }
  }
  
  return(results)
}

validateDataBases <- function(inputs) {
  results <- list()
  if(is.null(inputs$species_dbs) && inputs$custom_species_db == ''){
    results[[length(results) + 1]] <- list(input_elem_id="species_dbs",
                                           valid=FALSE,
                                           message='No species database chosen')
  }
  else{
    ##Mario EMPTY?
  }
  return(results)
}

validateSomething <- function(inputs) {
  results <- list()
  
  return(results)
}

validateBarCodes <- function(inputs) {
  results <- list()
  
  #barcode_acid
  #barcode_trypsin
  #barcode_protease
  
  if(inputs$barcode_trypsin == '' && inputs$barcode_protease == '') {
    results[[length(results) + 1]] <- list(input_elem_id="barcode_trypsin",
                                           valid=FALSE,
                                           message='At least one enzyme needed')
    results[[length(results) + 1]] <- list(input_elem_id="barcode_protease",
                                           valid=FALSE,
                                           message='At least one enzyme needed')
  }
  
  return(results)
}

##Mario one suggestion for your validation process
Validated <- function(input_element_id, message=NULL, valid=FALSE) {
  if(is.null(message)) {
    my_message <- sprintf('"%s" is not set', input_element_id)
  } else {
    my_message <- message
  }
  return(list(
    input_element_id=input_element_id,
    valid=valid, 
    message=my_message
  ))
}

validateFastaInputs <- function(inputs) {
  
  results <- list()
  
  fasta_file_input_names <- c("custom_species_db_file", "custom_background_db_file")
  
  for(input_name in fasta_file_input_names) {
    fasta_file <- inputs[[input_name]]
    if(!is.null(fasta_file)) {
      
      valid_res <- validateFastaFiles(fasta_file[["datapath"]])
      
      if(valid_res==TRUE) { ##MARIO NEVER test equals TRUE! isTRUE() or just simple the variable is enough if it is logical!
        results[[length(results)+1]] <- list(input_elem_id=input_name,
                                             valid=TRUE,
                                             message='Fasta file is OK')
      } else if(valid_res==FALSE) { ##MARIO same here! use !valid_res 
        results[[length(results) + 1]] <- list(input_elem_id=input_name,
                                               valid=FALSE,
                                               message='File is not a FASTA File or is empty')
      }
      else{
        ##Mario since I now removed the the Xs time the space between message and = I wanted to suggest a function Validated() created above
        # results[[length(results) + 1]] <- list(input_elem_id=input_name,
        #                                        valid=TRUE,
        #                                        message='No file(s) uploaded')
        results[[length(results) + 1]] <- 
          Validated(input_name, 'No file(s) uploaded', TRUE)
        ##Mario does this look better?
      }
    }
  }
  return(results)
}

validateFastaFiles <- function(file_path) {
  
  
  if(!is.null(file_path)) {
    
    result <- tryCatch({ 
      fastaDB <- lapply(file_path,
                        function(x) read.fasta(file=x, as.string=T, seqtype='AA'))
      TRUE
    },
    error = function(cond) {
      
      return(FALSE)
    },
    warning = function(cond) {
      
      return(FALSE)
    })
    
    return(result)
    
  }
  else{
    return(NULL)
  }
  
}


submitCompletedForm <- function(allInputs, out_directory) {
  if(!dir.exists(out_directory)) dir.create(out_directory, recursive=TRUE)
  
  #copy uploaded files from tmp folder
  if(!is.null(allInputs$gel_picture)) {
    allInputs$gel_picture$new_datapath <- 
      normalizePath(file.path(out_directory,
                              paste("Gel_picture",
                                    sub(".+\\.(.+)", "\\1", allInputs$gel_picture$name), 
                                    sep=".")))
    file.copy(allInputs$gel_picture$datapath, allInputs$gel_picture$new_datapath)
  }
  
  db_out_directory <- file.path(out_directory, "Custom_DB")
  if(!dir.exists(db_out_directory)) dir.create(db_out_directory)
  if(!is.null(allInputs$custom_species_db_file)) {
    
    allInputs$custom_species_db_file$new_datapath <- 
      normalizePath(file.path(db_out_directory,
                              allInputs$custom_species_db_file$name))
    file.copy(allInputs$custom_species_db_file$datapath,
              allInputs$custom_species_db_file$new_datapath)
  }
  
  if(allInputs$fasta_sequence!='') {
    ##TODO check content (fasta format)
    path <- normalizePath(file.path(db_out_directory, "custom_seq.fasta"))
    
    print("faste seq write....")
    write(allInputs$fasta_sequence, file=path)
    print("faste seq written")
    allInputs$fasta_sequence <- list(content="Custom Sequence(s) uploaded",
                                     path=path)
  }else {
    allInputs$fasta_sequence <- list(content=NULL,
                                     path=NULL)
  }
  
  if(!is.null(allInputs$custom_background_db_file)) {
    db_out_directory <- file.path(out_directory, "Custom_BG_DB")
    if(!dir.exists(db_out_directory)) dir.create(db_out_directory)
    allInputs$custom_background_db_file$new_datapath <- 
      normalizePath(file.path(db_out_directory,
                              allInputs$custom_background_db_file$name))
    file.copy(allInputs$custom_background_db_file$datapath,
              allInputs$custom_background_db_file$new_datapath)
  }
  
  
  allInputs$species_dbs <- list(names=allInputs$species_dbs,
                                paths=getFilenamesFromChosenDBs(allInputs))
  
  
  yaml::write_yaml(allInputs,file.path(out_directory, user_inputs_file_name))
  
  form_output_file <- file.path(out_directory, "CompletedForm.html")
  
  rmarkdown::render(input="BandIdent_CompletedForm.Rmd",
                    knit_root_dir=out_directory, output_dir=out_directory,
                    output_file=form_output_file)
  
  
  # insertUI(
  #   selector = "#submit",
  #   where = "afterEnd",
  #   ui = tags$div(style="display: inline-block;",
  #                 downloadButton("form_download", label = "Download Form"))
  # )
  # 
  # 
  # 
  # output$form_download <- downloadHandler(
  #   filename = paste(directory_name, "Form.html", sep=""),
  #   content = function(file) {
  #     file.copy(form_output_file, file)
  #   }
  # )
  
  showAndPrintHtmlFile(form_output_file, allInputs$timestamp)
}

#extracts Protein IDs from fasta file
extrProtIdsFromFasta <- function(fasta_file,sub_pattern=NULL){
  
  if(is.null(sub_pattern)){
    #try to determinate source DB and a respective pattern
    db_names_to_patterns <- list(uniprot=">\\w+\\|([^ ]+)\\|",
                                 ensemble=">([^ ]*)",
                                 ncbi=">([^ ]*)",
                                 default=">([^ ]+)")
    
    for(db_name in names(db_names_to_patterns)){
      if(grepl(db_name,basename(fasta_file), ignore.case=TRUE)){
        
        sub_pattern <- db_names_to_patterns[[db_name]]
      } 
    }
    
    if(is.null(sub_pattern)) sub_pattern <- db_names_to_patterns$default
  }
  
 
  f <- function(x, pos) x[grepl('^>', x)]
  
 
  header_lines <- unique(unlist(
    readr::read_lines_chunked(fasta_file, 
                              readr::ListCallback$new(f), 
                              chunk_size=500000)))
  
  sub_pattern <- paste0(sub_pattern, ".*")
  #print(length(header_lines))
  prot_ids <- sub(pattern=sub_pattern, ("\\1"), header_lines)
  
  #print(prot_ids)
  
  return(prot_ids)
  
}

showAndPrintHtmlFile <- function(path, name_replacement=NULL){
  
  new_dir <- file.path("www", "tmp")
  if(!dir.exists(new_dir)){
    dir.create(new_dir, recursive=TRUE)
  }
  
  new_path <- new_dir
  if(!is.null(name_replacement) && typeof(name_replacement) == "character"){
    new_path <- file.path(new_path, paste0(name_replacement, ".html"))
  }
  file.copy(path, new_path)
  #print(new_path)
  js_path <- sub(pattern="www.", "", new_path)
  js$winopenAndPrint(js_path)
  
}

markRequiredInput <- function(inputId, message){
  
  #removeAllRequiredMarks()
  
  #print(inputId)
  
  jquery <- paste0("label[for='", inputId, "']")
  
  #print(jquery)
  
  insertUI(selector=jquery,
           where="beforeEnd",
           ui=tags$span(class="required-asterix","*"))
           
  
  insertUI(selector=jquery,
           where="afterEnd",
           ui=tags$p(class="required-error-message",message))
  
}

removeAllRequiredMarks <- function(){
  removeUI(selector=".required-asterix, .required-error-message",
           multiple=TRUE)
}

# Run the application 
shinyApp(ui = ui, server = server)


