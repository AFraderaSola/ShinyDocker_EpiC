#
# package version: 0.4.10
# package date: 2018-05-25

pattern <- '*.raw'
setwd('F:/')
files <- list.files(pattern=pattern) 
if(length(files) > 0) {
  for(file in files) {
    folder <- sub('.raw', '',file)
    cat(sprintf('"%s" folder is created!\n', folder))
    dir.create(folder)
    file.rename(from=file,to=file.path(folder,file))
  }
} else {
  cat(sprintf('There are now %s-files in "%s"\n',pattern,getwd()))
}


