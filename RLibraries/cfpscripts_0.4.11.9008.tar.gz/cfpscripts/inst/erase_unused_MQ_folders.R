###############################################################################
#
# This script will search for some directories we do not really use and delete
# them.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.4
# date: 2018.02.13
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

folders <- list.dirs('D:/')
# folders <- list.dirs('/Volumes/Proteomics-Data/2016')

dont_delete_pattern <- 'Dont_delete.txt'
folders_to_ignore <- folders[file.exists(file.path(folders, dont_delete_pattern)) | 
                               grepl('automated_hela', folders)]

if(length(folders_to_ignore) > 0) {
  folders_not_ignored <- folders[-grep(paste(folders_to_ignore,collapse='|'), folders)]
} else {
  folders_not_ignored <- folders
}

cfpscripts::deleteUnusedMQFolders(folders_not_ignored)

cat('Checking ignored folders for DML IC subfolders')
still_to_remove <- grep('IC_', grep(paste(folders_to_ignore,collapse='|'), folders, value=TRUE), value=TRUE)

cfpscripts::deleteUnusedMQFolders(still_to_remove)


