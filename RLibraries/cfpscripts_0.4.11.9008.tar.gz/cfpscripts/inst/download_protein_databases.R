###############################################################################
#
# Script to download all important fasta files from uniprot or ensembl database.
#
# It is also possible to load multiple taxonomiy IDs into a single file but it 
# is only recommended for species from the same genus like in Danaus plexippus, 
# which consists of 3 species.
# For some reason, the ftp download on Windows make some problems yet.
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.3.2
# date: 2020.09.22
#
# package version: 0.4.10
# package date: 2018-05-25
#
###############################################################################

library(dplyr)

ref_proteomes <- read.delim('~/Downloads/proteomes-reference%3Ayes-2.tab',
                            stringsAsFactors=FALSE) %>%
  as_tibble()
overwrite_date <- '20200922' # use something like '20170123'
out_dir <- 'databases'
if(!dir.exists(out_dir)) dir.create(out_dir)


# for each entry, 
# filter ref_proteomes to specific species with tax id
# generate the two download links
# download the two files and fuse them
# split both files into swissprot and trembl
# set filenames
# * filename should be Genus.species.strain_database_date_version_comments.fasta
# * database is one of swissprot, trembl, ensembl, ncbi, own, or any specific DB
# 

UniprotSpecies <- function(scientific_name, tax_ids, comment=NULL, url=NULL) {
  file_name <- 
    sprintf('%s_%sUniprot_%s%s.fasta',
            gsub(' ', '_', scientific_name),
            ifelse(is.null(name), 
                   '', 
                   sprintf('(%s)_', gsub(' ', '', toupper(name)))),
            ifelse(is.null(comment), 
                   '', 
                   sprintf('(%s)_', gsub(' ', '_', comment))),
            ifelse(is.null(overwrite_date),
                   format(Sys.Date(), '%Y%m%d'),
                   overwrite_date))
  list(scientific_name=scientific_name,
       tax_ids=tax_ids, 
       name=name,
       file_name=file_name, 
       url=url)
}
EnsemblSpecies <- function(scientific_name, url, name=NULL, comment=NULL) {
  file_name <- 
    sprintf('%s_%sEnsembl_%s%s.fasta',
            gsub(' ', '_', scientific_name),
            ifelse(is.null(name), 
                   '', 
                   sprintf('(%s)_', gsub(' ', '', toupper(name)))),
            ifelse(is.null(comment), 
                   '', 
                   sprintf('(%s)_', gsub(' ', '_', comment))),
            ifelse(is.null(overwrite_date),
                   format(Sys.Date(), '%Y%m%d'),
                   overwrite_date))
  list(scientific_name=scientific_name,
       name=name,
       file_name=file_name, 
       url=url)
}

UniprotSpecies <- function(scientific_name, tax_ids, comments='') {
  ref_proteomes %>%
    filter(Organism.ID %in% tax_ids) %>%
    mutate(
      filename=sprintf('%s_Uniprot_%s_%s_%s.fasta',
                       gsub(' ','.', scientific_name),
                       overwrite_date,
                       Proteome.ID,
                       gsub(' ','.', comments)),
      link1=file.path(
      'ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/reference_proteomes',
      sub('([^,]+),.*', '\\1', Taxonomic.lineage),
      sprintf('%s_%s.fasta.gz', Proteome.ID, Organism.ID)
    ),
    link2=file.path(
      'ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/reference_proteomes',
      sub('([^,]+),.*', '\\1', Taxonomic.lineage),
      sprintf('%s_%s_additional.fasta.gz', Proteome.ID, Organism.ID)
    )) %>%
  tidyr::pivot_longer(starts_with('link'), names_to='link', values_to='download_links') ->
    my_proteome
  complete_file <- c()
  if(nrow(my_proteome) > 0) {
    cat(sprintf('start download ref proteome: %s\n',
                paste(unique(my_proteome$Organism, collapse=',\n'))))
    
    download_files <- unname(
      my_proteome %>% transmute(filename=paste0(filename, 1:n())) %>% unlist()
    )
    # complete_file_name <- my_proteome$filename[1]
    
    jnk <- tryCatch(
      download.file(my_proteome$download_links,
                    destfile=download_files, 
                    quiet=TRUE),
      warning=function(w) w)
    complete_file <- do.call("c", lapply(download_files[file.exists(download_files)], 
                                         function(file) {
                                           readLines(file)
                                         }))
    jnk <- file.remove(download_files[file.exists(download_files)])
    # writeLines(complete_file, complete_file_name)
  } 
  missing_tax_ids <- tax_ids[!tax_ids %in% my_proteome$Organism.ID]
  if(length(missing_tax_ids)) {
    cat(sprintf('start download manual proteome: %s\n',
                scientific_name))
    download_link <- 
      sprintf('http://www.uniprot.org/uniprot/?compress=no&query=organism:%s&format=fasta&include=yes',
              missing_tax_ids)
    # complete_file_name <- 
    #   sprintf('%s_Uniprot_%s_%s_%s.fasta',
    #           gsub(' ','.', scientific_name),
    #           overwrite_date,
    #           'noRefProt',
    #           gsub(' ','.', comments))
    download_files <- paste0(complete_file_name, seq(length(download_link)))
    
    jnk <- download.file(download_link,
                         destfile=download_files, 
                         quiet=TRUE)
    complete_file <- c(complete_file,
                       do.call("c", lapply(download_files, function(file) {
                         readLines(file)
                       })))
    jnk <- file.remove(download_files)
    # writeLines(complete_file, complete_file_name)
  }
  
  complete_file_name <- 
    sprintf('%s_Uniprot_%s_%s_%s.fasta',
            gsub(' ','.', scientific_name),
            overwrite_date,
            ifelse(nrow(my_proteome) > 0, 
                   ifelse(length(missing_tax_ids) > 0, 
                          paste(paste(unique(my_proteome$Proteome.ID), collapse='.'), 
                                'AND', 
                                'noRefProt', 
                                sep='.'), 
                          paste(unique(my_proteome$Proteome.ID), collapse='.')),
                   'noRefProt'),
            gsub(' ','.', comments))
  
  writeLines(complete_file, complete_file_name)
  complete_file <- seqinr::read.fasta(complete_file_name, seqtype='AA')
  if(any(grepl('^tr', seqinr::getName(complete_file)))) 
    seqinr::write.fasta(
      complete_file[grepl('^tr', seqinr::getName(complete_file))], 
      names=substring(seqinr::getAnnot(complete_file)[grepl('^tr', seqinr::getName(complete_file))], 2),
      file.out=file.path(
        out_dir,
        sub('.fasta', sprintf('_%dseq.fasta', sum(grepl('^tr', seqinr::getName(complete_file)))), 
            sub('Uniprot','trembl', complete_file_name))))
  if(any(grepl('^sp', seqinr::getName(complete_file)))) 
    seqinr::write.fasta(
      complete_file[grepl('^sp', seqinr::getName(complete_file))], 
      names=substring(seqinr::getAnnot(complete_file)[grepl('^sp', seqinr::getName(complete_file))], 2),
      file.out=file.path(
        out_dir,
        sub('.fasta', sprintf('_%dseq.fasta', sum(grepl('^sp', seqinr::getName(complete_file)))), 
            sub('Uniprot','swissprot', complete_file_name))))
  jnk <- unlink(complete_file_name)
}


UniprotSpecies('Arabidopsis thaliana', 3702)
UniprotSpecies('Bombyx mori', 7091)
UniprotSpecies('Bos taurus', 9913)
UniprotSpecies('Caenorhabditis elegans', 6239)
UniprotSpecies('Canis lupus', 9615)
# UniprotSpecies('Danaus plexippus', 
#                c(13037))
# UniprotSpecies('Danaus plexippus', 
#                c(278856, 1699404, 278857))
UniprotSpecies('Danaus plexippus', 
               c(13037, 278856, 1699404, 278857))
UniprotSpecies('Danio rerio', 7955)
UniprotSpecies('Daphnia magna', 35525)
UniprotSpecies('Daphnia pulex', 6669)
UniprotSpecies('Drosophila melanogaster', 7227)

UniprotSpecies('Escherichia coli', 83333, 'strain K12')
UniprotSpecies('Felis catus', 9685)
UniprotSpecies('Gallus gallus', 9031)
UniprotSpecies('Homo sapiens', 9606)
UniprotSpecies('Mus musculus', 10090)

UniprotSpecies('Moloney murine leukemia virus', 928306)
UniprotSpecies('Neurospora crassa', 367110, 'strain.ATCC.24698')
UniprotSpecies('Rattus norvegicus', 10116)
UniprotSpecies('Saccharomyces cerevisiae', 559292, 'strain.ATCC.204508')
UniprotSpecies('Schizosaccharomyces pombe', 284812, 'strain.ATCC.24843')
UniprotSpecies('Sus scrofa', 9823)
UniprotSpecies('Trichoplusia ni', 7111)
UniprotSpecies('Spodoptera frugiperda', 7108, 'SF9.cells')
UniprotSpecies('Synechocystis.sp.PCC6803', 1111708)
UniprotSpecies('Platynereis dumerilii', 6359)
UniprotSpecies('Xenopus laevis', 8355)
UniprotSpecies('Xenopus tropicalis', 8364)
UniprotSpecies('Human cytomegalovirus', 10360, 'strain.AD169')
UniprotSpecies('Human cytomegalovirus', 10359)
UniprotSpecies('Human cytomegalovirus', 10363, 'strain Towne')


EnsemblSpecies('Drosophila melanogaster',
               url='ftp://ftp.ensembl.org/pub/release-95/fasta/drosophila_melanogaster/pep/Drosophila_melanogaster.BDGP6.pep.all.fa.gz', 
               name='Fruit fly', comment='release95')

EnsemblSpecies('Homo sapiens',
               url='ftp://ftp.ensembl.org/pub/release-95/fasta/homo_sapiens/pep/Homo_sapiens.GRCh38.pep.all.fa.gz', 
               name='Human', comment='release95')
EnsemblSpecies('Mus musculus',
               url='ftp://ftp.ensembl.org/pub/release-95/fasta/mus_musculus/pep/Mus_musculus.GRCm38.pep.all.fa.gz', 
               name='Mouse', comment='release95')
