###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

context("testing LFQ analysis script")

runAllChunks <- function(rmd, envir=globalenv()){
  # as found here http://stackoverflow.com/questions/24753969
  tempR <- tempfile(tmpdir = '.', fileext = ".R")
  on.exit(unlink(tempR))
  # knitr::purl(rmd, output=tempR, quiet=TRUE)
  knitr::knit(rmd, output=tempR, quiet=TRUE, envir=envir)
  # sys.source(tempR, envir=envir)
}

# set the correct folder paths
test_dir <- 'lfq_test'
start_dir <- getwd()

# tests before executing --------------------------------------------------
# list of test file folders
data_folders <- list.dirs('../LFQ_DATA', recursive=FALSE)

for(folder in data_folders) {
  dir.create(test_dir)
  setwd(test_dir)
  a.LFQ_ANALYSIS.script(dbg_level=Inf)
  
  for(filename in list.files(file.path('..',folder), full.names=TRUE)) {
    # since we are in the test_dir we have to add '../' to the path
    file.copy(filename, basename(filename))
  }
  outdir <- 'main_data_out'
  # source('config.R')
  # outdir <- paste0(config$prefix, 'main_data_out')
  # 
  # test_that('main out folder already exists', {
  #   expect_that(file.exists(outdir),
  #               is_false())
  # })
  
  test_that(
    sprintf('LFQ analysis works with "%s" folder.',
            basename(folder)), {
              # expect_warning(f <- runAllChunks('010_main_lfq_analysis.Rmd'),
              # 'Column "Gene.names" does not exist. Using "Protein.IDs" instead!')
              expect_error(
                f <- knitr::knit('010_main_lfq_analysis.Rmd', output='jnk.R', quiet=TRUE, envir=globalenv()), NA)
              # expect_that(file.exists('main_analysis_data.RData'), is_true())
    expect_that(dir.exists(outdir), is_true())
    expect_that(file.exists(file.path(outdir, 'abundance_rank.pdf')), is_true())
    expect_that(file.exists(file.path(outdir, 'imputed_values.pdf')), is_true())
    expect_that(file.exists(file.path(outdir, 'intensity_comparison.pdf')), is_true())
    expect_that(file.exists(file.path(outdir, 'all_pca_proteinGroups_prcomp.pdf')), is_true())
    expect_that(file.exists(file.path(outdir, 'protein_counts.pdf')), is_true())
    expect_that(file.exists(file.path(outdir, 'quantified_proteinGroups.txt')), is_true())
  })

  
  # switch back to original folder and deleting testfolder
  setwd(start_dir)  
  unlink(test_dir, recursive=TRUE)
}

test_that('LFQ analysis standard settings are correct', {
  expect_equal(data_dir, '.', info=sprintf('data_dir is "%s"', data_dir))
  expect_equal(pg_filename, 'proteinGroups.txt', info='protein group file name is not correct')
  expect_that(razor_peptides, equals(2), 'razor peptide setting is not 2')
  expect_that(unique_peptides, equals(1), 'unique peptides setting is not 1')
  expect_that(min_quant_events, equals(2), 'min quant events are not 2')
})





