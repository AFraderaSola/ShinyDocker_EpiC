###############################################################################
#
# Test RawFile class
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

context("testing RawFile Object")
options(rMQanalysis.dbg_level = 0)

filenames <- c("/Volumes/Proteomics-Data//2015/20150618_QEP2_IMB_CF_0330_hs_PR_NON_120/20150618_QEP2_IMB_CF_0330-D_hs_PR_NON_120.raw",                          
               "/Volumes/Proteomics-Data//2015/20150614_QEP1_IMB_CF_0327_hs_PR_DML_120/IC_IMB_CF_0327-C/IC_DML_4/20150614_QEP1_IMB_CF_0327-C_hs_PR_DML_120.raw",
               "/Volumes/Proteomics-Data//2014/20140607_QEP1_IMB_HR_0022_hs_IP_NON_060/20140607_QEP1_IMB_HR_0022_hs_IP_NON_060.raw",                            
               "/Volumes/Proteomics-Data//2014/20141113_QEP1_IMB_CF_0179_sc_PR_SIL_300/20141113_QEP1_IMB_CF_0179_sc_PR_SIL_300.raw",                            
               "/Volumes/Proteomics-Data//2014/20141023_QEP1_IMB_HR_0075_hs_IP_SIL_120/20141023_QEP1_IMB_HR_0075_hs_IP_SIL_120.raw",                            
               "/Volumes/Proteomics-Data//2014/20140718_QEP1_IMB_CF_0137-0138_hs_IP_SIL_060,090,120/20140722_QEP1_IMB_CF_0137_hs_IP_SIL_090.raw",               
               "/Volumes/Proteomics-Data//2015/20150507_QEP1_IMB_CF_HeLa_SILAC_500ng_120/20150507_QEP1_IMB_CF_HeLa_SILAC_500ng_120.raw",                       
               "/Volumes/Proteomics-Data//2015/20150328_QEP1_IMB_CF_0259-0270_na_IP_DML_120/20150328_QEP1_IMB_CF_0265_hs_PR_DIM_120.raw",                       
               "/Volumes/Proteomics-Data//2014/20140902_QEP2_IMB_CF_0153-0154-NC_hs_IP_SIL_120/20140902_QEP2_IMB_CF_0154-NC_hs_IP_SIL_120.raw",                 
               "/Volumes/Proteomics-Data//2015/20150113_QEP1_IMB_CF_HeLa-500ng_hs_PR_SIL_120/20150113_QEP1_IMB_CF_HeLa-500ng_hs_PR_SIL_120.raw")

test_that('RawFile returns object with variable basename', { 
  a <- list(basename='filename.raw')
  expect_warning(b <- RawFile('filename.raw'), 'expect this filename format more often')
  expect_equal(b$basename, a$basename)
})

test_that('RawFile returns object with variable fullname', {
  a <- list(fullname='filename.raw')
  expect_warning(b <- RawFile('filename.raw'), 'expect this filename format more often')
  expect_equal(b$fullname, a$fullname)
})

test_that('RawFile matches the standard filenames', {
  expect_that(all(sapply(filenames, function(x) RawFile(x)$matching)),
              equals(TRUE))
})

test_that('getParameter on RawFile object throws error if parameter does not exists.', {
  raw_file <- RawFile(filenames[1])
  expect_that(getParameter(raw_file, 'data_xyz'), throws_error())
})

test_that('getParameter on RawFile object returns expected values.', {
  raw_file <- RawFile('20150618_QEP2_IMB_CF_0330_hs_PR_NON_120/20150618_QEP2_IMB_CF_0330-D_hs_PR_NON_120.raw')
  expect_that(getParameter(raw_file, 'date'), equals('20150618'))
  expect_that(getParameter(raw_file, 'machine'), equals('QEP2'))
  expect_that(getParameter(raw_file, 'institute'), equals('IMB'))
  expect_that(getParameter(raw_file, 'group'), equals('CF'))
  expect_that(getParameter(raw_file, 'barcode'), equals('0330-D'))
  expect_that(getParameter(raw_file, 'species'), equals('hs'))
  expect_that(getParameter(raw_file, 'experiment'), equals('PR'))
  expect_that(getParameter(raw_file, 'label'), equals('NON'))
  expect_that(getParameter(raw_file, 'retentiontime'), equals('120'))
})

test_that('RawFile can handle manual input', {
  raw_file1 <- RawFile(date='20150618', machine='QEP2', institute='IMB',
          group='CF', barcode='0330-D', species='hs',
          experiment='PR', label='NON', retentiontime='120')
  raw_file2 <- RawFile('20150618_QEP2_IMB_CF_0330-D_hs_PR_NON_120.raw')
  expect_that(getParameter(raw_file1, 'date'), equals(getParameter(raw_file2, 'date')))
  expect_that(getParameter(raw_file1, 'machine'), equals(getParameter(raw_file2, 'machine')))
  expect_that(getParameter(raw_file1, 'institute'), equals(getParameter(raw_file2, 'institute')))
  expect_that(getParameter(raw_file1, 'group'), equals(getParameter(raw_file2, 'group')))
  expect_that(getParameter(raw_file1, 'barcode'), equals(getParameter(raw_file2, 'barcode')))
  expect_that(getParameter(raw_file1, 'species'), equals(getParameter(raw_file2, 'species')))
  expect_that(getParameter(raw_file1, 'experiment'), equals(getParameter(raw_file2, 'experiment')))
  expect_that(getParameter(raw_file1, 'label'), equals(getParameter(raw_file2, 'label')))
  expect_that(getParameter(raw_file1, 'retentiontime'), equals(getParameter(raw_file2, 'retentiontime')))
})



