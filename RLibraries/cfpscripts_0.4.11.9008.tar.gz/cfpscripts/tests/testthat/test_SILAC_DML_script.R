###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

context("testing SILAC DML script")

original_test_mode <- getOption('cfpscripts.test_mode')
original_impute_mode <- getOption('cfpscripts.impute_mode')
options('cfpscripts.test_mode' = TRUE)
# set the correct folder paths
test_dir <- 'dml_silac_test'
start_dir <- getwd()


# if(file.exists('../../inst')) {
#   script_path <- '../../inst'
# } else {
#   script_path <- '../../00_pkg_src/cfpscripts/inst'
# }

# list of test file folders
data_folders <- list.dirs('../SILAC_DML_DATA', recursive=FALSE)


for(folder in data_folders) {
  dir.create(test_dir)
  setwd(test_dir)
  
  script_file <- a.SILAC.script(dbg_level=Inf)
  
  
#   # copy script file
#   script_file <- file.path(script_path, 'SILAC-DML_with_PDF.R')
#   file.copy(script_file, file.path(test_dir, basename(script_file)), overwrite=TRUE)
#   
#   # copy folder recursive to testdir and name it as combined
#   dir.create(file.path(test_dir, 'combined'))
#   dir.create(file.path(test_dir, 'combined', 'txt'))
#   txt_files <- list.files(file.path(folder, 'txt'), full.names=TRUE)
#   txt_files_copied <- lapply(txt_files, function(x) { 
#     file.copy(x, 
#               file.path(test_dir, 'combined', 'txt', basename(x)),
#               overwrite=TRUE)}
#     )
  test_that(sprintf('we could copy all files from "%s".', folder), {
    expect_that(
      file.copy(list.files(file.path('..',folder), full.names=TRUE), 
                '.', 
                recursive=TRUE), 
      is_true())
  })
  
  test_that(sprintf('SILAC-DML Script works with "%s" data', folder), {
    expect_warning(capture.output(messages <- source(basename(script_file))), 
                'Script was not copied',
                info='the "use source button" warning doesn\'t get printed')
  })
  
  # test imputing
  options('cfpscripts.impute_mode' = TRUE)
  test_that(sprintf('SILAC-DML Script works with "%s" data AND imputing!', folder), {
    expect_warning(capture.output(messages <- source(basename(script_file))), 
                   'Script was not copied',
                   info='the "use source button" warning doesn\'t get printed')
    
  })
  options('cfpscripts.impute_mode' = original_impute_mode)
  
  setwd(start_dir)  
  unlink(test_dir, recursive=TRUE)
}


test_that(sprintf('data directory was is set to "combined/txt"'), {
  expect_that(data_directory, is_equivalent_to(file.path('combined','txt')))
})
test_that(sprintf('imputing is set to FALSE as standard'), {
  expect_that(impute, is_false())
})
test_that(sprintf('zoom_quadrant is set to "UL" as default'), {
  expect_that(zoom_quadrant, is_equivalent_to('UL'))
})
test_that(sprintf('interactive plot was set to FALSE'), {
  expect_that(interactive_plot, is_false())
})

options('cfpscripts.test_mode' = original_test_mode)
options('cfpscripts.impute_mode' = original_impute_mode)

