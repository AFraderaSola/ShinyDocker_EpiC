###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

context("testing BAND IDENTIFICATION script")

original_test_mode <- getOption('cfpscripts.test_mode')
options('cfpscripts.test_mode' = TRUE)
# set the correct folder paths
test_dir <- 'band_identification_test'
start_dir <- getwd()


if(file.exists('../../inst')) {
  script_path <- '../../inst'
} else {
  script_path <- '../../00_pkg_src/cfpscripts/inst'
}

# list of test file folders
data_folders <- list.dirs('../BAND_IDENTIFICATION_DATA', recursive=FALSE)


test_that(sprintf('Proteomics-Data folder is accessable'), {
  expect_that(file.exists('/Volumes/Proteomics-Data'), is_true())
})

for(folder in data_folders[-grep('/not_', data_folders)]) {
  dir.create(test_dir)
  setwd(test_dir)
  
  # copy script file
  script_file <- a.BAND_IDENTIFICATION.script(dbg_level=Inf)
  
  test_that(sprintf('we could copy all files from "%s".', 
                    folder), {
                      expect_that(
                        all(file.copy(list.files(file.path('..',folder), full.names=TRUE), 
                                  '.', 
                                  recursive=TRUE)), 
                        is_true())
                    })

  test_that(sprintf('BAND IDENTIFICATION Script works with "%s" data', folder), {
    # expect_that(capture.output(messages <- source(basename(script_file))), 
    #             not(throws_error()))
    expect_warning(capture.output(messages <- source(basename(script_file))),
                   'Script was not copied to "executed_scripts" directory!\nPlease use the Source button instead of just running the lines')
  })
  test_that(sprintf('data directory was is set to "combined/txt"'), {
    expect_that(data_directory, is_equivalent_to(file.path('combined','txt')))
  })
  
  setwd(start_dir)  
  unlink(test_dir, recursive=TRUE)
  # unlink('tests/testthat/dml_silac_test', recursive=TRUE)
}





options('cfpscripts.test_mode' = original_test_mode)

