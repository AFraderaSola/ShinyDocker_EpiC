###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

context("testing DML create folder and start MQ script")

source('~/.Rprofile')

original_test_mode <- getOption('cfpscripts.test_mode')
original_impute_mode <- getOption('cfpscripts.impute_mode')
options('cfpscripts.test_mode' = TRUE)
# set the correct folder paths
test_dir <- 'dml_ic_mq_test'
start_dir <- getwd()

# list of test file folders
data_folders <- list.dirs('../DML_IC_MQ_DATA', recursive=FALSE)

test_that('massspec folder is mounted.', {
  expect_true(file.exists('/Volumes/massspec'),
              '/Volumes/massspec is not mounted!')
})

for(folder in data_folders) {
  dir.create(test_dir)
  setwd(test_dir)
  
  script_file <- a.DML_prepare_IC.script(dbg_level=Inf)
  
  test_that(sprintf('we could copy all files from "%s".', 
                    folder), {
                      expect_that(
                        all(file.copy(list.files(file.path('..',folder), full.names=TRUE), 
                                      '.', 
                                      recursive=TRUE)), 
                        is_true())
                    })
  withWarnings <- function(expr) {
    myWarnings <- NULL
    wHandler <- function(w) {
      myWarnings <<- c(myWarnings, list(w))
      invokeRestart("muffleWarning")
    }
    val <- withCallingHandlers(expr, 
                                warning = wHandler)
    list(value = val, warnings = myWarnings, source_output=source_output)
  } 
  suppressMessages(my_test <- 
                     withWarnings(source_output <- 
                                    capture.output(source(basename(script_file)))))
  test_that(
    sprintf('DML create folder start MQ Script works with "%s" data', 
            folder), {
              expect_true(any(grepl('Script was not copied to \"executed_scripts\" directory!\nPlease use the Source button instead of just running the lines.\n',
                                    sapply(my_test$warnings, function(x) x$message))),
                          'Use source button message is not displayed')
              expect_true(any(grepl('!!! MaxQuantCmd.exe is not provided. !!!\n!!! The folder structure gets created but not analysed. !!!',
                                    sapply(my_test$warnings, function(x) x$message))),
                          'MaxQuantCmd.exe warning is not printed')
              expect_true(any(grepl('processingData() is only working in a windows environment.',
                                    sapply(my_test$warnings, function(x) x$message), 
                                    fixed=TRUE)),
                          'Warning "processingData() only in windows" does not get printed')
            })
  

  count_rawfiles <- length(list.files(pattern='.raw$'))
  created_folders <- list.dirs(recursive=FALSE)
  test_that(sprintf('%s folder got created for each raw file.',
                    subfolder_prefix), {
                      expect_equal(length(grep(subfolder_prefix, created_folders)),
                                   count_rawfiles)
                    })
  setwd(start_dir)  
  unlink(test_dir, recursive=TRUE)
}


processes_to_start_default <- 6
test_that(sprintf('max quant processes to start is set to %s',
                  processes_to_start_default), {
  expect_that(processes_to_start, 
              is_equivalent_to(processes_to_start_default))
})

options('cfpscripts.test_mode' = original_test_mode)
options('cfpscripts.impute_mode' = original_impute_mode)

