###############################################################################
#
# developer: Mario Dejung <m.dejung@imb.de>
#
# package version: 0.4.10
# package date: 2018-05-25
# 
###############################################################################

library(cfpscripts)


context("testing all a.XXX.script functions")

script_functions <- grep('^a\\..*\\.script$', lsf.str('package:cfpscripts'), value=TRUE)
exclude_from_testing <- c('a.PR_IP_SILAC_for_rev.script', 
                          'a.IP_NON_SILAC.script')
script_functions <- 
  script_functions[!grepl(paste(exclude_from_testing, collapse='|'),script_functions)]

for(script_file in script_functions) {
  test_that(sprintf('%s() copies correct file into working directory', script_file), {  
    result <- NULL
    scriptFunction <- get(script_file)
    expect_error(result <- scriptFunction(dbg_level=2), NA) 
    if(!is.null(result)) {
      file.remove(result)
    }
  })
}


test_that('copyScriptFile can copy a file', {
  filename <- 'recommended_packages.R'
  destination <- '.'
  f <- copyScriptFile(filename, destination, 2)
  expect_that(file.exists(file.path(destination, filename)), is_true())
  file.remove(f)
})


test_that('copyScriptFile can copy a file into new directory', {
  filename <- 'recommended_packages.R'
  destination <- 'test'
  f <- copyScriptFile(filename, destination, 2)
  expect_that(file.exists(file.path(destination, filename)), is_true())
  file.remove(f)
  file.remove(destination)
})

test_that('copyScriptFile is producing log messages if dbg_level is smaller than 1', {
  filename <- 'recommended_packages.R'
  destination <- '.'
  expect_that(f <- copyScriptFile(filename, destination, 0), 
              prints_text('\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2} INFO: Copy ".*" script to .*.'))
  expect_that(file.exists(file.path(destination, filename)), is_true())
  file.remove(f)
})


if(file.exists('../../R/scriptFunctions.R')) {
  script_files <- list.files('../../inst/', pattern='.*\\.R$|.*\\.Rmd$', recursive=TRUE)
  scriptFunctions_lines <- readLines('../../R/scriptFunctions.R')
} else {
  script_files <- list.files('../../00_pkg_src/cfpscripts/inst/', pattern='.*\\.R$|.*\\.Rmd$', recursive=TRUE)
  scriptFunctions_lines <- readLines('../../00_pkg_src/cfpscripts/R/scriptFunctions.R')
}
exclude_files <- c('update_version_date.R', 
                   'SILAC-DML_stand_alone.R',
                   'usersample_todo.R',
                   'lfq_lite.R',
                   'HeLa_maintenance_stats.R',
                   'HeLa_automated_maintenance.R',
                   'under_development',
                   'createBIStructure.R',
                   'extdata/',
                   'NGSpipe2go.Rmd')
# matching_files <- na.omit(match(exclude_files, script_files))
matching_files <- grep(paste(exclude_files, collapse='|'), 
                       script_files)
if(length(matching_files) > 0) {
  script_files <- script_files[-matching_files]
} 

for(script_file in script_files) {
  test_that(sprintf('copy function exists for %s', script_file), {  
    regex <- paste0("copyScriptFile.*", basename(script_file), ".*")
    expect_that(any(grepl(regex, scriptFunctions_lines)), 
                is_true()) 
  })
}

