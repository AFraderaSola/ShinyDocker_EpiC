specific_proteins <- c('Q9WTL8-2')
